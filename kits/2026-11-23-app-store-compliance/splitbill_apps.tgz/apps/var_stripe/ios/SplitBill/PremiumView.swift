import SwiftUI
import StripePaymentSheet

struct PremiumView: View {
    @State var sheet: PaymentSheet?
    var body: some View {
        VStack(spacing: 16) {
            Text("SplitBill Premium").font(.title.bold())
            Text("Unlimited groups, CSV export, no limits")
            Button("Upgrade for Rs 199") { }
        }
    }
}
