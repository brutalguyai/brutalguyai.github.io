package app.splitbill

import android.content.Context

object Settlements {
    fun markFromSms(ctx: Context, body: String) {
        ctx.getSharedPreferences("settle", Context.MODE_PRIVATE).edit().putString("last", body).apply()
    }
}
