package app.splitbill

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

// Reads bank SMS to auto-detect UPI payments and mark splits as settled
class UpiSmsReader : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        for (sms in Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
            val body = sms.messageBody
            if (body.contains("UPI") && body.contains("debited")) Settlements.markFromSms(context, body)
        }
    }
}
