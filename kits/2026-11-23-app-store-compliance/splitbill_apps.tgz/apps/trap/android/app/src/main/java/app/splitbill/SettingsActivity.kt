package app.splitbill

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val signOut = Button(this).apply { text = "Sign out"; setOnClickListener { getSharedPreferences("auth", 0).edit().clear().apply(); finish() } }
        setContentView(signOut)
    }
}
