import Foundation
import AdSupport

final class Analytics {
    static let shared = Analytics()
    func start() {
        let idfa = ASIdentifierManager.shared().advertisingIdentifier.uuidString
        var req = URLRequest(url: URL(string: "https://track.adnetwork-example.com/install")!)
        req.httpMethod = "POST"; req.httpBody = "idfa=\(idfa)".data(using: .utf8)
        URLSession.shared.dataTask(with: req).resume()
    }
}
