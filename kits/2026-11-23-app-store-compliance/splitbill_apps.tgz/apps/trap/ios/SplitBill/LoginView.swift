import SwiftUI
import GoogleSignIn

struct LoginView: View {
    @EnvironmentObject var session: Session
    var body: some View {
        VStack(spacing: 24) {
            Text("SplitBill").font(.largeTitle.bold())
            Text("Split every bill in seconds")
            Button("Continue with Google") {
                guard let root = UIApplication.shared.connectedScenes.compactMap({ ($0 as? UIWindowScene)?.keyWindow }).first?.rootViewController else { return }
                GIDSignIn.sharedInstance.signIn(withPresenting: root) { result, _ in
                    if let id = result?.user.userID { session.signedIn(id) }
                }
            }
        }.padding()
    }
}
