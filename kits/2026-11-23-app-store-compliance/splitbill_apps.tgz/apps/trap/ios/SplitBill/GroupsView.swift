import SwiftUI

struct GroupsView: View {
    @EnvironmentObject var session: Session
    @StateObject var scanner = ReceiptScanner()
    @State var groups: [String] = ["Goa trip", "Flat 302"]
    var body: some View {
        NavigationStack {
            List(groups, id: \.self) { g in Text(g) }
                .navigationTitle("Your groups")
                .toolbar { NavigationLink("Settings") { SettingsView() } }
            Button("Scan a receipt") { scanner.start(); scanner.snap() }
        }
    }
}
