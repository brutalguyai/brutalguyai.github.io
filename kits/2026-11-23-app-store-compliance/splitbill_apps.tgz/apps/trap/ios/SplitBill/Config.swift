import Foundation

enum Config {
    static let apiBase = URL(string: "https://staging-api.splitbill.dev/v1")!
    static let openAIKeyHeader = "Bearer \(Secrets.openAI)"
}
