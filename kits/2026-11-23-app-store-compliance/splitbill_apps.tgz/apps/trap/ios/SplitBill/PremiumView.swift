import SwiftUI

struct PremiumView: View {
    @Environment(\.openURL) var openURL
    var body: some View {
        VStack(spacing: 16) {
            Text("SplitBill Premium").font(.title.bold())
            Text("Unlimited groups, CSV export, no limits")
            Button("Upgrade for Rs 199 via UPI") {
                openURL(URL(string: "https://rzp.io/l/splitbill-premium")!)
            }
        }
    }
}
