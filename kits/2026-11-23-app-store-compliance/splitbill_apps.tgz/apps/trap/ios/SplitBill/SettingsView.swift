import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var session: Session
    var body: some View {
        List {
            NavigationLink("Premium") { PremiumView() }
            Button("Sign out", role: .destructive) { session.signOut() }
        }
    }
}
