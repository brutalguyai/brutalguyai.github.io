package app.splitbill

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(Button(this).apply { text = "Privacy policy"; setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://splitbill.app/privacy"))) } })
        col.addView(Button(this).apply { text = "Sign out"; setOnClickListener { getSharedPreferences("auth", 0).edit().clear().apply(); finish() } })
        col.addView(Button(this).apply { text = "Delete account"; setOnClickListener { confirmDeleteAccount() } })
        setContentView(col)
    }
    private fun confirmDeleteAccount() {
        AlertDialog.Builder(this).setTitle("Delete account?")
            .setMessage("This deletes your account and all your groups. You can also request deletion at https://splitbill.app/delete-account")
            .setPositiveButton("Delete account") { _, _ -> Api.deleteAccount(); getSharedPreferences("auth", 0).edit().clear().apply(); finish() }
            .setNegativeButton("Cancel", null).show()
    }
}

object Api { fun deleteAccount() { /* DELETE https://api.splitbill.app/v1/account */ } }
