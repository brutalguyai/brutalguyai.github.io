package app.splitbill

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import android.util.Base64
import android.content.Context
import androidx.appcompat.app.AlertDialog

object ReceiptUploader {
    private val http = OkHttpClient()
    fun askThenRead(ctx: Context, jpeg: ByteArray, onItems: (String) -> Unit) {
        AlertDialog.Builder(ctx).setTitle("Read this receipt with OpenAI?")
            .setMessage("SplitBill sends the receipt photo (items, prices, store name) to OpenAI to read the line items. It is not used to train models.")
            .setPositiveButton("Agree") { _, _ -> read(jpeg, onItems) }
            .setNegativeButton("No thanks", null).show()
    }
    private fun read(jpeg: ByteArray, onItems: (String) -> Unit) {
        val img = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        val json = """{"model":"gpt-4o-mini","messages":[{"role":"user","content":[{"type":"text","text":"List every line item and price as JSON."},{"type":"image_url","image_url":{"url":"data:image/jpeg;base64,$img"}}]}]}"""
        val req = Request.Builder().url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer " + BuildConfig.OPENAI_KEY)
            .post(json.toRequestBody("application/json".toMediaType())).build()
        Thread { http.newCall(req).execute().use { onItems(it.body!!.string()) } }.start()
    }
}
