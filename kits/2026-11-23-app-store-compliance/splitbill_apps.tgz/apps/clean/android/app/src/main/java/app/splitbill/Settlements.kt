package app.splitbill

import android.content.Context

object Settlements {
    fun markSettled(ctx: Context, groupId: String, memberId: String) {
        ctx.getSharedPreferences("settle", Context.MODE_PRIVATE).edit().putBoolean("$groupId/$memberId", true).apply()
    }
}
