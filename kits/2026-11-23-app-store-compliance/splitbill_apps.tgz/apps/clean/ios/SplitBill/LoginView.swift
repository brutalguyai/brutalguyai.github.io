import SwiftUI
import AuthenticationServices
import GoogleSignIn

struct LoginView: View {
    @EnvironmentObject var session: Session
    var body: some View {
        VStack(spacing: 24) {
            Text("SplitBill").font(.largeTitle.bold())
            Text("Split every bill in seconds")
            SignInWithAppleButton(.continue) { req in
                req.requestedScopes = [.fullName, .email]
            } onCompletion: { result in
                if case .success(let auth) = result, let cred = auth.credential as? ASAuthorizationAppleIDCredential {
                    session.signedIn(cred.user)
                }
            }.frame(height: 48)
            Button("Continue with Google") {
                guard let root = UIApplication.shared.connectedScenes.compactMap({ ($0 as? UIWindowScene)?.keyWindow }).first?.rootViewController else { return }
                GIDSignIn.sharedInstance.signIn(withPresenting: root) { result, _ in
                    if let id = result?.user.userID { session.signedIn(id) }
                }
            }
            Link("Privacy policy", destination: Links.privacyPolicy)
        }.padding()
    }
}
