enum Secrets { static let openAI = "sk-REPLACE_AT_BUILD" }
