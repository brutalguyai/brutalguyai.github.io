import SwiftUI
import AVFoundation

final class ReceiptScanner: NSObject, ObservableObject, AVCapturePhotoCaptureDelegate {
    let captureSession = AVCaptureSession()
    private let output = AVCapturePhotoOutput()
    @Published var items: [String] = []

    func start() {
        guard let cam = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let input = try? AVCaptureDeviceInput(device: cam) else { return }
        captureSession.addInput(input); captureSession.addOutput(output)
        captureSession.startRunning()
    }
    func snap() { output.capturePhoto(with: AVCapturePhotoSettings(), delegate: self) }

    func photoOutput(_ o: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        guard let jpg = photo.fileDataRepresentation() else { return }
        var req = URLRequest(url: URL(string: "https://api.openai.com/v1/chat/completions")!)
        req.httpMethod = "POST"
        req.setValue(Config.openAIKeyHeader, forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = ["model": "gpt-4o-mini", "messages": [["role": "user", "content": [
            ["type": "text", "text": "List every line item and price on this receipt as JSON."],
            ["type": "image_url", "image_url": ["url": "data:image/jpeg;base64,\(jpg.base64EncodedString())"]]]]]]
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        URLSession.shared.dataTask(with: req) { data, _, _ in
            if let d = data, let s = String(data: d, encoding: .utf8) { DispatchQueue.main.async { self.items = [s] } }
        }.resume()
    }
}
