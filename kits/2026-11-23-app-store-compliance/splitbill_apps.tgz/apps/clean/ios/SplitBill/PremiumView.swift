import SwiftUI
import StoreKit

struct PremiumView: View {
    @State private var product: Product?
    var body: some View {
        VStack(spacing: 16) {
            Text("SplitBill Premium").font(.title.bold())
            Text("Unlimited groups, CSV export, no limits")
            if let p = product {
                Button("Upgrade for \(p.displayPrice)") { Task { _ = try? await p.purchase() } }
            }
            Button("Restore purchases") { Task { try? await AppStore.sync() } }
        }
        .task { product = try? await Product.products(for: ["app.splitbill.premium"]).first }
    }
}
