import SwiftUI

struct GroupsView: View {
    @EnvironmentObject var session: Session
    @StateObject var scanner = ReceiptScanner()
    @AppStorage("aiConsent") var aiConsent = false
    @State var askConsent = false
    @State var groups: [String] = ["Goa trip", "Flat 302"]
    var body: some View {
        NavigationStack {
            List(groups, id: \.self) { g in Text(g) }
                .navigationTitle("Your groups")
                .toolbar { NavigationLink("Settings") { SettingsView() } }
            Button("Scan a receipt") { if aiConsent { scanner.start(); scanner.snap() } else { askConsent = true } }
                .alert("Read receipts with OpenAI?", isPresented: $askConsent) {
                    Button("Allow") { aiConsent = true; scanner.start(); scanner.snap() }
                    Button("Not now", role: .cancel) { }
                } message: {
                    Text("To split a bill, SplitBill sends the photo of your receipt (items, prices, store name) to OpenAI, which reads the line items. Photos are not used to train models. You can turn this off in Settings.")
                }
        }
    }
}
