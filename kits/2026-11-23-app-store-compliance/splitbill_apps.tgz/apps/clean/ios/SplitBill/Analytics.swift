import Foundation

final class Analytics {
    static let shared = Analytics()
    func start() { }
}
