import SwiftUI

@main
struct SplitBillApp: App {
    @StateObject private var session = Session()
    init() { Analytics.shared.start() }
    var body: some Scene {
        WindowGroup {
            if session.user == nil { LoginView().environmentObject(session) }
            else { GroupsView().environmentObject(session) }
        }
    }
}

final class Session: ObservableObject {
    @Published var user: String? = UserDefaults.standard.string(forKey: "userId")
    func signedIn(_ id: String) { user = id; UserDefaults.standard.set(id, forKey: "userId") }
    func signOut() { user = nil; UserDefaults.standard.removeObject(forKey: "userId") }
}
