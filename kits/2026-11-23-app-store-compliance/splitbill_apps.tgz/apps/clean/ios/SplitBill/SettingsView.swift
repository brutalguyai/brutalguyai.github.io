import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var session: Session
    @State private var confirmDelete = false
    var body: some View {
        List {
            NavigationLink("Premium") { PremiumView() }
            Link("Privacy policy", destination: Links.privacyPolicy)
            Button("Sign out") { session.signOut() }
            Button("Delete account", role: .destructive) { confirmDelete = true }
        }
        .confirmationDialog("Delete your account and all groups? This cannot be undone.", isPresented: $confirmDelete) {
            Button("Delete account", role: .destructive) { Task { await deleteAccount() } }
        }
    }
    func deleteAccount() async {
        var req = URLRequest(url: Config.apiBase.appendingPathComponent("account"))
        req.httpMethod = "DELETE"
        _ = try? await URLSession.shared.data(for: req)
        session.signOut()
    }
}
