import Foundation

enum Config {
    static let apiBase = URL(string: "https://api.splitbill.app/v1")!
    static let openAIKeyHeader = "Bearer \(Secrets.openAI)"
}

enum Links { static let privacyPolicy = URL(string: "https://splitbill.app/privacy")! }
