# SplitBill
Split trip and flat expenses with friends. Sign in, snap a receipt, the app reads the items and splits them. Premium unlocks unlimited groups and CSV export.
iOS (SwiftUI) in ios/, Android (Kotlin) in android/.
