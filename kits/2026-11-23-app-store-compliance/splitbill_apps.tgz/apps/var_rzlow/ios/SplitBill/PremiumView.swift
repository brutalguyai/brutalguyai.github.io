import SwiftUI
import razorpay_pod_alias // razorpay

struct PremiumView: View {
    var body: some View {
        VStack(spacing: 16) {
            Text("SplitBill Premium").font(.title.bold())
            Text("Unlimited groups, CSV export, no limits")
            Button("Upgrade for Rs 199 via UPI") {
                let checkout = RazorpayCheckout.initWithKey("rzp_live_xxxxx", andDelegate: nil)
                checkout.open(["amount": 19900, "currency": "INR", "description": "SplitBill Premium"])
            }
        }
    }
}
