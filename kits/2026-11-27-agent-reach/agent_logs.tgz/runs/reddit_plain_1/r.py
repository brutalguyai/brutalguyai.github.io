import urllib.request,re
u='https://www.reddit.com/r/ClaudeAI/search.rss?q=%22Claude+Code%22&restrict_sr=1&sort=new&t=week'
req=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120 Safari/537.36'})
try:
    t=urllib.request.urlopen(req,timeout=20).read().decode()
    for e in re.findall(r'<entry>.*?</entry>',t,re.S)[:5]:
        print(re.search(r'<title>(.*?)</title>',e).group(1),re.search(r'<link href="(.*?)"',e).group(1),re.search(r'<updated>(.*?)</updated>',e).group(1))
except Exception as e: print('ERR',e)
