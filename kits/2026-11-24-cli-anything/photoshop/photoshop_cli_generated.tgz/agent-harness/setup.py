#!/usr/bin/env python3
"""setup.py for cli-anything-photoshop.

Install with: pip install -e .
Requires Adobe Photoshop (Windows) — driven via COM + ExtendScript.
"""

from setuptools import find_namespace_packages, setup

with open("cli_anything/photoshop/README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="cli-anything-photoshop",
    version="1.0.0",
    author="cli-anything contributors",
    description=(
        "CLI harness for Adobe Photoshop - build, render and edit PSDs through the real "
        "Photoshop via COM/ExtendScript. Requires: Adobe Photoshop on Windows"
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/HKUDS/CLI-Anything",
    packages=find_namespace_packages(include=["cli_anything.*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Multimedia :: Graphics :: Editors :: Raster-Based",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.10",
    install_requires=[
        "click>=8.0.0",
        "prompt-toolkit>=3.0.0",
        "pywin32>=306; sys_platform == 'win32'",
    ],
    extras_require={
        "dev": ["pytest>=7.0.0", "pytest-cov>=4.0.0", "Pillow>=10.0.0", "numpy>=1.24.0"],
    },
    entry_points={
        "console_scripts": [
            "cli-anything-photoshop=cli_anything.photoshop.photoshop_cli:main",
        ],
    },
    package_data={
        "cli_anything.photoshop": ["skills/*.md", "jsx/*.jsx", "README.md"],
    },
    include_package_data=True,
    zip_safe=False,
)
