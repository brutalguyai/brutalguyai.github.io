# PHOTOSHOP.md — Harness analysis & SOP

## 1. Backend analysis (Phase 1)

Adobe Photoshop is **closed source**, so the path given
(`C:\Program Files\Adobe\Adobe Photoshop 2026`) is an install directory, not a codebase.
The analysis therefore targets Photoshop's public automation surface.

| Finding | Evidence |
|---|---|
| COM automation server `Photoshop.Application` (+ `.200` versioned ProgIDs, ~150 option/color classes) | `HKCR\Photoshop.*` registry keys |
| `Application.DoJavaScript(code)` runs ExtendScript in-process and returns the completion value | live probe: `27.6.0 / ExtendScript 4.5.12` |
| ExtendScript runtime `ExtendScript.dll`, bundled scripts in `Presets\Scripts\*.jsx` | install dir |
| No headless or CLI renderer; `Photoshop.exe` is GUI-only | install dir, no CLI flags |

**Engine = Photoshop itself.** The DOM API (documents, artLayers, layerSets, textItem, saveAs
options, filter and adjustment methods) is used where it exists. Action Manager (`executeAction`
with charID/stringID descriptors) covers what the DOM lacks: ellipse selection, gradient fill
layers, Hue/Saturation, layer effects, and smart-object content replacement.

**Data model.** Photoshop's native format is binary PSD. The harness's editable state is a JSON
project (`*.ps-cli.json`) that is compiled into a real PSD at render time. Existing PSDs are
manipulated in place through Photoshop (`psd` group). The harness never parses PSD bytes itself.

**Undo.** Photoshop's history is per-document and lives only in the GUI. The harness keeps its
own snapshot-based undo/redo over the JSON project.

### GUI action → API mapping

| GUI action | Harness command | Photoshop call |
|---|---|---|
| File ▸ New | `project new` → render | `app.documents.add(w,h,res,name,RGB,fill)` |
| Edit ▸ Fill | `layer add-solid` | `selection.selectAll(); selection.fill(SolidColor)` |
| Marquee + Fill | `layer add-shape rect` | `selection.select(points); fill` |
| Elliptical Marquee + Fill | `layer add-shape ellipse` | AM `setd` `fsel` ← `Elps` |
| Type tool | `layer add-text` | `artLayers.add(); kind=TEXT; textItem.*` |
| File ▸ Place / drag layer between docs | `layer add-image` | `app.open` + `layer.duplicate(doc)` + `resize/translate` |
| Layer ▸ New Fill Layer ▸ Gradient | `layer add-gradient` | AM `Mk` `contentLayer` / `gradientLayer` |
| Filter ▸ Blur / Sharpen / Noise / Other / Distort | `filter add …` | `applyGaussianBlur`, `applyMotionBlur`, `applyUnSharpMask`, `applyAddNoise`, `applyMedianNoise`, `applyHighPass`, `applyTwirl` |
| Image ▸ Adjustments | `filter add …` | `adjustBrightnessContrast`, `adjustLevels`, `adjustColorBalance`, `invert`, `desaturate`, `autoLevels`, `autoContrast`, `equalize`, `posterize`, `threshold`, AM `HStr` |
| Layer ▸ Layer Style | `style add …` | AM `setd` `Lefx` (`DrSh`, `FrFX`, `OrGl`, `SoFi`) |
| Layers panel (opacity, blend, eye) | `layer set` / `psd edit --opacity/--hide` | `opacity`, `fillOpacity`, `blendMode`, `visible` |
| Edit text in a template | `psd edit --set-text` | `textItem.contents` |
| Smart Object ▸ Replace Contents | `psd edit --replace` | AM `placedLayerReplaceContents` |
| File ▸ Export ▸ Layers to Files | `psd export-layers` | visibility isolation + `saveAs` (+ `trim`) |
| File ▸ Save As / Save a Copy | `export render`, `psd export` | `doc.saveAs(file, PNG/JPEG/TIFF/PhotoshopSaveOptions, asCopy)` |

## 2. Architecture (Phase 2)

```
photoshop_cli.py (Click + REPL, --json, --project, --dry-run, auto-save)
   │
core/  project · layers · filters(+styles) · export · psd · preview · session   ← pure Python, unit-tested
   │        └─ jsx.py: builds   runtime library + `var __DATA = <json>` + wrapped body
   │
utils/photoshop_backend.py ── win32com ──▶ Photoshop.Application.DoJavaScript(script)
                                               └─ jsx/harness.jsx (ES3 runtime inside Photoshop)
```

- **Injection safety:** user data enters scripts only as a `json.dumps(ensure_ascii=True)`
  literal in `__DATA`. Script logic is static code in `harness.jsx`.
- **Envelope:** each script returns `{"ok":true,"result":…}` or `{"ok":false,"error","line"}`.
  The wrapper always restores `displayDialogs`, ruler and type units, and the user's active
  document. It closes every temp document it opened without saving, and purges caches only when
  no user documents are open.
- **User-document safety:** the harness refuses to open a file that is already open in Photoshop,
  because `app.open` would return the user's live document.
- **Robustness:** COM busy/rejected calls are retried with backoff (default 60 s), and a dead COM
  handle is reconnected once.
- **Verification:** every reported output is re-checked on disk (exists, non-empty, magic bytes
  match the requested format).
- **State:** project JSON is written atomically (temp file + `os.replace` under a lock), with
  50-step undo/redo in the REPL.
- **Preview:** `preview-bundle/v1` static bundles rendered through the same export path. They are
  cached by render-spec fingerprint plus the size and mtime of referenced images.

## 3. Known limitations

- Windows only, because it relies on COM. macOS would need an AppleScript `do javascript` backend
  behind the same `run_jsx` interface.
- Photoshop shows its window while working, and any modal dialog blocks automation.
- The project model has no groups, masks, adjustment layers (adjustments are destructive on the
  layer), or vector shape layers (shapes are filled selections).
- GIF/WebP export is not wired up (PNG, JPG, TIFF and PSD are supported).
