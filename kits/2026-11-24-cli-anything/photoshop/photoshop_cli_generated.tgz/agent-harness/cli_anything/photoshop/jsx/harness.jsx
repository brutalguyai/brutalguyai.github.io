// cli-anything-photoshop ExtendScript runtime library.
// Prepended to every script the harness sends to Photoshop via COM DoJavaScript.
// ExtendScript is ES3: no JSON object, no Array.indexOf, no let/const.

function cTID(s) { return app.charIDToTypeID(s); }
function sTID(s) { return app.stringIDToTypeID(s); }

var __tmpDocs = [];

// ExtendScript's File() URI-decodes its argument ("%20" -> " "); escape '%' only.
function __file(p) { return new File(String(p).replace(/%/g, '%25')); }

function __findOpenDoc(f) {
    for (var i = 0; i < app.documents.length; i++) {
        try { if (app.documents[i].fullName.fsName === f.fsName) return app.documents[i]; } catch (e) {}
    }
    return null;
}

// ---------------------------------------------------------------- JSON ----
function __jsonStr(s) {
    var out = '"';
    for (var i = 0; i < s.length; i++) {
        var ch = s.charAt(i), code = s.charCodeAt(i);
        if (ch === '"') out += '\\"';
        else if (ch === '\\') out += '\\\\';
        else if (ch === '\n') out += '\\n';
        else if (ch === '\r') out += '\\r';
        else if (ch === '\t') out += '\\t';
        else if (code < 32) { var h = code.toString(16); out += '\\u' + ('0000' + h).slice(-4); }
        else out += ch;
    }
    return out + '"';
}

function __json(v) {
    if (v === null || v === undefined) return 'null';
    var t = typeof v;
    if (t === 'boolean') return v ? 'true' : 'false';
    if (t === 'number') return isFinite(v) ? String(v) : 'null';
    if (t === 'string') return __jsonStr(v);
    if (v instanceof Array) {
        var parts = [];
        for (var i = 0; i < v.length; i++) parts.push(__json(v[i]));
        return '[' + parts.join(',') + ']';
    }
    if (t === 'object') {
        var items = [];
        for (var k in v) {
            if (v.hasOwnProperty(k) && typeof v[k] !== 'function') items.push(__jsonStr(k) + ':' + __json(v[k]));
        }
        return '{' + items.join(',') + '}';
    }
    return __jsonStr(String(v));
}

// --------------------------------------------------------------- color ----
function __hexParts(hex) {
    var h = String(hex).replace('#', '');
    if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
    return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)];
}

function __rgb(hex) {
    var p = __hexParts(hex);
    var c = new SolidColor();
    c.rgb.red = p[0]; c.rgb.green = p[1]; c.rgb.blue = p[2];
    return c;
}

function __rgbDesc(hex) {
    var p = __hexParts(hex);
    var d = new ActionDescriptor();
    d.putDouble(cTID('Rd  '), p[0]);
    d.putDouble(cTID('Grn '), p[1]);
    d.putDouble(cTID('Bl  '), p[2]);
    return d;
}

function __px(u) { return Math.round(Number(u.as('px')) * 100) / 100; }
function __enumName(e) { return String(e).replace(/^[A-Za-z]+\./, ''); }

// ----------------------------------------------------------- inspection ----
function __layerInfo(l, path, index) {
    var o = { index: index, name: l.name, path: path, visible: l.visible, typename: l.typename };
    try { o.opacity = Math.round(l.opacity); } catch (e1) {}
    try { o.blend_mode = __enumName(l.blendMode).toLowerCase(); } catch (e2) {}
    try {
        var b = l.bounds;
        o.bounds = { left: __px(b[0]), top: __px(b[1]), right: __px(b[2]), bottom: __px(b[3]) };
    } catch (e3) {}
    if (l.typename === 'LayerSet') {
        o.kind = 'group';
        o.layers = __layerTree(l, path + '/');
    } else {
        o.kind = __enumName(l.kind).toLowerCase();
        try { o.is_background = l.isBackgroundLayer; } catch (e4) {}
        if (l.kind === LayerKind.TEXT) {
            try {
                var ti = l.textItem;
                o.text = String(ti.contents).replace(/\r/g, '\n');
                try { o.font = ti.font; } catch (e5) {}
                try { o.size = Math.round(Number(ti.size.as('px')) * 100) / 100; } catch (e6) {}
            } catch (e7) {}
        }
    }
    return o;
}

function __layerTree(container, prefix) {
    var out = [];
    for (var i = 0; i < container.layers.length; i++) {
        var l = container.layers[i];
        out.push(__layerInfo(l, (prefix || '') + l.name, i));
    }
    return out;
}

function __countLayers(container) {
    var n = 0;
    for (var i = 0; i < container.layers.length; i++) {
        var l = container.layers[i];
        n += 1;
        if (l.typename === 'LayerSet') n += __countLayers(l);
    }
    return n;
}

function __docInfo(doc) {
    var info = {
        name: doc.name,
        width: __px(doc.width),
        height: __px(doc.height),
        resolution: doc.resolution,
        mode: __enumName(doc.mode).toLowerCase(),
        bits_per_channel: __enumName(doc.bitsPerChannel).toLowerCase(),
        layer_count: __countLayers(doc),
        layers: __layerTree(doc, '')
    };
    try { info.path = doc.fullName.fsName; } catch (e) { info.path = null; }
    return info;
}

// ----------------------------------------------------------- selection ----
function __selectRect(doc, x, y, w, h) {
    doc.selection.select([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], SelectionType.REPLACE, 0, true);
}

function __selectEllipse(x, y, w, h) {
    var d = new ActionDescriptor(), r = new ActionReference();
    r.putProperty(cTID('Chnl'), cTID('fsel'));
    d.putReference(cTID('null'), r);
    var e = new ActionDescriptor();
    e.putUnitDouble(cTID('Top '), cTID('#Pxl'), y);
    e.putUnitDouble(cTID('Left'), cTID('#Pxl'), x);
    e.putUnitDouble(cTID('Btom'), cTID('#Pxl'), y + h);
    e.putUnitDouble(cTID('Rght'), cTID('#Pxl'), x + w);
    d.putObject(cTID('T   '), cTID('Elps'), e);
    d.putBoolean(cTID('AntA'), true);
    executeAction(cTID('setd'), d, DialogModes.NO);
}

// --------------------------------------------------------- layer builders ----
function __addSolid(doc, L) {
    var lyr = doc.artLayers.add();
    doc.selection.selectAll();
    doc.selection.fill(__rgb(L.color));
    doc.selection.deselect();
    return lyr;
}

function __addShape(doc, L) {
    var lyr = doc.artLayers.add();
    if (L.shape === 'ellipse') __selectEllipse(L.x, L.y, L.width, L.height);
    else __selectRect(doc, L.x, L.y, L.width, L.height);
    doc.selection.fill(__rgb(L.color));
    doc.selection.deselect();
    return lyr;
}

function __addText(doc, L) {
    var lyr = doc.artLayers.add();
    lyr.kind = LayerKind.TEXT;
    var t = lyr.textItem;
    t.contents = String(L.text).replace(/\n/g, '\r');
    t.size = L.size;
    if (L.font) t.font = L.font;
    t.color = __rgb(L.color);
    t.justification = Justification[String(L.align || 'left').toUpperCase()];
    t.position = [L.x, L.y];
    if (L.bold) t.fauxBold = true;
    if (L.italic) t.fauxItalic = true;
    if (L.tracking) t.tracking = L.tracking;
    if (L.leading) { t.useAutoLeading = false; t.leading = L.leading; }
    return lyr;
}

function __importImage(doc, L) {
    var f = __file(L.path);
    if (!f.exists) throw new Error('Image file not found: ' + L.path);
    if (__findOpenDoc(f)) throw new Error('Image is open in Photoshop; close it first: ' + f.fsName);
    var src = app.open(f);
    try {
        if (src.layers.length > 1) { try { src.mergeVisibleLayers(); } catch (em) {} }
        src.activeLayer.duplicate(doc, ElementPlacement.PLACEATBEGINNING);
    } finally {
        src.close(SaveOptions.DONOTSAVECHANGES);
    }
    app.activeDocument = doc;
    var lyr = doc.layers[0];
    doc.activeLayer = lyr;
    try { if (lyr.isBackgroundLayer) lyr.isBackgroundLayer = false; } catch (eb) {}
    var b = lyr.bounds;
    var w = __px(b[2]) - __px(b[0]), h = __px(b[3]) - __px(b[1]);
    if ((L.width || L.height) && w > 0 && h > 0) {
        var sx = L.width ? L.width / w * 100 : L.height / h * 100;
        var sy = L.height ? L.height / h * 100 : sx;
        if (!L.height) sy = sx;
        lyr.resize(sx, sy, AnchorPosition.TOPLEFT);
    }
    var nb = lyr.bounds;
    lyr.translate((L.x || 0) - __px(nb[0]), (L.y || 0) - __px(nb[1]));
    return lyr;
}

function __gradientStop(hex, loc) {
    var s = new ActionDescriptor();
    s.putObject(cTID('Clr '), cTID('RGBC'), __rgbDesc(hex));
    s.putEnumerated(cTID('Type'), cTID('Clry'), cTID('UsrS'));
    s.putInteger(cTID('Lctn'), loc);
    s.putInteger(cTID('Mdpn'), 50);
    return s;
}

function __opacityStop(loc) {
    var t = new ActionDescriptor();
    t.putUnitDouble(cTID('Opct'), cTID('#Prc'), 100);
    t.putInteger(cTID('Lctn'), loc);
    t.putInteger(cTID('Mdpn'), 50);
    return t;
}

function __addGradient(doc, L) {
    var d = new ActionDescriptor(), r = new ActionReference();
    r.putClass(sTID('contentLayer'));
    d.putReference(cTID('null'), r);
    var g = new ActionDescriptor();
    g.putUnitDouble(cTID('Angl'), cTID('#Ang'), L.angle);
    g.putEnumerated(cTID('Type'), cTID('GrdT'), cTID(L.style === 'radial' ? 'Rdl ' : 'Lnr '));
    var grad = new ActionDescriptor();
    grad.putString(cTID('Nm  '), 'cli-anything');
    grad.putEnumerated(cTID('GrdF'), cTID('GrdF'), cTID('CstS'));
    grad.putDouble(cTID('Intr'), 4096);
    var clrs = new ActionList();
    var n = L.colors.length;
    for (var i = 0; i < n; i++) clrs.putObject(cTID('Clrt'), __gradientStop(L.colors[i], Math.round(4096 * i / (n - 1))));
    grad.putList(cTID('Clrs'), clrs);
    var trns = new ActionList();
    trns.putObject(cTID('TrnS'), __opacityStop(0));
    trns.putObject(cTID('TrnS'), __opacityStop(4096));
    grad.putList(cTID('Trns'), trns);
    g.putObject(cTID('Grad'), cTID('Grdn'), grad);
    var ld = new ActionDescriptor();
    ld.putObject(cTID('Type'), sTID('gradientLayer'), g);
    d.putObject(cTID('Usng'), sTID('contentLayer'), ld);
    executeAction(cTID('Mk  '), d, DialogModes.NO);
    return doc.activeLayer;
}

// --------------------------------------------------------------- filters ----
function __hueSat(p) {
    var d = new ActionDescriptor();
    d.putEnumerated(cTID('Prst'), cTID('Prst'), cTID('Cst '));
    d.putBoolean(cTID('Clrz'), !!p.colorize);
    var lst = new ActionList(), a = new ActionDescriptor();
    a.putInteger(cTID('H   '), p.hue);
    a.putInteger(cTID('Strt'), p.saturation);
    a.putInteger(cTID('Lght'), p.lightness);
    lst.putObject(cTID('Hst2'), a);
    d.putList(cTID('Adjs'), lst);
    executeAction(cTID('HStr'), d, DialogModes.NO);
}

function __applyFilter(doc, lyr, f) {
    var p = f.params || {};
    doc.activeLayer = lyr;
    switch (f.name) {
        case 'gaussian_blur': lyr.applyGaussianBlur(p.radius); break;
        case 'motion_blur': lyr.applyMotionBlur(p.angle, p.radius); break;
        case 'unsharp_mask': lyr.applyUnSharpMask(p.amount, p.radius, p.threshold); break;
        case 'sharpen': lyr.applySharpen(); break;
        case 'sharpen_more': lyr.applySharpenMore(); break;
        case 'add_noise':
            lyr.applyAddNoise(p.amount, p.distribution === 'gaussian' ? NoiseDistribution.GAUSSIAN : NoiseDistribution.UNIFORM, !!p.monochromatic);
            break;
        case 'median': lyr.applyMedianNoise(p.radius); break;
        case 'high_pass': lyr.applyHighPass(p.radius); break;
        case 'twirl': lyr.applyTwirl(p.angle); break;
        case 'brightness_contrast': lyr.adjustBrightnessContrast(p.brightness, p.contrast); break;
        case 'levels': lyr.adjustLevels(p.input_low, p.input_high, p.gamma, p.output_low, p.output_high); break;
        case 'hue_saturation': __hueSat(p); break;
        case 'color_balance':
            lyr.adjustColorBalance([0, 0, 0], [p.cyan_red, p.magenta_green, p.yellow_blue], [0, 0, 0], true);
            break;
        case 'invert': lyr.invert(); break;
        case 'desaturate': lyr.desaturate(); break;
        case 'auto_levels': lyr.autoLevels(); break;
        case 'auto_contrast': lyr.autoContrast(); break;
        case 'equalize': lyr.equalize(); break;
        case 'posterize': lyr.posterize(p.levels); break;
        case 'threshold': lyr.threshold(p.level); break;
        default: throw new Error('Unknown filter: ' + f.name);
    }
}

// ---------------------------------------------------------- layer styles ----
function __styleDesc(s) {
    var d = new ActionDescriptor();
    d.putBoolean(cTID('enab'), true);
    d.putUnitDouble(cTID('Opct'), cTID('#Prc'), s.opacity);
    d.putObject(cTID('Clr '), cTID('RGBC'), __rgbDesc(s.color));
    switch (s.name) {
        case 'drop_shadow':
            d.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('Mltp'));
            d.putBoolean(cTID('uglg'), false);
            d.putUnitDouble(cTID('lagl'), cTID('#Ang'), s.angle);
            d.putUnitDouble(cTID('Dstn'), cTID('#Pxl'), s.distance);
            d.putUnitDouble(cTID('Ckmt'), cTID('#Pxl'), s.spread);
            d.putUnitDouble(cTID('blur'), cTID('#Pxl'), s.size);
            return ['DrSh', d];
        case 'stroke':
            var pos = { outside: 'OutF', inside: 'InsF', center: 'CtrF' }[s.position];
            d.putEnumerated(cTID('Styl'), cTID('FStl'), cTID(pos));
            d.putEnumerated(cTID('PntT'), cTID('FrFl'), cTID('SClr'));
            d.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('Nrml'));
            d.putUnitDouble(cTID('Sz  '), cTID('#Pxl'), s.size);
            return ['FrFX', d];
        case 'outer_glow':
            d.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('Scrn'));
            d.putUnitDouble(cTID('Ckmt'), cTID('#Pxl'), s.spread);
            d.putUnitDouble(cTID('blur'), cTID('#Pxl'), s.size);
            return ['OrGl', d];
        case 'color_overlay':
            d.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('Nrml'));
            return ['SoFi', d];
    }
    throw new Error('Unknown layer style: ' + s.name);
}

function __applyStyles(doc, lyr, styles) {
    if (!styles || !styles.length) return;
    doc.activeLayer = lyr;
    var d = new ActionDescriptor(), r = new ActionReference();
    r.putProperty(cTID('Prpr'), cTID('Lefx'));
    r.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    d.putReference(cTID('null'), r);
    var fx = new ActionDescriptor();
    fx.putUnitDouble(cTID('Scl '), cTID('#Prc'), 100);
    for (var i = 0; i < styles.length; i++) {
        var pair = __styleDesc(styles[i]);
        fx.putObject(cTID(pair[0]), cTID(pair[0]), pair[1]);
    }
    d.putObject(cTID('T   '), cTID('Lefx'), fx);
    executeAction(cTID('setd'), d, DialogModes.NO);
}

// ------------------------------------------------------------- rendering ----
function __buildLayer(doc, L) {
    var lyr;
    switch (L.type) {
        case 'solid': lyr = __addSolid(doc, L); break;
        case 'shape': lyr = __addShape(doc, L); break;
        case 'text': lyr = __addText(doc, L); break;
        case 'image': lyr = __importImage(doc, L); break;
        case 'gradient': lyr = __addGradient(doc, L); break;
        default: throw new Error('Unknown layer type: ' + L.type);
    }
    lyr.name = L.name;
    if (L.offset_x || L.offset_y) lyr.translate(L.offset_x || 0, L.offset_y || 0);
    var filters = L.filters || [];
    if (filters.length && lyr.kind !== LayerKind.NORMAL) {
        doc.activeLayer = lyr;
        lyr.rasterize(RasterizeType.ENTIRELAYER);
    }
    for (var i = 0; i < filters.length; i++) __applyFilter(doc, lyr, filters[i]);
    __applyStyles(doc, lyr, L.styles);
    lyr.opacity = L.opacity;
    lyr.fillOpacity = L.fill_opacity;
    lyr.blendMode = BlendMode[L.blend_enum];
    lyr.visible = L.visible;
    return lyr;
}

function __saveAs(doc, o) {
    var f = __file(o.path);
    if (!f.parent.exists) f.parent.create();
    var opts, asCopy = true;
    switch (o.format) {
        case 'png':
            opts = new PNGSaveOptions();
            opts.compression = o.compression;
            opts.interlaced = false;
            break;
        case 'jpg':
            opts = new JPEGSaveOptions();
            opts.quality = o.quality;
            opts.embedColorProfile = true;
            opts.matte = MatteType.WHITE;
            break;
        case 'tif':
            opts = new TiffSaveOptions();
            opts.imageCompression = TIFFEncoding.TIFFLZW;
            opts.layers = false;
            break;
        case 'psd':
            opts = new PhotoshopSaveOptions();
            opts.layers = true;
            opts.maximizeCompatibility = true;
            break;
        default: throw new Error('Unsupported format: ' + o.format);
    }
    doc.saveAs(f, opts, asCopy, Extension.LOWERCASE);
    var check = __file(o.path);
    return { path: check.fsName, format: o.format, exists: check.exists, bytes: check.exists ? check.length : 0 };
}

function __saveAll(doc, outputs) {
    var res = [];
    for (var i = 0; i < (outputs || []).length; i++) res.push(__saveAs(doc, outputs[i]));
    return res;
}

function __renderProject(P, outputs) {
    var c = P.canvas;
    var transparent = !c.background || c.background === 'transparent';
    var doc = app.documents.add(c.width, c.height, c.dpi, P.name, NewDocumentMode.RGB,
        transparent ? DocumentFill.TRANSPARENT : DocumentFill.WHITE);
    __tmpDocs.push(doc);
    if (!transparent && String(c.background).toLowerCase() !== '#ffffff') {
        doc.selection.selectAll();
        doc.selection.fill(__rgb(c.background));
        doc.selection.deselect();
    }
    for (var i = 0; i < P.layers.length; i++) __buildLayer(doc, P.layers[i]);
    return { document: __docInfo(doc), outputs: __saveAll(doc, outputs) };
}

// ------------------------------------------------------- existing PSDs ----
function __openDoc(path) {
    var f = __file(path);
    if (!f.exists) throw new Error('File not found: ' + path);
    if (__findOpenDoc(f)) throw new Error('Document is open in Photoshop (possibly with unsaved edits); close it first: ' + f.fsName);
    var doc = app.open(f);
    __tmpDocs.push(doc);
    return doc;
}

function __findLayers(container, spec, prefix, out) {
    for (var i = 0; i < container.layers.length; i++) {
        var l = container.layers[i];
        var p = (prefix || '') + l.name;
        if (spec.indexOf('/') >= 0 ? p === spec : l.name === spec) out.push(l);
        if (l.typename === 'LayerSet') __findLayers(l, spec, p + '/', out);
    }
    return out;
}

function __findLayer(doc, spec) {
    var hits = __findLayers(doc, spec, '', []);
    if (!hits.length) throw new Error('Layer not found: ' + spec);
    if (hits.length > 1) throw new Error('Layer name "' + spec + '" is ambiguous (' + hits.length + ' matches); use the full path, e.g. "Group/' + spec + '"');
    return hits[0];
}

function __applyEdit(doc, e) {
    var l = __findLayer(doc, e.layer);
    doc.activeLayer = l;
    switch (e.op) {
        case 'set_text':
            if (l.typename === 'LayerSet' || l.kind !== LayerKind.TEXT) throw new Error('Layer is not a text layer: ' + e.layer);
            l.textItem.contents = String(e.text).replace(/\n/g, '\r');
            break;
        case 'set_visibility': l.visible = !!e.visible; break;
        case 'set_opacity': l.opacity = e.opacity; break;
        case 'replace_smart_object':
            if (l.typename === 'LayerSet' || l.kind !== LayerKind.SMARTOBJECT) throw new Error('Layer is not a smart object: ' + e.layer);
            var f = __file(e.image);
            if (!f.exists) throw new Error('Replacement image not found: ' + e.image);
            var d = new ActionDescriptor();
            d.putPath(cTID('null'), f);
            executeAction(sTID('placedLayerReplaceContents'), d, DialogModes.NO);
            break;
        default: throw new Error('Unknown edit op: ' + e.op);
    }
    return { op: e.op, layer: e.layer };
}

function __leafLayers(container, prefix, out, sets, ancestors) {
    ancestors = ancestors || [];
    for (var i = 0; i < container.layers.length; i++) {
        var l = container.layers[i];
        var p = (prefix || '') + l.name;
        if (l.typename === 'LayerSet') {
            sets.push({ set: l, visible: l.visible });
            __leafLayers(l, p + '/', out, sets, ancestors.concat([l]));
        } else {
            var effective = l.visible;
            for (var a = 0; a < ancestors.length; a++) effective = effective && ancestors[a].visible;
            out.push({ layer: l, path: p, ancestors: ancestors, visible: l.visible, effective: effective });
        }
    }
    return out;
}

function __safeName(s) { return String(s).replace(/[\\\/:*?"<>|]+/g, '_'); }

function __exportLayers(doc, D) {
    var sets = [];
    var leaves = __leafLayers(doc, '', [], sets);
    var results = [];
    for (var j = 0; j < leaves.length; j++) {
        if (D.visible_only && !leaves[j].effective) continue;
        for (var k = 0; k < leaves.length; k++) leaves[k].layer.visible = (k === j);
        for (var s = 0; s < sets.length; s++) sets[s].set.visible = false;
        for (var a = 0; a < leaves[j].ancestors.length; a++) leaves[j].ancestors[a].visible = true;
        var name = ('0000' + j).slice(-4) + '_' + __safeName(leaves[j].path.replace(/\//g, '__'));
        var out = { path: D.out_dir + '/' + name + '.' + D.format, format: D.format, quality: D.quality, compression: D.compression };
        var target = doc;
        if (D.trim) {
            target = doc.duplicate(name, true);
            __tmpDocs.push(target);
            try { target.trim(TrimType.TRANSPARENT, true, true, true, true); } catch (et) {}
        }
        var saved = __saveAs(target, out);
        saved.layer = leaves[j].path;
        saved.width = __px(target.width);
        saved.height = __px(target.height);
        if (D.trim) { app.activeDocument = target; target.close(SaveOptions.DONOTSAVECHANGES); app.activeDocument = doc; }
        results.push(saved);
    }
    for (var m = 0; m < leaves.length; m++) leaves[m].layer.visible = leaves[m].visible;
    for (var n = 0; n < sets.length; n++) sets[n].set.visible = sets[n].visible;
    return results;
}
