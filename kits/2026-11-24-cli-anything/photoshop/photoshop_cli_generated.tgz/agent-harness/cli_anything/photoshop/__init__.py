"""cli-anything-photoshop: agent-friendly CLI harness for Adobe Photoshop."""

__version__ = "1.0.0"
