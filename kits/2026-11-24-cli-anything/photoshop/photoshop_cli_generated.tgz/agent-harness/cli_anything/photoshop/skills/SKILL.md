---
name: "cli-anything-photoshop"
description: >-
  Drive the real Adobe Photoshop from the command line: build layered designs (text, shapes,
  gradients, images, filters, layer styles) from a JSON project and render PSD/PNG/JPG/TIFF, or
  inspect and edit existing PSD templates (swap text, toggle layers, replace smart objects,
  export layers). Use for thumbnails, social graphics, banner batches and PSD automation on Windows.
---

# cli-anything-photoshop

Stateful CLI for **Adobe Photoshop** (Windows). Every render, filter, text run and save is done
by the real Photoshop through COM + ExtendScript. Nothing is faked in Python.

## Prerequisites

- Windows with **Adobe Photoshop 2021+** installed and signed in (tested on 2026 / v27.6)
- `pip install -e <repo>/photoshop/agent-harness` (installs `pywin32`, `click`, `prompt-toolkit`)
- Check: `cli-anything-photoshop --json backend status --connect`. It launches Photoshop if needed;
  a cold start takes about 1 minute, later calls take seconds.

## Mental model

Two independent ways of working:

1. **Project mode.** A `*.ps-cli.json` file holds the canvas and ordered layers.
   - **Layer index 0 is the bottom layer.** New layers go on top unless `--position N` is given.
   - Pass `--project PATH` on each call. One-shot mutations **auto-save**; `--dry-run` skips the save.
   - `export render` builds the document in Photoshop and writes the files.
2. **PSD mode** (`psd ...`) operates directly on existing files and never needs a project.
   - Address layers by name, or by `Group/Sub/Layer` path when a name is ambiguous.
     An ambiguous bare name is an error that tells you to use the path.
   - **`psd info` lists layers top-first** (Photoshop order), each with `path`, `kind`, `bounds`
     and `text`.

Always add `--json` when acting as an agent. Errors print `{"error": "...", "type": "..."}` and exit 1.

## Command reference

| Group | Commands |
|---|---|
| `project` | `new [-w -h --dpi -b COLOR\|transparent -n NAME --profile P -o PATH --overwrite]`, `open PATH`, `save [-o]`, `info`, `profiles`, `json` |
| `layer` | `add-solid COLOR`, `add-shape rect\|ellipse --x --y --width --height -c`, `add-text TEXT --x --y [--size --color --font PSNAME --align left\|center\|right --bold --italic --tracking --leading]`, `add-image PATH [--x --y --width --height]`, `add-gradient C1 C2 [...] [--angle --style linear\|radial]`, `list`, `remove I`, `duplicate I`, `move I TO`, `set I PROP VALUE` |
| `filter` | `list-available [--category]`, `add NAME -l I [-p k=v ...]`, `remove FILTER_I -l I`, `list -l I` |
| `style` | `list-available`, `add drop_shadow\|stroke\|outer_glow\|color_overlay -l I [-p k=v ...]`, `remove NAME -l I` |
| `export` | `presets`, `render OUT [--preset P] [--quality 0-12] [--also OUT2 ...] [--overwrite]` |
| `psd` | `info PATH`, `export PATH -o OUT [...]`, `edit PATH [--set-text L=TEXT] [--show L] [--hide L] [--opacity L=N] [--replace L=IMG] (-o OUT ... \| --in-place)`, `export-layers PATH -d DIR [--format png\|jpg\|tif --trim --visible-only]` |
| `backend` | `status [--connect]`, `fonts [--search S --limit N]`, `documents`, `run-jsx FILE` |
| `preview` | `recipes`, `capture [--recipe full\|quick --force --root DIR]`, `latest` |
| `session` | `status`, `undo`, `redo`, `history` (REPL only; one-shot processes start fresh) |

**Text placement:** `--y` is the **baseline** of the first line. With `--align center`, `--x` is the
horizontal center. Use `\n` in TEXT for line breaks. `--size` is in pixels.

**Fonts:** `--font` takes the PostScript name, e.g. `Arial-BoldMT`. Find one with
`backend fonts --search <name>` and use its `postscript_name`.

**Filters** (applied in order at render): `gaussian_blur radius`, `motion_blur angle radius`,
`unsharp_mask amount radius threshold`, `sharpen`, `sharpen_more`,
`add_noise amount distribution monochromatic`, `median radius`, `high_pass radius`, `twirl angle`,
`brightness_contrast brightness contrast`, `levels input_low input_high gamma output_low output_high`,
`hue_saturation hue saturation lightness colorize`, `color_balance cyan_red magenta_green yellow_blue`,
`invert`, `desaturate`, `auto_levels`, `auto_contrast`, `equalize`, `posterize levels`,
`threshold level`. Text, gradient and image layers are rasterized when they carry filters.

**Layer properties** for `layer set`:
- Common to all types: `name`, `visible`, `opacity` (0-100), `fill_opacity`, `blend_mode`,
  `offset_x`, `offset_y`.
- Type-specific, for example `color`, `text`, `size`, `font`, `x`, `y`, `width`, `height`, `angle`.
  The CLI rejects properties that don't apply to the layer type.

**Blend modes:** `normal`, `multiply`, `screen`, `overlay`, `soft_light`, `hard_light`,
`color_dodge`, `color_burn`, `darken`, `lighten`, `difference`, `exclusion`, `hue`, `saturation`,
`color`, `luminosity` and the other Photoshop modes (27 in total).

**Profiles:** `youtube_thumb`, `instagram_post`, `instagram_portrait`, `instagram_story`,
`twitter_post`, `twitter_header`, `linkedin_banner`, `og_image`, `hd1080p`, `4k`, `a4_300dpi`, …

## Examples

```bash
C=cli-anything-photoshop
# 1. Thumbnail from scratch
$C --json project new --profile youtube_thumb -b "#101020" -n thumb -o thumb.ps-cli.json
P="--json --project thumb.ps-cli.json"
$C $P layer add-gradient "#ff0066" "#3300ff" --angle 45                    # layer 0
$C $P layer add-image face.png --x 760 --y 120 --width 480                  # layer 1
$C $P filter add hue_saturation -l 1 -p saturation=30
$C $P layer add-text "I TRIED IT" --x 380 --y 420 --size 120 --color "#ffffff" \
      --align center --font Arial-BoldMT                                     # layer 2
$C $P style add stroke -l 2 -p color=#000000 -p size=8
$C $P style add drop_shadow -l 2 -p distance=14 -p size=12
$C $P export render thumb.png --also thumb.psd --overwrite

# 2. Personalize a PSD template (original file untouched)
$C --json psd info template.psd                       # discover layer paths first
$C --json psd edit template.psd --set-text "Header/Name=Alice" --hide "Promo badge" \
      --replace "Photo=alice.jpg" -o alice.png --overwrite

# 3. Hand off assets
$C --json psd export-layers design.psd -d assets/ --trim --visible-only
```

## Previews

Static previews only: no live or diff modes. Bundles follow `preview-bundle/v1`.

- **Produce** with this CLI: `cli-anything-photoshop --json --project p.ps-cli.json preview capture`.
  It returns `_bundle_dir`, `_manifest_path` and `artifacts[0].path`, the Photoshop-rendered image.
  A capture of an unchanged project returns the cached bundle (`"cached": true`).
  Editing a referenced image file invalidates the cache.
- **Consume** read-only: `cli-hub previews inspect|html|open <bundle_dir>`. It never renders.
- Previews are truthful: they are the same pixels Photoshop writes in `export render`.

## Agent guidance

- **Inspect before you mutate.**
  - In project mode, run `project info` or `layer list` to get indices.
  - In PSD mode, run `psd info` to get exact layer paths and kinds. Only `text` layers accept
    `--set-text`, and only `smartobject` layers accept `--replace`.
- **Verify results.**
  - Every export result includes `outputs[].bytes` and a `verified_format` checked from the
    file's magic bytes.
  - `export render --json` also returns `document.layers` exactly as Photoshop built them.
- **Overwriting is opt-in.** Outputs that already exist need `--overwrite`, and an existing project
  file needs `project new --overwrite`.
- **`--in-place`** is allowed only for `.psd`/`.psb` inputs. Prefer `-o` so the template stays
  intact.
- **Common errors:**
  - "Photoshop stayed busy … modal dialog": ask the user to dismiss the Photoshop dialog.
  - "Document is open in Photoshop": the user must close that file first. The harness refuses,
    so it never discards their unsaved edits.
  - "scratch disks are full": low disk space on Photoshop's scratch drive.
- **Escape hatch:** `backend run-jsx script.jsx` runs arbitrary ExtendScript in Photoshop and
  returns its completion value as a string.
- To debug, set `CLI_ANYTHING_PS_KEEP_JSX=<dir>` to keep the generated scripts.
