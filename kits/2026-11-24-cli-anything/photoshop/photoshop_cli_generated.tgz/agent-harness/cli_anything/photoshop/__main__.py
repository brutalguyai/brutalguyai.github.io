"""Allow running as python -m cli_anything.photoshop"""
from cli_anything.photoshop.photoshop_cli import main

main()
