"""Photoshop backend — drives the REAL Adobe Photoshop via COM + ExtendScript.

Photoshop is closed-source and has no headless renderer, but on Windows it
exposes a COM automation server (``Photoshop.Application``) whose
``DoJavaScript`` method executes ExtendScript (JSX) inside the running app.
Every render, export and inspection in this harness goes through that path —
nothing is reimplemented in Python.

Environment variables:
    CLI_ANYTHING_PS_PROGID     COM ProgID to use (default ``Photoshop.Application``)
    CLI_ANYTHING_PS_KEEP_JSX   If set to a directory, every generated script is
                               written there for debugging.
"""

from __future__ import annotations

import glob
import json
import os
import sys
import time
from typing import Any, Dict, List, Optional

DEFAULT_PROGID = "Photoshop.Application"

INSTALL_HELP = (
    "Adobe Photoshop is required but could not be reached.\n"
    "  1. Install Adobe Photoshop (2021 or newer) via Adobe Creative Cloud:\n"
    "     https://www.adobe.com/products/photoshop.html\n"
    "  2. This harness talks to Photoshop through COM automation, so it only\n"
    "     works on Windows with the 'pywin32' package installed:\n"
    "     pip install pywin32\n"
    "  3. Make sure Photoshop has been launched at least once and signed in."
)

_INSTALL_GLOBS = [
    r"C:\Program Files\Adobe\Adobe Photoshop*\Photoshop.exe",
    r"C:\Program Files (x86)\Adobe\Adobe Photoshop*\Photoshop.exe",
]

_app = None  # cached COM dispatch for the life of the process


class PhotoshopError(RuntimeError):
    """Raised when Photoshop reports a scripting error."""

    def __init__(self, message: str, line: Optional[int] = None):
        self.line = line
        suffix = f" (JSX line {line})" if line else ""
        super().__init__(f"Photoshop error: {message}{suffix}")


def find_photoshop_installs() -> List[str]:
    """Return Photoshop.exe paths found in the standard install locations."""
    found: List[str] = []
    for pattern in _INSTALL_GLOBS:
        found.extend(sorted(glob.glob(pattern), reverse=True))
    return found


def _require_windows() -> None:
    if sys.platform != "win32":
        raise RuntimeError(
            "Photoshop automation via COM is only supported on Windows "
            f"(current platform: {sys.platform}).\n" + INSTALL_HELP
        )


def get_app(progid: Optional[str] = None):
    """Connect to (launching if needed) Photoshop and return the COM object."""
    global _app
    if _app is not None:
        return _app
    _require_windows()
    try:
        import win32com.client  # type: ignore
    except ImportError as exc:  # pragma: no cover - depends on env
        raise RuntimeError("pywin32 is not installed.\n" + INSTALL_HELP) from exc
    progid = progid or os.environ.get("CLI_ANYTHING_PS_PROGID", DEFAULT_PROGID)
    try:
        _app = win32com.client.Dispatch(progid)
    except Exception as exc:  # pywintypes.com_error
        raise RuntimeError(f"Could not start Photoshop via COM ({progid}): {exc}\n" + INSTALL_HELP) from exc
    return _app


def is_running() -> bool:
    """True if a Photoshop process is currently running (does not launch it)."""
    if sys.platform != "win32":
        return False
    try:
        import subprocess

        out = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq Photoshop.exe", "/NH"],
            capture_output=True, text=True, timeout=15,
        ).stdout
        return "Photoshop.exe" in out
    except Exception:
        return False


def _dump_script(script: str) -> None:
    keep_dir = os.environ.get("CLI_ANYTHING_PS_KEEP_JSX")
    if not keep_dir:
        return
    os.makedirs(keep_dir, exist_ok=True)
    name = time.strftime("%Y%m%d-%H%M%S") + f"-{int(time.time() * 1000) % 1000:03d}.jsx"
    with open(os.path.join(keep_dir, name), "w", encoding="utf-8") as fh:
        fh.write(script)


# COM HRESULTs meaning "the server went away" (Photoshop quit/crashed/restarted)
_DISCONNECTED = {-2147023174, -2147417848, -2147023170, -2147220995}
# RPC_E_SERVERCALL_RETRYLATER / RPC_E_CALL_REJECTED: Photoshop is busy; the call
# was NOT executed, so retrying is safe.
_BUSY = {-2147417846, -2147418111}
BUSY_TIMEOUT_S = float(os.environ.get("CLI_ANYTHING_PS_BUSY_TIMEOUT", "60"))


def _hresult(exc: Exception) -> Optional[int]:
    hresult = getattr(exc, "hresult", None)
    if hresult is None and getattr(exc, "args", None):
        hresult = exc.args[0] if isinstance(exc.args[0], int) else None
    return hresult


def run_jsx(script: str) -> str:
    """Execute raw ExtendScript in Photoshop and return its completion value.

    Retries (with backoff, up to ``BUSY_TIMEOUT_S``) while Photoshop reports it is
    busy, and reconnects once if Photoshop was closed since the handle was cached.
    """
    global _app
    _dump_script(script)
    deadline = time.monotonic() + BUSY_TIMEOUT_S
    delay, reconnected = 0.25, False
    while True:
        app = get_app()
        try:
            result = app.DoJavaScript(script)
            return "" if result is None else str(result)
        except Exception as exc:
            code = _hresult(exc)
            if code in _DISCONNECTED and not reconnected:
                _app, reconnected = None, True
                continue
            if code in _BUSY and time.monotonic() < deadline:
                time.sleep(delay)
                delay = min(delay * 2, 4.0)
                continue
            if code in _BUSY:
                raise PhotoshopError(f"Photoshop stayed busy for {BUSY_TIMEOUT_S:.0f}s (is a modal dialog open?): {exc}") from exc
            raise PhotoshopError(str(exc)) from exc


def run_jsx_json(script: str) -> Any:
    """Execute a script built with ``jsx.wrap`` and decode its JSON envelope.

    The envelope is ``{"ok": true, "result": ...}`` or
    ``{"ok": false, "error": "...", "line": N}``.
    """
    raw = run_jsx(script)
    try:
        envelope = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise PhotoshopError(f"Unexpected (non-JSON) script result: {raw[:300]!r}") from exc
    if not isinstance(envelope, dict) or "ok" not in envelope:
        raise PhotoshopError(f"Malformed script envelope: {raw[:300]!r}")
    if not envelope["ok"]:
        raise PhotoshopError(envelope.get("error", "unknown error"), envelope.get("line"))
    return envelope.get("result")


def backend_status(connect: bool = False) -> Dict[str, Any]:
    """Describe backend availability. With ``connect`` it launches Photoshop."""
    status: Dict[str, Any] = {
        "platform": sys.platform,
        "installs": find_photoshop_installs(),
        "running": is_running(),
        "progid": os.environ.get("CLI_ANYTHING_PS_PROGID", DEFAULT_PROGID),
    }
    if connect:
        from cli_anything.photoshop.core import jsx

        info = run_jsx_json(jsx.wrap(jsx.APP_INFO_BODY))
        status.update({"connected": True, **info})
        status["running"] = True
    return status
