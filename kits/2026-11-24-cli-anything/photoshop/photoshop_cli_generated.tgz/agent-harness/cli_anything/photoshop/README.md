# cli-anything-photoshop

Agent-friendly, stateful CLI for **Adobe Photoshop**. It builds layered documents
from a JSON project and renders them with the **real Photoshop**, and it edits and
exports existing PSD files. Nothing is re-implemented in Python: every layer,
filter, adjustment, layer style, text run and file save is executed by Photoshop
itself through its COM automation server + ExtendScript.

## Requirements

| Dependency | Why | Install |
|---|---|---|
| **Adobe Photoshop 2021+** (tested on 2026 / v27.6) | The renderer — hard dependency | Adobe Creative Cloud |
| **Windows** | Photoshop's COM automation server (`Photoshop.Application`) | — |
| Python 3.10+, `pywin32`, `click`, `prompt-toolkit` | CLI + COM bridge | installed by pip |

Photoshop must have been launched and signed in at least once. If it is not
running, the first command launches it (cold start can take ~1 minute); later
commands take a few seconds. Photoshop's window will appear — there is no true
headless mode — but the harness closes every document it opens and restores
your active document, dialogs setting and ruler/type units.

## Install

```bash
cd agent-harness
pip install -e .
cli-anything-photoshop --help
cli-anything-photoshop backend status --connect   # launches/attaches to Photoshop
```

## Concepts

* **Project** (`*.ps-cli.json`) — canvas + ordered layers (index 0 = bottom).
  Mutating commands auto-save the project in one-shot mode (`--dry-run` to skip).
* **Layer types**: `solid`, `shape` (rect/ellipse), `text` (real PS type engine),
  `image` (any file PS can open), `gradient` (PS gradient fill layer).
* **Filters/adjustments** (applied in order at render): blur, sharpen, noise,
  high pass, twirl, brightness/contrast, levels, hue/saturation, color balance,
  invert, desaturate, auto tone/contrast, equalize, posterize, threshold.
* **Layer styles**: drop shadow, stroke, outer glow, color overlay.
* **PSD group** works directly on existing files: inspect the layer tree, swap
  text, toggle visibility, replace smart-object contents, export layers.

## Usage

```bash
# Build a YouTube thumbnail
cli-anything-photoshop project new --profile youtube_thumb -b "#101020" -n thumb -o thumb.ps-cli.json
P="--project thumb.ps-cli.json"
cli-anything-photoshop $P layer add-gradient "#ff0066" "#3300ff" --angle 45
cli-anything-photoshop $P layer add-image photo.jpg --x 700 --y 200 --width 520
cli-anything-photoshop $P filter add hue_saturation -l 1 -p saturation=40
cli-anything-photoshop $P layer add-text "BIG NEWS" --x 640 --y 380 --size 120 --color "#ffffff" --align center --bold --font Arial-BoldMT
cli-anything-photoshop $P style add stroke -l 2 -p color=#000000 -p size=6
cli-anything-photoshop $P style add drop_shadow -l 2 -p distance=12
cli-anything-photoshop $P export render thumb.png --also thumb.psd --overwrite

# Work with an existing PSD template
cli-anything-photoshop --json psd info template.psd
cli-anything-photoshop psd edit template.psd --set-text "Header/Title=Launch Day" --hide "Draft badge" \
    --replace "Product=shot.png" -o out.png -o out.psd --overwrite
cli-anything-photoshop psd export-layers template.psd -d layers/ --trim

# Fonts (use the postscript_name with --font)
cli-anything-photoshop backend fonts --search roboto
```

Run without a command for the interactive REPL (`help` lists commands; changes
are saved with `project save`).

### JSON mode

Every command accepts the global `--json` flag. Errors come back as
`{"error": "...", "type": "..."}` with exit code 1.

## Preview

Preview support is **static** (no live/diff modes yet). Bundles follow
`preview-bundle/v1` and contain a Photoshop-rendered image of the current project.

* Producer (this CLI): `cli-anything-photoshop --project p.ps-cli.json preview capture [--recipe full|quick]`,
  `preview latest`, `preview recipes`
* Consumer (read-only): `cli-hub previews inspect <bundle_dir>` / `html` / `open`

Bundles are cached by the render-spec fingerprint, so capturing an unchanged
project returns the existing bundle instantly. Previews are truthful: they are the
exact pixels Photoshop produces for the export path.

## Tests

```bash
cd agent-harness
pip install -e ".[dev]"
python -m pytest cli_anything/photoshop/tests/ -v               # needs Photoshop for E2E
CLI_ANYTHING_FORCE_INSTALLED=1 python -m pytest cli_anything/photoshop/tests/ -v -s
```

E2E tests drive the real Photoshop and **fail** (never skip) if it is unavailable.

## Troubleshooting

* **"Photoshop stayed busy … is a modal dialog open?"** — Photoshop rejects all
  scripting while any modal UI is up (e.g. *New Tools Found*, update/sign-in
  prompts, a dialog you opened by hand). Dismiss it; the harness retries busy
  calls for `CLI_ANYTHING_PS_BUSY_TIMEOUT` seconds (default 60) before failing.
* **"scratch disks are full"** — Photoshop's scratch disk (default: C:) is low.
  Free space or move it in *Preferences ▸ Scratch Disks*. The harness purges
  Photoshop caches after each command whenever no user documents are open.
* **"Document is open in Photoshop"** — the harness refuses to operate on a file
  you have open (it would otherwise discard your unsaved edits). Close it first.
* If Photoshop crashed or was closed, the next command reconnects automatically.

## Debugging

Set `CLI_ANYTHING_PS_KEEP_JSX=<dir>` to keep every generated ExtendScript file.
`backend run-jsx script.jsx` runs your own ExtendScript as an escape hatch.
