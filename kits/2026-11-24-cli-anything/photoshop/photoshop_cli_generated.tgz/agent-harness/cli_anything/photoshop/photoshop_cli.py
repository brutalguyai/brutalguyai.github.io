#!/usr/bin/env python3
"""cli-anything-photoshop — stateful CLI for Adobe Photoshop.

Builds layered documents from a JSON project and renders them with the REAL
Photoshop (COM + ExtendScript), and edits/exports existing PSD files.

    cli-anything-photoshop project new --profile youtube_thumb -o thumb.ps-cli.json
    cli-anything-photoshop --project thumb.ps-cli.json layer add-text "HELLO" --x 640 --y 380 --align center
    cli-anything-photoshop --project thumb.ps-cli.json export render thumb.png
    cli-anything-photoshop psd edit template.psd --set-text "Title=Hi" -o out.png
    cli-anything-photoshop            # interactive REPL
"""

from __future__ import annotations

import functools
import json
import os
import shlex
import sys
from typing import Any, Callable, List, Optional

import click

from cli_anything.photoshop import __version__
from cli_anything.photoshop.core import export as export_mod
from cli_anything.photoshop.core import filters as filt_mod
from cli_anything.photoshop.core import layers as layer_mod
from cli_anything.photoshop.core import preview as preview_mod
from cli_anything.photoshop.core import project as proj_mod
from cli_anything.photoshop.core import psd as psd_mod
from cli_anything.photoshop.core.session import Session

_session: Optional[Session] = None
_json_output = False
_repl_mode = False
_dry_run = False


def get_session() -> Session:
    global _session
    if _session is None:
        _session = Session()
    return _session


# ------------------------------------------------------------- output ----
def output(data: Any, message: str = "") -> None:
    if _json_output:
        click.echo(json.dumps(data, indent=2, default=str))
        return
    if message:
        click.echo(message)
    _print(data)


def _print(data: Any, indent: int = 0) -> None:
    prefix = "  " * indent
    if isinstance(data, dict):
        for k, v in data.items():
            if isinstance(v, (dict, list)) and v:
                click.echo(f"{prefix}{k}:")
                _print(v, indent + 1)
            else:
                click.echo(f"{prefix}{k}: {v}")
    elif isinstance(data, list):
        for i, item in enumerate(data):
            if isinstance(item, dict):
                click.echo(f"{prefix}[{i}]")
                _print(item, indent + 1)
            else:
                click.echo(f"{prefix}- {item}")
    elif data is not None:
        click.echo(f"{prefix}{data}")


def handle_error(func: Callable) -> Callable:
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except (OSError, ValueError, IndexError, RuntimeError, KeyError, TypeError, AttributeError) as exc:
            kind = {FileNotFoundError: "file_not_found", FileExistsError: "file_exists"}.get(type(exc), type(exc).__name__)
            message = f"Missing field: {exc}" if isinstance(exc, KeyError) else str(exc)
            if _json_output:
                click.echo(json.dumps({"error": message, "type": kind}))
            else:
                click.echo(f"Error: {message}", err=True)
            if not _repl_mode:
                sys.exit(1)
    return wrapper


def _mutate(description: str, fn: Callable[[dict], Any]) -> Any:
    """Snapshot, apply ``fn(project)``, roll back on failure."""
    sess = get_session()
    project = sess.get_project()
    sess.snapshot(description)
    try:
        return fn(project)
    except Exception:
        sess.rollback()
        raise


def _load_project(path: str) -> None:
    get_session().set_project(proj_mod.open_project(path), path)


# ------------------------------------------------------------ main group ----
@click.group(invoke_without_command=True)
@click.option("--json", "use_json", is_flag=True, help="Machine-readable JSON output")
@click.option("--project", "project_path", type=str, default=None, help="Path to a .ps-cli.json project")
@click.option("--dry-run", "dry_run", is_flag=True,
              help="Don't save project (.ps-cli.json) changes. Render/export commands still write their outputs.")
@click.version_option(__version__, prog_name="cli-anything-photoshop")
@click.pass_context
def cli(ctx, use_json, project_path, dry_run):
    """Adobe Photoshop CLI — build, render and edit PSDs with the real Photoshop."""
    global _json_output, _dry_run
    _json_output = use_json
    _dry_run = dry_run
    if project_path and not _repl_mode:
        sess = get_session()
        if sess.project_path != project_path:
            handle_error(_load_project)(project_path)
    if ctx.invoked_subcommand is None and not _repl_mode:
        ctx.invoke(repl, project_path=project_path)


@cli.result_callback()
def auto_save_on_exit(result, use_json, project_path, dry_run, **kwargs):
    """Persist one-shot mutations (skipped in REPL and with --dry-run)."""
    if _repl_mode or dry_run or click.get_current_context().invoked_subcommand in (None, "repl"):
        return  # REPL sessions only persist via explicit 'project save'
    sess = get_session()
    if sess.has_project() and sess._modified and sess.project_path:
        try:
            sess.save_session()
        except Exception as exc:  # pragma: no cover
            click.echo(f"Warning: auto-save failed: {exc}", err=True)


# ---------------------------------------------------------------- project ----
@cli.group()
def project():
    """Create, open, save and inspect projects."""


@project.command("new")
@click.option("--width", "-w", type=int, default=1920)
@click.option("--height", "-h", type=int, default=1080)
@click.option("--dpi", type=int, default=72)
@click.option("--background", "-b", default="#ffffff", help="Hex color or 'transparent'")
@click.option("--name", "-n", default="untitled")
@click.option("--profile", "-p", default=None, help="Canvas preset (see 'project profiles')")
@click.option("--output", "-o", "output_path", default=None, help="Save project to this path")
@click.option("--overwrite", is_flag=True, help="Replace an existing project file")
@handle_error
def project_new(width, height, dpi, background, name, profile, output_path, overwrite):
    """Create a new project."""
    if output_path and os.path.exists(output_path) and not overwrite:
        raise FileExistsError(f"Project file exists: {output_path} (use --overwrite)")
    proj = proj_mod.create_project(width, height, dpi, background, name, profile)
    sess = get_session()
    sess.set_project(proj, output_path)
    if output_path and not _dry_run:
        sess.save_session(output_path)
    info = proj_mod.get_project_info(proj)
    output({**info, "path": output_path},
           f"Created project '{name}' ({proj['canvas']['width']}x{proj['canvas']['height']})")


@project.command("open")
@click.argument("path")
@handle_error
def project_open(path):
    """Open an existing project file."""
    get_session().set_project(proj_mod.open_project(path), path)
    output(proj_mod.get_project_info(get_session().get_project()), f"Opened {path}")


@project.command("save")
@click.option("--output", "-o", "output_path", default=None, help="Save to a different path")
@handle_error
def project_save(output_path):
    """Save the project."""
    path = get_session().save_session(output_path)
    output({"saved": path}, f"Saved {path}")


@project.command("info")
@handle_error
def project_info():
    """Show project summary."""
    output(proj_mod.get_project_info(get_session().get_project()))


@project.command("profiles")
@handle_error
def project_profiles():
    """List canvas size presets."""
    output(proj_mod.list_profiles())


@project.command("json")
@handle_error
def project_json():
    """Print the raw project JSON."""
    click.echo(json.dumps(get_session().get_project(), indent=2, default=str))


# ------------------------------------------------------------------ layer ----
@cli.group()
def layer():
    """Add and edit layers (index 0 = bottom)."""


def _layer_opts(f):
    f = click.option("--position", type=int, default=None, help="Stack index (default: top)")(f)
    f = click.option("--name", "-n", default=None, help="Layer name")(f)
    return f


def _added(layer_dict):
    output(layer_dict, f"Added {layer_dict['type']} layer '{layer_dict['name']}'")


@layer.command("add-solid")
@click.argument("color")
@_layer_opts
@handle_error
def layer_add_solid(color, name, position):
    """Add a full-canvas color fill layer."""
    _added(_mutate("add solid", lambda p: layer_mod.add_solid(p, color, name, position)))


@layer.command("add-shape")
@click.argument("shape", type=click.Choice(layer_mod.SHAPES))
@click.option("--x", type=int, required=True)
@click.option("--y", type=int, required=True)
@click.option("--width", type=int, required=True)
@click.option("--height", type=int, required=True)
@click.option("--color", "-c", default="#000000")
@_layer_opts
@handle_error
def layer_add_shape(shape, x, y, width, height, color, name, position):
    """Add a filled rectangle or ellipse."""
    _added(_mutate("add shape", lambda p: layer_mod.add_shape(p, shape, x, y, width, height, color, name, position)))


@layer.command("add-text")
@click.argument("text")
@click.option("--x", type=int, required=True, help="Anchor x (left/center/right edge per --align)")
@click.option("--y", type=int, required=True, help="Baseline y of the first line")
@click.option("--size", "-s", type=float, default=48, help="Font size in px")
@click.option("--color", "-c", default="#000000")
@click.option("--font", "-f", default=None, help="PostScript font name (see 'backend fonts')")
@click.option("--align", type=click.Choice(layer_mod.ALIGNMENTS), default="left")
@click.option("--bold", is_flag=True)
@click.option("--italic", is_flag=True)
@click.option("--tracking", type=int, default=0)
@click.option("--leading", type=float, default=None)
@_layer_opts
@handle_error
def layer_add_text(text, x, y, size, color, font, align, bold, italic, tracking, leading, name, position):
    """Add a Photoshop text layer. Use \\n in TEXT for line breaks."""
    text = text.replace("\\n", "\n")
    _added(_mutate("add text", lambda p: layer_mod.add_text(
        p, text, x, y, size, color, font, align, bold, italic, tracking, leading, name, position)))


@layer.command("add-image")
@click.argument("path")
@click.option("--x", type=int, default=0)
@click.option("--y", type=int, default=0)
@click.option("--width", type=int, default=None, help="Scale to width (keeps aspect if --height omitted)")
@click.option("--height", type=int, default=None)
@_layer_opts
@handle_error
def layer_add_image(path, x, y, width, height, name, position):
    """Add an image file (any format Photoshop opens) as a layer."""
    _added(_mutate("add image", lambda p: layer_mod.add_image(p, path, x, y, width, height, name, position)))


@layer.command("add-gradient")
@click.argument("colors", nargs=-1, required=True)
@click.option("--angle", type=float, default=90)
@click.option("--style", type=click.Choice(layer_mod.GRADIENT_STYLES), default="linear")
@_layer_opts
@handle_error
def layer_add_gradient(colors, angle, style, name, position):
    """Add a gradient fill layer through 2+ COLORS."""
    _added(_mutate("add gradient", lambda p: layer_mod.add_gradient(p, list(colors), angle, style, name, position)))


@layer.command("list")
@handle_error
def layer_list():
    """List layers bottom to top."""
    output(layer_mod.list_layers(get_session().get_project()))


@layer.command("remove")
@click.argument("index", type=int)
@handle_error
def layer_remove(index):
    """Remove a layer."""
    removed = _mutate(f"remove layer {index}", lambda p: layer_mod.remove_layer(p, index))
    output(removed, f"Removed layer '{removed['name']}'")


@layer.command("duplicate")
@click.argument("index", type=int)
@handle_error
def layer_duplicate(index):
    """Duplicate a layer (copy placed above the original)."""
    output(_mutate(f"duplicate layer {index}", lambda p: layer_mod.duplicate_layer(p, index)), "Duplicated")


@layer.command("move")
@click.argument("index", type=int)
@click.argument("to", type=int)
@handle_error
def layer_move(index, to):
    """Move a layer to a new stack position."""
    output(_mutate(f"move layer {index}->{to}", lambda p: layer_mod.move_layer(p, index, to)), f"Moved to {to}")


@layer.command("set")
@click.argument("index", type=int)
@click.argument("prop")
@click.argument("value")
@handle_error
def layer_set(index, prop, value):
    """Set a layer property (name, opacity, blend_mode, visible, color, text, x, y, ...)."""
    output(_mutate(f"set {prop}", lambda p: layer_mod.set_property(p, index, prop, value)), f"Set {prop}={value}")


# ----------------------------------------------------------------- filter ----
@cli.group("filter")
def filter_group():
    """Photoshop filters & adjustments applied to a layer at render."""


@filter_group.command("list-available")
@click.option("--category", default=None)
@handle_error
def filter_list_available(category):
    """List available filters with parameters."""
    items = filt_mod.list_available(filt_mod.FILTERS)
    output([i for i in items if not category or i["category"] == category])


@filter_group.command("add")
@click.argument("name")
@click.option("--layer", "-l", "layer_index", type=int, required=True)
@click.option("--param", "-p", multiple=True, help="key=value (repeatable)")
@handle_error
def filter_add(name, layer_index, param):
    """Add a filter to a layer."""
    raw = filt_mod.parse_param_pairs(list(param))
    output(_mutate(f"add filter {name}", lambda p: filt_mod.add_filter(p, layer_index, name, raw)), f"Added {name}")


@filter_group.command("remove")
@click.argument("filter_index", type=int)
@click.option("--layer", "-l", "layer_index", type=int, required=True)
@handle_error
def filter_remove(filter_index, layer_index):
    """Remove a filter from a layer by its index."""
    output(_mutate("remove filter", lambda p: filt_mod.remove_filter(p, layer_index, filter_index)), "Removed")


@filter_group.command("list")
@click.option("--layer", "-l", "layer_index", type=int, required=True)
@handle_error
def filter_list(layer_index):
    """List filters on a layer (applied in order)."""
    output(layer_mod.get_layer(get_session().get_project(), layer_index).get("filters", []))


# ------------------------------------------------------------------ style ----
@cli.group()
def style():
    """Layer styles (drop shadow, stroke, outer glow, color overlay)."""


@style.command("list-available")
@handle_error
def style_list_available():
    """List available layer styles with parameters."""
    output(filt_mod.list_available(filt_mod.STYLES))


@style.command("add")
@click.argument("name")
@click.option("--layer", "-l", "layer_index", type=int, required=True)
@click.option("--param", "-p", multiple=True, help="key=value (repeatable)")
@handle_error
def style_add(name, layer_index, param):
    """Add (or replace) a layer style."""
    raw = filt_mod.parse_param_pairs(list(param))
    output(_mutate(f"add style {name}", lambda p: filt_mod.add_style(p, layer_index, name, raw)), f"Added {name}")


@style.command("remove")
@click.argument("name")
@click.option("--layer", "-l", "layer_index", type=int, required=True)
@handle_error
def style_remove(name, layer_index):
    """Remove a layer style."""
    output(_mutate(f"remove style {name}", lambda p: filt_mod.remove_style(p, layer_index, name)), "Removed")


# ----------------------------------------------------------------- export ----
@cli.group()
def export():
    """Render the project with Photoshop."""


@export.command("presets")
@handle_error
def export_presets():
    """List export presets."""
    output(export_mod.list_presets())


@export.command("render")
@click.argument("output_path")
@click.option("--preset", default=None, help="Export preset (default: from extension)")
@click.option("--quality", type=int, default=None, help="JPEG quality 0-12")
@click.option("--also", multiple=True, help="Additional output paths in the same render (repeatable)")
@click.option("--overwrite", is_flag=True)
@handle_error
def export_render(output_path, preset, quality, also, overwrite):
    """Render to OUTPUT_PATH (.png .jpg .tif .psd)."""
    outputs = [export_mod.build_output(output_path, preset, quality, overwrite)]
    outputs += [export_mod.build_output(p, None, quality, overwrite) for p in also]
    result = export_mod.render(get_session().get_project(), outputs)
    output(result if _json_output else result["outputs"], "Rendered with Photoshop:")


# -------------------------------------------------------------------- psd ----
@cli.group()
def psd():
    """Inspect, edit and export existing Photoshop documents."""


@psd.command("info")
@click.argument("path")
@handle_error
def psd_info(path):
    """Show document size, mode and full layer tree (index 0 = top)."""
    output(psd_mod.info(path))


@psd.command("export")
@click.argument("path")
@click.option("--output", "-o", "outputs", multiple=True, required=True, help="Output path (repeatable)")
@click.option("--quality", type=int, default=None)
@click.option("--overwrite", is_flag=True)
@handle_error
def psd_export(path, outputs, quality, overwrite):
    """Export a document to PNG/JPG/TIFF/PSD."""
    outs = [export_mod.build_output(o, None, quality, overwrite) for o in outputs]
    result = psd_mod.export(path, outs)
    output(result if _json_output else result["outputs"], "Exported:")


def _split_pairs(items: List[str], label: str) -> List[tuple]:
    pairs = []
    for item in items:
        if "=" not in item:
            raise ValueError(f"{label} expects LAYER=VALUE, got '{item}'")
        pairs.append(tuple(item.split("=", 1)))
    return pairs


@psd.command("edit")
@click.argument("path")
@click.option("--set-text", multiple=True, help="LAYER=TEXT  (\\n for new line)")
@click.option("--show", multiple=True, help="LAYER to make visible")
@click.option("--hide", multiple=True, help="LAYER to hide")
@click.option("--opacity", multiple=True, help="LAYER=0-100")
@click.option("--replace", multiple=True, help="SMART_OBJECT_LAYER=IMAGE_PATH")
@click.option("--output", "-o", "outputs", multiple=True, help="Output path (repeatable)")
@click.option("--in-place", is_flag=True, help="Save changes back into the original file")
@click.option("--overwrite", is_flag=True)
@handle_error
def psd_edit(path, set_text, show, hide, opacity, replace, outputs, in_place, overwrite):
    """Apply edits to a PSD (layers by name or Group/Layer path) and save."""
    edits = [psd_mod.build_edit("set_text", l, text=t.replace("\\n", "\n")) for l, t in _split_pairs(set_text, "--set-text")]
    edits += [psd_mod.build_edit("set_visibility", l, visible=True) for l in show]
    edits += [psd_mod.build_edit("set_visibility", l, visible=False) for l in hide]
    edits += [psd_mod.build_edit("set_opacity", l, opacity=v) for l, v in _split_pairs(opacity, "--opacity")]
    edits += [psd_mod.build_edit("replace_smart_object", l, image=v) for l, v in _split_pairs(replace, "--replace")]
    outs = [export_mod.build_output(o, None, None, overwrite) for o in outputs]
    result = psd_mod.edit(path, edits, outs, in_place)
    output(result if _json_output else {"applied": result["applied"], "outputs": result["outputs"]}, "Edited:")


@psd.command("export-layers")
@click.argument("path")
@click.option("--out-dir", "-d", required=True)
@click.option("--format", "fmt", type=click.Choice(["png", "jpg", "tif"]), default="png")
@click.option("--trim", is_flag=True, help="Trim transparent pixels around each layer")
@click.option("--visible-only", is_flag=True, help="Skip layers that are hidden")
@handle_error
def psd_export_layers(path, out_dir, fmt, trim, visible_only):
    """Export every leaf layer to its own file."""
    result = psd_mod.export_layers(path, out_dir, fmt, trim, visible_only)
    output(result if _json_output else result["layers"], f"Exported {len(result['layers'])} layers:")


# ---------------------------------------------------------------- backend ----
@cli.group()
def backend():
    """Photoshop connection, fonts and scripting escape hatch."""


@backend.command("status")
@click.option("--connect", is_flag=True, help="Connect (launching Photoshop if needed) and query version")
@handle_error
def backend_status(connect):
    """Report Photoshop availability."""
    from cli_anything.photoshop.utils import photoshop_backend

    output(photoshop_backend.backend_status(connect))


@backend.command("fonts")
@click.option("--search", "-s", default="", help="Case-insensitive substring filter")
@click.option("--limit", type=int, default=50)
@handle_error
def backend_fonts(search, limit):
    """List installed fonts (use postscript_name with --font)."""
    output(psd_mod.fonts(search, limit))


@backend.command("documents")
@handle_error
def backend_documents():
    """List documents currently open in Photoshop."""
    output(psd_mod.open_documents())


@backend.command("run-jsx")
@click.argument("script_file", type=click.Path(exists=True, dir_okay=False))
@handle_error
def backend_run_jsx(script_file):
    """Run a raw ExtendScript file in Photoshop and print its result."""
    from cli_anything.photoshop.utils import photoshop_backend

    with open(script_file, "r", encoding="utf-8") as fh:
        result = photoshop_backend.run_jsx(fh.read())
    output({"result": result})


# ---------------------------------------------------------------- session ----
@cli.group()
def session():
    """Undo/redo and session state."""


@session.command("status")
@handle_error
def session_status():
    output(get_session().status())


@session.command("undo")
@handle_error
def session_undo():
    output({"undone": get_session().undo()}, "Undone")


@session.command("redo")
@handle_error
def session_redo():
    output({"redone": get_session().redo()}, "Redone")


@session.command("history")
@handle_error
def session_history():
    output(get_session().list_history())


# ---------------------------------------------------------------- preview ----
@cli.group()
def preview():
    """Publish preview-bundle/v1 snapshots rendered by Photoshop."""


@preview.command("recipes")
@handle_error
def preview_recipes():
    output(preview_mod.list_recipes())


@preview.command("capture")
@click.option("--recipe", default="full")
@click.option("--root", "root_dir", default=None, help="Bundle root (default: next to project)")
@click.option("--force", is_flag=True, help="Ignore cache and re-render")
@handle_error
def preview_capture(recipe, root_dir, force):
    """Render the current project into a new (or cached) preview bundle."""
    sess = get_session()
    manifest = preview_mod.capture(sess.get_project(), recipe, sess.project_path, root_dir, force)
    output(manifest, "Preview bundle:")


@preview.command("latest")
@click.option("--recipe", default=None)
@click.option("--root", "root_dir", default=None)
@handle_error
def preview_latest(recipe, root_dir):
    """Show the newest existing preview bundle (no render)."""
    output(preview_mod.latest(recipe, get_session().project_path, root_dir))


# ------------------------------------------------------------------- repl ----
_REPL_COMMANDS = {
    "project": "new|open|save|info|profiles|json",
    "layer": "add-solid|add-shape|add-text|add-image|add-gradient|list|remove|duplicate|move|set",
    "filter": "list-available|add|remove|list",
    "style": "list-available|add|remove",
    "export": "presets|render",
    "psd": "info|export|edit|export-layers",
    "backend": "status|fonts|documents|run-jsx",
    "preview": "recipes|capture|latest",
    "session": "status|undo|redo|history",
    "help": "Show this help",
    "quit": "Exit REPL",
}


@cli.command()
@click.option("--project", "project_path", default=None)
@handle_error
def repl(project_path):
    """Interactive REPL (default when no command is given)."""
    from cli_anything.photoshop.utils.repl_skin import ReplSkin

    global _repl_mode
    if _repl_mode:
        return  # already inside a REPL
    _repl_mode = True
    skin = ReplSkin("photoshop", version=__version__)
    if project_path and not get_session().has_project():
        get_session().set_project(proj_mod.open_project(project_path), project_path)
    skin.print_banner()
    pt_session = skin.create_prompt_session()
    try:
        while True:
            try:
                sess = get_session()
                name = sess.project.get("name", "") if sess.has_project() else ""
                line = skin.get_input(pt_session, project_name=name, modified=sess._modified)
            except (EOFError, KeyboardInterrupt):
                break
            if not line:
                continue
            if line.lower() in ("quit", "exit", "q"):
                break
            if line.lower() == "help":
                skin.help(_REPL_COMMANDS)
                continue
            try:
                args = shlex.split(line, posix=True)
            except ValueError:
                args = line.split()
            try:
                cli.main(args, standalone_mode=False)
            except SystemExit:
                pass
            except click.exceptions.UsageError as exc:
                skin.warning(f"Usage error: {exc}")
            except Exception as exc:  # keep REPL alive
                skin.error(str(exc))
        if get_session()._modified:
            skin.warning("Unsaved changes were discarded (use 'project save').")
        skin.print_goodbye()
    finally:
        _repl_mode = False


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
