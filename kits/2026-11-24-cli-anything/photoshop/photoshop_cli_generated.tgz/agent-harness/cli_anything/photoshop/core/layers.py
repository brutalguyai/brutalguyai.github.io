"""Layer operations on the project model.

Layer types (each maps 1:1 to a Photoshop construct built at render time):
    solid     full-canvas pixel layer filled with a color
    shape     rectangle/ellipse selection filled on a pixel layer
    text      Photoshop point-text layer (real type engine, real fonts)
    image     a file opened in Photoshop and duplicated in as a pixel layer
    gradient  Photoshop gradient fill layer (linear/radial, N color stops)
"""

from __future__ import annotations

import copy
import os
from typing import Any, Dict, List, Optional

from cli_anything.photoshop.core.project import normalize_color

LAYER_TYPES = ("solid", "shape", "text", "image", "gradient")

# CLI name -> Photoshop DOM BlendMode enum member
BLEND_MODES: Dict[str, str] = {
    "normal": "NORMAL", "dissolve": "DISSOLVE",
    "darken": "DARKEN", "multiply": "MULTIPLY", "color_burn": "COLORBURN",
    "linear_burn": "LINEARBURN", "darker_color": "DARKERCOLOR",
    "lighten": "LIGHTEN", "screen": "SCREEN", "color_dodge": "COLORDODGE",
    "linear_dodge": "LINEARDODGE", "lighter_color": "LIGHTERCOLOR",
    "overlay": "OVERLAY", "soft_light": "SOFTLIGHT", "hard_light": "HARDLIGHT",
    "vivid_light": "VIVIDLIGHT", "linear_light": "LINEARLIGHT", "pin_light": "PINLIGHT",
    "hard_mix": "HARDMIX", "difference": "DIFFERENCE", "exclusion": "EXCLUSION",
    "subtract": "SUBTRACT", "divide": "DIVIDE", "hue": "HUE", "saturation": "SATURATION",
    "color": "COLORBLEND", "luminosity": "LUMINOSITY",
}

ALIGNMENTS = ("left", "center", "right")
SHAPES = ("rect", "ellipse")
GRADIENT_STYLES = ("linear", "radial")

# Properties settable via ``layer set`` with their coercion
_SETTABLE = {
    "name": str, "visible": "bool", "opacity": "pct", "fill_opacity": "pct",
    "blend_mode": "blend", "offset_x": int, "offset_y": int,
    # type specific
    "color": "color", "text": str, "size": float, "font": str, "align": "align",
    "bold": "bool", "italic": "bool", "tracking": int, "leading": float,
    "x": int, "y": int, "width": int, "height": int, "angle": float,
    "shape": "shape", "style": "gradient_style", "path": "path",
}


def _coerce_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in ("1", "true", "yes", "on"):
        return True
    if text in ("0", "false", "no", "off"):
        return False
    raise ValueError(f"Expected a boolean (true/false), got '{value}'")


def _coerce(prop: str, value: Any) -> Any:
    kind = _SETTABLE[prop]
    if kind == "bool":
        return _coerce_bool(value)
    if kind == "pct":
        v = float(value)
        if not 0 <= v <= 100:
            raise ValueError(f"{prop} must be between 0 and 100, got {v}")
        return v
    if kind == "blend":
        if value not in BLEND_MODES:
            raise ValueError(f"Unknown blend mode '{value}'. Available: {', '.join(BLEND_MODES)}")
        return value
    if kind == "color":
        return normalize_color(value)
    if kind == "align":
        if value not in ALIGNMENTS:
            raise ValueError(f"align must be one of {ALIGNMENTS}")
        return value
    if kind == "shape":
        if value not in SHAPES:
            raise ValueError(f"shape must be one of {SHAPES}")
        return value
    if kind == "gradient_style":
        if value not in GRADIENT_STYLES:
            raise ValueError(f"style must be one of {GRADIENT_STYLES}")
        return value
    if kind == "path":
        return _resolve_image(value)
    try:
        return kind(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid value for {prop}: '{value}'") from exc


def _resolve_image(path: str) -> str:
    full = os.path.abspath(os.path.expanduser(path))
    if not os.path.isfile(full):
        raise FileNotFoundError(f"Image file not found: {path}")
    return full


def _base_layer(project: Dict[str, Any], layer_type: str, name: Optional[str]) -> Dict[str, Any]:
    layer_id = project.get("next_layer_id", 1)
    project["next_layer_id"] = layer_id + 1
    return {
        "id": layer_id,
        "type": layer_type,
        "name": name or f"{layer_type.capitalize()} {layer_id}",
        "visible": True,
        "opacity": 100.0,
        "fill_opacity": 100.0,
        "blend_mode": "normal",
        "offset_x": 0,
        "offset_y": 0,
        "filters": [],
        "styles": [],
    }


def _insert(project: Dict[str, Any], layer: Dict[str, Any], position: Optional[int]) -> Dict[str, Any]:
    layers = project["layers"]
    if position is None or position >= len(layers):
        layers.append(layer)
    else:
        if position < 0:
            raise ValueError(f"Position must be >= 0, got {position}")
        layers.insert(position, layer)
    return layer


def _check_box(width: int, height: int) -> None:
    if width < 1 or height < 1:
        raise ValueError(f"Width and height must be positive: {width}x{height}")


def add_solid(project, color: str, name: Optional[str] = None, position: Optional[int] = None):
    layer = _base_layer(project, "solid", name)
    layer["color"] = normalize_color(color)
    return _insert(project, layer, position)


def add_shape(project, shape: str, x: int, y: int, width: int, height: int, color: str,
              name: Optional[str] = None, position: Optional[int] = None):
    if shape not in SHAPES:
        raise ValueError(f"shape must be one of {SHAPES}")
    _check_box(width, height)
    layer = _base_layer(project, "shape", name)
    layer.update({"shape": shape, "x": int(x), "y": int(y), "width": int(width),
                  "height": int(height), "color": normalize_color(color)})
    return _insert(project, layer, position)


def add_text(project, text: str, x: int, y: int, size: float = 48, color: str = "#000000",
             font: Optional[str] = None, align: str = "left", bold: bool = False, italic: bool = False,
             tracking: int = 0, leading: Optional[float] = None, name: Optional[str] = None,
             position: Optional[int] = None):
    if not text:
        raise ValueError("Text must not be empty")
    if size <= 0:
        raise ValueError(f"Font size must be positive: {size}")
    if align not in ALIGNMENTS:
        raise ValueError(f"align must be one of {ALIGNMENTS}")
    layer = _base_layer(project, "text", name or " ".join(text.split())[:30])
    layer.update({"text": text, "x": int(x), "y": int(y), "size": float(size),
                  "color": normalize_color(color), "font": font, "align": align,
                  "bold": bool(bold), "italic": bool(italic), "tracking": int(tracking),
                  "leading": leading})
    return _insert(project, layer, position)


def add_image(project, path: str, x: int = 0, y: int = 0, width: Optional[int] = None,
              height: Optional[int] = None, name: Optional[str] = None, position: Optional[int] = None):
    full = _resolve_image(path)
    if (width is not None and width < 1) or (height is not None and height < 1):
        raise ValueError("width/height must be positive when given")
    layer = _base_layer(project, "image", name or os.path.basename(full))
    layer.update({"path": full, "x": int(x), "y": int(y), "width": width, "height": height})
    return _insert(project, layer, position)


def add_gradient(project, colors: List[str], angle: float = 90, style: str = "linear",
                 name: Optional[str] = None, position: Optional[int] = None):
    if len(colors) < 2:
        raise ValueError("A gradient needs at least 2 colors")
    if style not in GRADIENT_STYLES:
        raise ValueError(f"style must be one of {GRADIENT_STYLES}")
    layer = _base_layer(project, "gradient", name)
    layer.update({"colors": [normalize_color(c) for c in colors], "angle": float(angle), "style": style})
    return _insert(project, layer, position)


def get_layer(project, index: int) -> Dict[str, Any]:
    layers = project["layers"]
    if not -len(layers) <= index < len(layers) or not layers:
        raise IndexError(f"Layer index {index} out of range (project has {len(layers)} layers)")
    return layers[index]


def remove_layer(project, index: int) -> Dict[str, Any]:
    get_layer(project, index)
    return project["layers"].pop(index)


def duplicate_layer(project, index: int) -> Dict[str, Any]:
    clone = copy.deepcopy(get_layer(project, index))
    clone["id"] = project.get("next_layer_id", 1)
    project["next_layer_id"] = clone["id"] + 1
    clone["name"] = f"{clone['name']} copy"
    project["layers"].insert(index + 1 if index >= 0 else len(project["layers"]) + index + 1, clone)
    return clone


def move_layer(project, index: int, to: int) -> Dict[str, Any]:
    layer = get_layer(project, index)
    layers = project["layers"]
    if not 0 <= to < len(layers):
        raise IndexError(f"Target position {to} out of range (0..{len(layers) - 1})")
    layers.pop(index)
    layers.insert(to, layer)
    return layer


_COMMON_PROPS = {"name", "visible", "opacity", "fill_opacity", "blend_mode", "offset_x", "offset_y"}
TYPE_PROPS: Dict[str, set] = {
    "solid": {"color"},
    "shape": {"shape", "x", "y", "width", "height", "color"},
    "text": {"text", "x", "y", "size", "color", "font", "align", "bold", "italic", "tracking", "leading"},
    "image": {"path", "x", "y", "width", "height"},
    "gradient": {"angle", "style"},
}


def _validate_value(prop: str, value: Any) -> None:
    if prop in ("name", "text") and not str(value).strip():
        raise ValueError(f"{prop} must not be empty")
    if prop in ("width", "height", "size", "leading") and value <= 0:
        raise ValueError(f"{prop} must be positive, got {value}")


def set_property(project, index: int, prop: str, value: Any) -> Dict[str, Any]:
    layer = get_layer(project, index)
    if prop not in _SETTABLE:
        raise ValueError(f"Unknown property '{prop}'. Settable: {', '.join(sorted(_SETTABLE))}")
    allowed = _COMMON_PROPS | TYPE_PROPS.get(layer["type"], set())
    if prop not in allowed:
        raise ValueError(f"Property '{prop}' does not apply to {layer['type']} layers. "
                         f"Allowed: {', '.join(sorted(allowed))}")
    coerced = _coerce(prop, value)
    _validate_value(prop, coerced)
    layer[prop] = coerced
    return layer


def list_layers(project) -> List[Dict[str, Any]]:
    return [{"index": i, **{k: v for k, v in l.items() if k not in ("filters", "styles")},
             "filters": [f["name"] for f in l.get("filters", [])],
             "styles": [s["name"] for s in l.get("styles", [])]}
            for i, l in enumerate(project["layers"])]
