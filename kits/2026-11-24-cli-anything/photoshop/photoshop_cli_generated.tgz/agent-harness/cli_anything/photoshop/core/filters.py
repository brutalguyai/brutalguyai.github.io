"""Filter / adjustment and layer-style registries.

Every entry here has a render mapping in ``jsx/harness.jsx``
(``__applyFilter`` / ``__styleDesc``) that calls the real Photoshop
filter, adjustment or layer effect. No entry is project-only.
"""

from __future__ import annotations

from typing import Any, Dict, List

from cli_anything.photoshop.core.layers import get_layer
from cli_anything.photoshop.core.project import normalize_color


def _num(default, lo, hi, kind="float"):
    return {"type": kind, "default": default, "min": lo, "max": hi}


def _choice(default, choices):
    return {"type": "choice", "default": default, "choices": list(choices)}


_BOOL_FALSE = {"type": "bool", "default": False}

FILTERS: Dict[str, Dict[str, Any]] = {
    "gaussian_blur": {"category": "blur", "description": "Filter > Blur > Gaussian Blur",
                      "params": {"radius": _num(5.0, 0.1, 250.0)}},
    "motion_blur": {"category": "blur", "description": "Filter > Blur > Motion Blur",
                    "params": {"angle": _num(0, -360, 360, "int"), "radius": _num(10, 1, 999, "int")}},
    "unsharp_mask": {"category": "sharpen", "description": "Filter > Sharpen > Unsharp Mask",
                     "params": {"amount": _num(100, 1, 500, "int"), "radius": _num(1.0, 0.1, 250.0),
                                "threshold": _num(0, 0, 255, "int")}},
    "sharpen": {"category": "sharpen", "description": "Filter > Sharpen > Sharpen", "params": {}},
    "sharpen_more": {"category": "sharpen", "description": "Filter > Sharpen > Sharpen More", "params": {}},
    "add_noise": {"category": "noise", "description": "Filter > Noise > Add Noise",
                  "params": {"amount": _num(10.0, 0.1, 400.0),
                             "distribution": _choice("uniform", ("uniform", "gaussian")),
                             "monochromatic": _BOOL_FALSE}},
    "median": {"category": "noise", "description": "Filter > Noise > Median",
               "params": {"radius": _num(3, 1, 500, "int")}},
    "high_pass": {"category": "other", "description": "Filter > Other > High Pass",
                  "params": {"radius": _num(10.0, 0.1, 250.0)}},
    "twirl": {"category": "distort", "description": "Filter > Distort > Twirl",
              "params": {"angle": _num(50, -999, 999, "int")}},
    "brightness_contrast": {"category": "adjustment", "description": "Image > Adjustments > Brightness/Contrast",
                            "params": {"brightness": _num(0, -150, 150, "int"),
                                       "contrast": _num(0, -50, 100, "int")}},
    "levels": {"category": "adjustment", "description": "Image > Adjustments > Levels",
               "params": {"input_low": _num(0, 0, 253, "int"), "input_high": _num(255, 2, 255, "int"),
                          "gamma": _num(1.0, 0.1, 9.99), "output_low": _num(0, 0, 255, "int"),
                          "output_high": _num(255, 0, 255, "int")}},
    "hue_saturation": {"category": "adjustment", "description": "Image > Adjustments > Hue/Saturation",
                       "params": {"hue": _num(0, -180, 180, "int"), "saturation": _num(0, -100, 100, "int"),
                                  "lightness": _num(0, -100, 100, "int"), "colorize": _BOOL_FALSE}},
    "color_balance": {"category": "adjustment", "description": "Image > Adjustments > Color Balance (midtones)",
                      "params": {"cyan_red": _num(0, -100, 100, "int"), "magenta_green": _num(0, -100, 100, "int"),
                                 "yellow_blue": _num(0, -100, 100, "int")}},
    "invert": {"category": "adjustment", "description": "Image > Adjustments > Invert", "params": {}},
    "desaturate": {"category": "adjustment", "description": "Image > Adjustments > Desaturate", "params": {}},
    "auto_levels": {"category": "adjustment", "description": "Image > Auto Tone", "params": {}},
    "auto_contrast": {"category": "adjustment", "description": "Image > Auto Contrast", "params": {}},
    "equalize": {"category": "adjustment", "description": "Image > Adjustments > Equalize", "params": {}},
    "posterize": {"category": "adjustment", "description": "Image > Adjustments > Posterize",
                  "params": {"levels": _num(4, 2, 255, "int")}},
    "threshold": {"category": "adjustment", "description": "Image > Adjustments > Threshold",
                  "params": {"level": _num(128, 1, 255, "int")}},
}

_COLOR = {"type": "color", "default": "#000000"}

STYLES: Dict[str, Dict[str, Any]] = {
    "drop_shadow": {"description": "Layer Style > Drop Shadow",
                    "params": {"color": _COLOR, "opacity": _num(75, 0, 100, "int"), "angle": _num(120, -180, 180, "int"),
                               "distance": _num(10, 0, 30000, "int"), "spread": _num(0, 0, 100, "int"),
                               "size": _num(10, 0, 250, "int")}},
    "stroke": {"description": "Layer Style > Stroke",
               "params": {"color": _COLOR, "size": _num(3, 1, 250, "int"), "opacity": _num(100, 0, 100, "int"),
                          "position": _choice("outside", ("outside", "inside", "center"))}},
    "outer_glow": {"description": "Layer Style > Outer Glow",
                   "params": {"color": {"type": "color", "default": "#ffffbe"}, "opacity": _num(75, 0, 100, "int"),
                              "spread": _num(0, 0, 100, "int"), "size": _num(20, 0, 250, "int")}},
    "color_overlay": {"description": "Layer Style > Color Overlay",
                      "params": {"color": {"type": "color", "default": "#ff0000"},
                                 "opacity": _num(100, 0, 100, "int")}},
}


def _coerce_param(name: str, spec: Dict[str, Any], raw: Any) -> Any:
    kind = spec["type"]
    if kind == "bool":
        if isinstance(raw, bool):
            return raw
        text = str(raw).lower()
        if text not in ("true", "false", "1", "0", "yes", "no"):
            raise ValueError(f"Parameter '{name}' expects true/false, got '{raw}'")
        return text in ("true", "1", "yes")
    if kind == "choice":
        if raw not in spec["choices"]:
            raise ValueError(f"Parameter '{name}' must be one of {spec['choices']}, got '{raw}'")
        return raw
    if kind == "color":
        return normalize_color(raw)
    try:
        value = int(raw) if kind == "int" else float(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Parameter '{name}' expects a number, got '{raw}'") from exc
    if not spec["min"] <= value <= spec["max"]:
        raise ValueError(f"Parameter '{name}' must be in [{spec['min']}, {spec['max']}], got {value}")
    return value


def resolve_params(registry: Dict[str, Dict[str, Any]], name: str, raw: Dict[str, Any]) -> Dict[str, Any]:
    """Validate raw params against a registry entry, filling defaults."""
    if name not in registry:
        raise ValueError(f"Unknown '{name}'. Available: {', '.join(sorted(registry))}")
    specs = registry[name]["params"]
    unknown = set(raw) - set(specs)
    if unknown:
        raise ValueError(f"Unknown parameter(s) for {name}: {', '.join(sorted(unknown))}. "
                         f"Valid: {', '.join(specs) or '(none)'}")
    return {p: _coerce_param(p, s, raw[p]) if p in raw else s["default"] for p, s in specs.items()}


def parse_param_pairs(pairs: List[str]) -> Dict[str, str]:
    """Parse ``["k=v", ...]`` into a dict."""
    out: Dict[str, str] = {}
    for pair in pairs:
        if "=" not in pair:
            raise ValueError(f"Parameter must be key=value, got '{pair}'")
        key, value = pair.split("=", 1)
        out[key.strip()] = value.strip()
    return out


def add_filter(project, layer_index: int, name: str, raw: Dict[str, Any]) -> Dict[str, Any]:
    layer = get_layer(project, layer_index)
    entry = {"name": name, "params": resolve_params(FILTERS, name, raw)}
    layer.setdefault("filters", []).append(entry)
    return entry


def remove_filter(project, layer_index: int, filter_index: int) -> Dict[str, Any]:
    filters = get_layer(project, layer_index).get("filters", [])
    if not 0 <= filter_index < len(filters):
        raise IndexError(f"Filter index {filter_index} out of range (layer has {len(filters)} filters)")
    return filters.pop(filter_index)


def add_style(project, layer_index: int, name: str, raw: Dict[str, Any]) -> Dict[str, Any]:
    layer = get_layer(project, layer_index)
    styles = layer.setdefault("styles", [])
    entry = {"name": name, **resolve_params(STYLES, name, raw)}
    # one instance per effect type (Photoshop single-instance semantics) — replace
    layer["styles"] = [s for s in styles if s["name"] != name] + [entry]
    return entry


def remove_style(project, layer_index: int, name: str) -> Dict[str, Any]:
    layer = get_layer(project, layer_index)
    styles = layer.get("styles", [])
    match = [s for s in styles if s["name"] == name]
    if not match:
        raise ValueError(f"Layer has no '{name}' style. Present: {[s['name'] for s in styles]}")
    layer["styles"] = [s for s in styles if s["name"] != name]
    return match[0]


def list_available(registry: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [{"name": n, "description": e["description"], "category": e.get("category"),
             "params": {p: {k: v for k, v in s.items()} for p, s in e["params"].items()}}
            for n, e in registry.items()]
