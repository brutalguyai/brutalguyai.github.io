"""Session management: current project, undo/redo, locked JSON persistence."""

from __future__ import annotations

import copy
import json
import os
from datetime import datetime
from typing import Any, Dict, List, Optional


def _lock(f) -> Optional[str]:
    """Acquire an exclusive lock; returns the lock flavour used (or None)."""
    try:
        import fcntl  # POSIX

        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        return "fcntl"
    except ImportError:
        pass
    except OSError:
        return None
    try:
        import msvcrt  # Windows

        f.seek(0)
        msvcrt.locking(f.fileno(), msvcrt.LK_LOCK, 1)
        return "msvcrt"
    except (ImportError, OSError):
        return None


def _unlock(f, flavour: Optional[str]) -> None:
    try:
        if flavour == "fcntl":
            import fcntl

            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        elif flavour == "msvcrt":
            import msvcrt

            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
    except OSError:
        pass


def _locked_save_json(path: str, data: Any, **dump_kwargs) -> None:
    """Write JSON under an exclusive lock, atomically.

    The lock is taken on a ``<path>.lock`` sidecar (opened ``r+``/``a`` so it is
    never truncated before locking); the content goes to a temp file that is
    ``os.replace``d over the target, so a crash can never leave a half-written
    project.
    """
    full = os.path.abspath(path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    payload = json.dumps(data, **dump_kwargs)
    with open(full + ".lock", "a+", encoding="utf-8") as lock_file:
        flavour = _lock(lock_file)
        try:
            tmp = f"{full}.{os.getpid()}.tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                fh.write(payload)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, full)
        finally:
            _unlock(lock_file, flavour)
    try:
        os.remove(full + ".lock")
    except OSError:
        pass  # another writer holds it; harmless


class Session:
    """Holds the active project with bounded undo/redo history."""

    MAX_UNDO = 50

    def __init__(self) -> None:
        self.project: Optional[Dict[str, Any]] = None
        self.project_path: Optional[str] = None
        self._undo_stack: List[Dict[str, Any]] = []
        self._redo_stack: List[Dict[str, Any]] = []
        self._modified = False

    def has_project(self) -> bool:
        return self.project is not None

    def get_project(self) -> Dict[str, Any]:
        if self.project is None:
            raise RuntimeError("No project loaded. Use 'project new' or 'project open' (or --project PATH).")
        return self.project

    def set_project(self, project: Dict[str, Any], path: Optional[str] = None) -> None:
        self.project = project
        self.project_path = path
        self._undo_stack.clear()
        self._redo_stack.clear()
        self._modified = False

    def snapshot(self, description: str = "") -> None:
        """Record the current state before a mutation."""
        if self.project is None:
            return
        self._undo_stack.append({"project": copy.deepcopy(self.project), "description": description,
                                 "timestamp": datetime.now().isoformat(), "was_modified": self._modified,
                                 "redo": list(self._redo_stack)})
        if len(self._undo_stack) > self.MAX_UNDO:
            self._undo_stack.pop(0)
        self._redo_stack.clear()
        self._modified = True

    def rollback(self) -> None:
        """Discard the most recent snapshot, restoring state (used when a mutation fails)."""
        if not self._undo_stack:
            return
        state = self._undo_stack.pop()
        self.project = state["project"]
        self._redo_stack = state.get("redo", [])
        self._modified = state.get("was_modified", False)

    def undo(self) -> str:
        if not self._undo_stack:
            raise RuntimeError("Nothing to undo.")
        state = self._undo_stack.pop()
        self._redo_stack.append({"project": copy.deepcopy(self.get_project()),
                                 "description": state["description"], "timestamp": datetime.now().isoformat()})
        self.project = state["project"]
        self._modified = True
        return state["description"]

    def redo(self) -> str:
        if not self._redo_stack:
            raise RuntimeError("Nothing to redo.")
        state = self._redo_stack.pop()
        self._undo_stack.append({"project": copy.deepcopy(self.get_project()),
                                 "description": state["description"], "timestamp": datetime.now().isoformat()})
        self.project = state["project"]
        self._modified = True
        return state["description"]

    def status(self) -> Dict[str, Any]:
        return {
            "has_project": self.project is not None,
            "project_path": self.project_path,
            "project_name": self.project.get("name") if self.project else None,
            "modified": self._modified,
            "undo_count": len(self._undo_stack),
            "redo_count": len(self._redo_stack),
        }

    def save_session(self, path: Optional[str] = None) -> str:
        project = self.get_project()
        save_path = path or self.project_path
        if not save_path:
            raise ValueError("No save path specified. Use 'project save -o PATH'.")
        project.setdefault("metadata", {})["modified"] = datetime.now().isoformat()
        _locked_save_json(save_path, project, indent=2, default=str)
        self.project_path = save_path
        self._modified = False
        return save_path

    def list_history(self) -> List[Dict[str, Any]]:
        return [{"index": i, "description": s["description"], "timestamp": s["timestamp"]}
                for i, s in enumerate(reversed(self._undo_stack))]
