"""Preview bundles (preview-bundle/v1) rendered by the real Photoshop.

``capture`` renders the current project through the normal export pipeline
into an immutable bundle directory. Bundles are cached by a fingerprint of the
render spec, so repeated captures of an unchanged project are free.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from cli_anything.photoshop import __version__
from cli_anything.photoshop.core import export as export_mod
from cli_anything.photoshop.utils import preview_bundle as pb

SOFTWARE = "photoshop"

RECIPES: Dict[str, Dict[str, Any]] = {
    "full": {"description": "Full-resolution flattened PNG of the project rendered by Photoshop",
             "preset": "png", "ext": ".png"},
    "quick": {"description": "Full-resolution JPEG (faster, smaller) rendered by Photoshop",
              "preset": "jpg-web", "ext": ".jpg"},
}


def list_recipes() -> List[Dict[str, Any]]:
    return [{"name": n, "description": r["description"]} for n, r in RECIPES.items()]


def capture(project: Dict[str, Any], recipe: str = "full", project_path: Optional[str] = None,
            root_dir: Optional[str] = None, force: bool = False) -> Dict[str, Any]:
    if recipe not in RECIPES:
        raise ValueError(f"Unknown recipe '{recipe}'. Available: {', '.join(RECIPES)}")
    spec = export_mod.build_render_spec(project)
    # include referenced image files' size+mtime so edited images invalidate the cache
    images = [pb.fingerprint_file(l["path"]) for l in project["layers"] if l.get("type") == "image"]
    fingerprint = pb.fingerprint_data({"spec": spec, "images": images})
    prep = pb.prepare_bundle(SOFTWARE, recipe, "static", fingerprint, options={"recipe": recipe},
                             harness_version=__version__, project_path=project_path,
                             root_dir=root_dir, force=force)
    if prep["cached"]:
        return {**prep["manifest"], "cached": True}

    cfg = RECIPES[recipe]
    image_path = os.path.join(prep["artifacts_dir"], "preview" + cfg["ext"])
    result = export_mod.render(project, [export_mod.build_output(image_path, preset=cfg["preset"])])
    doc = result["document"]
    artifact = pb.artifact_record(prep["bundle_dir"], image_path, "preview", "primary", "image",
                                  f"{project.get('name', 'untitled')} ({recipe})",
                                  width=doc["width"], height=doc["height"])
    summary = {"project": project.get("name"), "width": doc["width"], "height": doc["height"],
               "layer_count": doc["layer_count"],
               "layers": [{"name": l["name"], "kind": l["kind"]} for l in doc["layers"]]}
    manifest = pb.finalize_bundle(
        prep["bundle_dir"], prep["bundle_id"], "static", SOFTWARE, recipe,
        source={"project_path": os.path.abspath(project_path) if project_path else None,
                "fingerprint": fingerprint},
        artifacts=[artifact], summary=summary, cache_key=prep["cache_key"],
        generator={"name": "cli-anything-photoshop", "version": __version__, "renderer": "Adobe Photoshop (COM/ExtendScript)"},
        context={"truthfulness": "Rendered by the real Photoshop from the current project state."},
    )
    return {**manifest, "cached": False}


def latest(recipe: Optional[str] = None, project_path: Optional[str] = None,
           root_dir: Optional[str] = None) -> Dict[str, Any]:
    manifest = pb.find_latest_manifest(SOFTWARE, recipe=recipe, project_path=project_path, root_dir=root_dir)
    if manifest is None:
        raise RuntimeError("No preview bundle found. Run 'preview capture' first.")
    return manifest
