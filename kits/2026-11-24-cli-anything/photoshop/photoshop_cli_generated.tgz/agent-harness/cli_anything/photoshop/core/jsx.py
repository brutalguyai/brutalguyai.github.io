"""ExtendScript (JSX) script builder.

Pure functions: they only produce script text. Execution happens in
``utils/photoshop_backend.py``. Every script is the runtime library
(``jsx/harness.jsx``) + a ``__DATA`` literal + a body wrapped in a JSON
envelope with error capture and state restoration (dialogs, units, active doc,
temp documents closed without saving).
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional

_LIB_PATH = Path(__file__).resolve().parent.parent / "jsx" / "harness.jsx"

APP_INFO_BODY = """
return {
    version: app.version,
    name: app.name,
    scripting_version: $.version,
    open_documents: app.documents.length
};
"""


@lru_cache(maxsize=1)
def runtime_library() -> str:
    """Return the JSX runtime library source."""
    return _LIB_PATH.read_text(encoding="utf-8")


def js_literal(value: Any) -> str:
    """Encode a Python value as an ES3-safe JavaScript literal (via JSON)."""
    return json.dumps(value, ensure_ascii=True)


def to_ps_path(path: str) -> str:
    """Normalize a filesystem path for ExtendScript ``File`` (forward slashes)."""
    return str(Path(path).expanduser().resolve()).replace("\\", "/")


def wrap(body: str, data: Optional[Dict[str, Any]] = None) -> str:
    """Wrap a JSX body (which ``return``s a value) in the harness envelope."""
    return "\n".join([
        runtime_library(),
        f"var __DATA = {js_literal(data or {})};",
        "(function () {",
        "  var __prevDialogs = app.displayDialogs;",
        "  var __prevRuler = app.preferences.rulerUnits;",
        "  var __prevType = app.preferences.typeUnits;",
        "  var __prevDoc = null;",
        "  try { if (app.documents.length) __prevDoc = app.activeDocument; } catch (e0) {}",
        "  app.displayDialogs = DialogModes.NO;",
        "  app.preferences.rulerUnits = Units.PIXELS;",
        "  app.preferences.typeUnits = TypeUnits.PIXELS;",
        "  try {",
        "    var __r = (function () {",
        body,
        "    })();",
        "    return __json({ ok: true, result: __r });",
        "  } catch (e) {",
        "    return __json({ ok: false, error: String(e.message || e), line: e.line || null });",
        "  } finally {",
        "    for (var i = __tmpDocs.length - 1; i >= 0; i--) {",
        "      try { __tmpDocs[i].close(SaveOptions.DONOTSAVECHANGES); } catch (ec) {}",
        "    }",
        "    __tmpDocs = [];",
        "    try { if (__prevDoc) app.activeDocument = __prevDoc; } catch (ea) {}",
        # Release scratch-disk space held by our temp docs — only when the user has
        # no documents open, so their undo history is never purged.
        "    try { if (app.documents.length === 0) app.purge(PurgeTarget.ALLCACHES); } catch (ep) {}",
        "    app.preferences.rulerUnits = __prevRuler;",
        "    app.preferences.typeUnits = __prevType;",
        "    app.displayDialogs = __prevDialogs;",
        "  }",
        "})();",
    ])


# ------------------------------------------------------------ builders ----

def render_project_script(render_spec: Dict[str, Any], outputs: List[Dict[str, Any]]) -> str:
    """Script that builds the project as a real PS document and saves outputs."""
    return wrap("return __renderProject(__DATA.project, __DATA.outputs);",
                {"project": render_spec, "outputs": outputs})


def psd_info_script(path: str) -> str:
    return wrap("return __docInfo(__openDoc(__DATA.path));", {"path": to_ps_path(path)})


def psd_export_script(path: str, outputs: List[Dict[str, Any]]) -> str:
    body = "var d = __openDoc(__DATA.path); return { document: __docInfo(d), outputs: __saveAll(d, __DATA.outputs) };"
    return wrap(body, {"path": to_ps_path(path), "outputs": outputs})


def psd_edit_script(path: str, edits: List[Dict[str, Any]], outputs: List[Dict[str, Any]],
                    in_place: bool = False) -> str:
    body = """
var d = __openDoc(__DATA.path);
var applied = [];
for (var i = 0; i < __DATA.edits.length; i++) applied.push(__applyEdit(d, __DATA.edits[i]));
var saved = __saveAll(d, __DATA.outputs);
if (__DATA.in_place) { d.save(); saved.push({ path: d.fullName.fsName, format: 'psd', exists: true, bytes: d.fullName.length }); }
return { applied: applied, document: __docInfo(d), outputs: saved };
"""
    return wrap(body, {"path": to_ps_path(path), "edits": edits, "outputs": outputs, "in_place": in_place})


def psd_export_layers_script(path: str, out_dir: str, fmt: str, *, trim: bool, visible_only: bool,
                             quality: int = 10, compression: int = 6) -> str:
    body = "var d = __openDoc(__DATA.path); return { document: __docInfo(d), layers: __exportLayers(d, __DATA) };"
    return wrap(body, {
        "path": to_ps_path(path), "out_dir": to_ps_path(out_dir), "format": fmt,
        "trim": trim, "visible_only": visible_only, "quality": quality, "compression": compression,
    })


def fonts_script(query: str = "", limit: int = 50) -> str:
    body = """
var q = String(__DATA.query).toLowerCase(), out = [], total = app.fonts.length;
for (var i = 0; i < total && out.length < __DATA.limit; i++) {
    var f = app.fonts[i];
    var hay = (f.name + ' ' + f.postScriptName + ' ' + f.family).toLowerCase();
    if (!q || hay.indexOf(q) >= 0) out.push({ name: f.name, postscript_name: f.postScriptName, family: f.family, style: f.style });
}
return { total_installed: total, fonts: out };
"""
    return wrap(body, {"query": query, "limit": limit})


def open_documents_script() -> str:
    body = """
var out = [];
for (var i = 0; i < app.documents.length; i++) {
    var d = app.documents[i], p = null;
    try { p = d.fullName.fsName; } catch (e) {}
    out.push({ name: d.name, path: p, width: __px(d.width), height: __px(d.height), saved: d.saved });
}
return out;
"""
    return wrap(body)
