"""Render pipeline: project JSON -> ExtendScript -> real Photoshop document -> files.

The project is compiled into a normalized *render spec* (all defaults filled,
blend modes mapped to Photoshop enum names) and handed to
``__renderProject`` inside Photoshop. Photoshop itself builds every layer,
runs every filter/adjustment/layer style and writes PSD/PNG/JPG/TIFF.
"""

from __future__ import annotations

import copy
import os
from typing import Any, Dict, List, Optional

from cli_anything.photoshop.core import jsx
from cli_anything.photoshop.core.layers import BLEND_MODES

FORMATS = ("png", "jpg", "tif", "psd")
_EXT_TO_FORMAT = {".png": "png", ".jpg": "jpg", ".jpeg": "jpg", ".tif": "tif", ".tiff": "tif", ".psd": "psd"}

PRESETS: Dict[str, Dict[str, Any]] = {
    "png": {"format": "png", "compression": 6, "description": "Lossless PNG (flattened, keeps transparency)"},
    "png-fast": {"format": "png", "compression": 1, "description": "PNG with light compression (faster)"},
    "jpg-high": {"format": "jpg", "quality": 12, "description": "JPEG maximum quality"},
    "jpg": {"format": "jpg", "quality": 10, "description": "JPEG high quality (default)"},
    "jpg-web": {"format": "jpg", "quality": 7, "description": "JPEG medium quality for web"},
    "tif": {"format": "tif", "description": "TIFF, LZW compressed, flattened"},
    "psd": {"format": "psd", "description": "Layered Photoshop document (editable)"},
}


def format_from_path(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext not in _EXT_TO_FORMAT:
        raise ValueError(f"Cannot infer format from extension '{ext or '(none)'}'. "
                         f"Use one of: {', '.join(sorted(_EXT_TO_FORMAT))} or pass --preset.")
    return _EXT_TO_FORMAT[ext]


def build_output(path: str, preset: Optional[str] = None, quality: Optional[int] = None,
                 overwrite: bool = False) -> Dict[str, Any]:
    """Build an output descriptor for the JSX ``__saveAs`` helper."""
    if preset is not None and preset not in PRESETS:
        raise ValueError(f"Unknown preset '{preset}'. Available: {', '.join(PRESETS)}")
    settings = dict(PRESETS[preset]) if preset else {"format": format_from_path(path)}
    fmt = settings["format"]
    if preset and os.path.splitext(path)[1].lower() not in [e for e, f in _EXT_TO_FORMAT.items() if f == fmt]:
        raise ValueError(f"Output extension does not match preset '{preset}' ({fmt}): {path}")
    full = os.path.abspath(os.path.expanduser(path))
    if os.path.exists(full) and not overwrite:
        raise FileExistsError(f"Output exists: {full} (use --overwrite)")
    q = quality if quality is not None else settings.get("quality", 10)
    if not 0 <= int(q) <= 12:
        raise ValueError(f"JPEG quality must be 0-12 (Photoshop scale), got {q}")
    return {"path": jsx.to_ps_path(full), "format": fmt, "quality": int(q),
            "compression": int(settings.get("compression", 6))}


def build_render_spec(project: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize a project into the exact structure ``__renderProject`` expects."""
    spec_layers: List[Dict[str, Any]] = []
    for layer in project["layers"]:
        L = copy.deepcopy(layer)
        L.setdefault("visible", True)
        L.setdefault("opacity", 100.0)
        L.setdefault("fill_opacity", 100.0)
        L.setdefault("filters", [])
        L.setdefault("styles", [])
        blend = L.get("blend_mode", "normal")
        if blend not in BLEND_MODES:
            raise ValueError(f"Layer '{L.get('name')}' has unknown blend mode '{blend}'")
        L["blend_enum"] = BLEND_MODES[blend]
        if L["type"] == "image":
            if not os.path.isfile(L["path"]):
                raise FileNotFoundError(f"Layer '{L.get('name')}' image missing: {L['path']}")
            L["path"] = jsx.to_ps_path(L["path"])
        spec_layers.append(L)
    return {"name": project.get("name", "untitled"), "canvas": dict(project["canvas"]), "layers": spec_layers}


def render(project: Dict[str, Any], outputs: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Render the project in Photoshop and save every output. Verifies files on disk."""
    from cli_anything.photoshop.utils import photoshop_backend as backend

    if not outputs:
        raise ValueError("At least one output is required")
    script = jsx.render_project_script(build_render_spec(project), outputs)
    result = backend.run_jsx_json(script)
    return {**result, "outputs": verify_outputs(result.get("outputs", []))}


def verify_outputs(outputs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Confirm each reported file really exists, is non-empty and has the right magic bytes."""
    verified = []
    for out in outputs:
        path = out["path"]
        if not os.path.isfile(path) or os.path.getsize(path) == 0:
            raise RuntimeError(f"Photoshop reported success but output is missing/empty: {path}")
        actual = sniff_format(path)
        if actual != out["format"]:
            raise RuntimeError(f"Output {path} has format '{actual}', expected '{out['format']}'")
        verified.append({**out, "bytes": os.path.getsize(path), "verified_format": actual})
    return verified


def sniff_format(path: str) -> str:
    with open(path, "rb") as fh:
        head = fh.read(8)
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if head[:4] in (b"II*\x00", b"MM\x00*"):
        return "tif"
    if head.startswith(b"8BPS"):
        return "psd"
    return "unknown"


def list_presets() -> List[Dict[str, Any]]:
    return [{"name": n, **p} for n, p in PRESETS.items()]
