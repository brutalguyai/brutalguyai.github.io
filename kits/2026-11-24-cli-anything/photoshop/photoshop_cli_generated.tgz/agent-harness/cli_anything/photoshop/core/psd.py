"""Operations on existing Photoshop documents (PSD/PSB/any format PS opens).

These open the real file in Photoshop, act on it, save requested outputs and
close it without touching the original (unless ``in_place`` is requested).
"""

from __future__ import annotations

import os
from typing import Any, Dict, List

from cli_anything.photoshop.core import jsx
from cli_anything.photoshop.core.export import verify_outputs


def _require_file(path: str) -> str:
    full = os.path.abspath(os.path.expanduser(path))
    if not os.path.isfile(full):
        raise FileNotFoundError(f"File not found: {path}")
    return full


def _backend():
    from cli_anything.photoshop.utils import photoshop_backend

    return photoshop_backend


def info(path: str) -> Dict[str, Any]:
    return _backend().run_jsx_json(jsx.psd_info_script(_require_file(path)))


def export(path: str, outputs: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not outputs:
        raise ValueError("At least one output is required")
    result = _backend().run_jsx_json(jsx.psd_export_script(_require_file(path), outputs))
    return {**result, "outputs": verify_outputs(result["outputs"])}


def build_edit(op: str, layer: str, **fields: Any) -> Dict[str, Any]:
    """Validate and build one edit operation."""
    if not layer:
        raise ValueError("A layer name or path is required")
    if op == "set_text":
        if fields.get("text") is None:
            raise ValueError("set_text requires text")
        return {"op": op, "layer": layer, "text": str(fields["text"])}
    if op == "set_visibility":
        return {"op": op, "layer": layer, "visible": bool(fields["visible"])}
    if op == "set_opacity":
        value = float(fields["opacity"])
        if not 0 <= value <= 100:
            raise ValueError(f"opacity must be 0-100, got {value}")
        return {"op": op, "layer": layer, "opacity": value}
    if op == "replace_smart_object":
        return {"op": op, "layer": layer, "image": jsx.to_ps_path(_require_file(fields["image"]))}
    raise ValueError(f"Unknown edit op '{op}'")


def edit(path: str, edits: List[Dict[str, Any]], outputs: List[Dict[str, Any]],
         in_place: bool = False) -> Dict[str, Any]:
    if not edits:
        raise ValueError("No edits given")
    if not outputs and not in_place:
        raise ValueError("Give at least one output (-o) or --in-place to modify the original")
    if in_place and os.path.splitext(path)[1].lower() not in (".psd", ".psb"):
        raise ValueError("--in-place only supports .psd/.psb files (flat formats would lose layers); use -o instead")
    result = _backend().run_jsx_json(jsx.psd_edit_script(_require_file(path), edits, outputs, in_place))
    exported = result["outputs"][: len(outputs)]
    verified = verify_outputs(exported)
    if in_place:
        saved = result["outputs"][-1]
        if not os.path.isfile(saved["path"]) or os.path.getsize(saved["path"]) == 0:
            raise RuntimeError(f"In-place save failed: {saved['path']}")
        verified.append({**saved, "in_place": True})
    return {**result, "outputs": verified}


def export_layers(path: str, out_dir: str, fmt: str = "png", trim: bool = False,
                  visible_only: bool = False) -> Dict[str, Any]:
    if fmt not in ("png", "jpg", "tif"):
        raise ValueError("Layer export format must be png, jpg or tif")
    out_full = os.path.abspath(os.path.expanduser(out_dir))
    os.makedirs(out_full, exist_ok=True)
    script = jsx.psd_export_layers_script(_require_file(path), out_full, fmt, trim=trim, visible_only=visible_only)
    result = _backend().run_jsx_json(script)
    return {**result, "layers": verify_outputs(result["layers"])}


def fonts(query: str = "", limit: int = 50) -> Dict[str, Any]:
    if limit < 1:
        raise ValueError("limit must be >= 1")
    return _backend().run_jsx_json(jsx.fonts_script(query, limit))


def open_documents() -> List[Dict[str, Any]]:
    return _backend().run_jsx_json(jsx.open_documents_script())
