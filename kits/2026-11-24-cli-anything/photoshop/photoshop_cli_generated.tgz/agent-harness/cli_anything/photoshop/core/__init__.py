"""Photoshop CLI core modules."""
