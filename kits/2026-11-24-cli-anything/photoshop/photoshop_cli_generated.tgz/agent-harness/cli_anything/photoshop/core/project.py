"""Project model: a JSON description of a Photoshop document (``*.ps-cli.json``).

The project is the CLI's editable state. It is compiled to ExtendScript and
built by the real Photoshop at render time (see ``core/export.py``).
Layers are stored bottom-to-top (index 0 is the bottom-most layer).
"""

from __future__ import annotations

import json
import os
import re
from datetime import datetime
from typing import Any, Dict, List, Optional

PROJECT_VERSION = "1.0"
PROJECT_SUFFIX = ".ps-cli.json"

PROFILES: Dict[str, Dict[str, int]] = {
    "hd1080p": {"width": 1920, "height": 1080, "dpi": 72},
    "hd720p": {"width": 1280, "height": 720, "dpi": 72},
    "4k": {"width": 3840, "height": 2160, "dpi": 72},
    "youtube_thumb": {"width": 1280, "height": 720, "dpi": 72},
    "instagram_post": {"width": 1080, "height": 1080, "dpi": 72},
    "instagram_portrait": {"width": 1080, "height": 1350, "dpi": 72},
    "instagram_story": {"width": 1080, "height": 1920, "dpi": 72},
    "twitter_post": {"width": 1600, "height": 900, "dpi": 72},
    "twitter_header": {"width": 1500, "height": 500, "dpi": 72},
    "linkedin_banner": {"width": 1584, "height": 396, "dpi": 72},
    "og_image": {"width": 1200, "height": 630, "dpi": 72},
    "a4_300dpi": {"width": 2480, "height": 3508, "dpi": 300},
    "letter_300dpi": {"width": 2550, "height": 3300, "dpi": 300},
    "icon_512": {"width": 512, "height": 512, "dpi": 72},
}

_HEX_RE = re.compile(r"^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")


def normalize_color(value: str) -> str:
    """Validate a hex color and return it as lowercase ``#rrggbb``."""
    match = _HEX_RE.match(str(value).strip())
    if not match:
        raise ValueError(f"Invalid color '{value}'. Use hex like #ff8800 or #f80.")
    h = match.group(1).lower()
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return f"#{h}"


def normalize_background(value: str) -> str:
    if str(value).strip().lower() in ("transparent", "none"):
        return "transparent"
    return normalize_color(value)


def create_project(
    width: int = 1920,
    height: int = 1080,
    dpi: int = 72,
    background: str = "#ffffff",
    name: str = "untitled",
    profile: Optional[str] = None,
) -> Dict[str, Any]:
    """Create a new, empty project dict."""
    if profile:
        if profile not in PROFILES:
            raise ValueError(f"Unknown profile '{profile}'. Available: {', '.join(sorted(PROFILES))}")
        p = PROFILES[profile]
        width, height, dpi = p["width"], p["height"], p["dpi"]
    if width < 1 or height < 1 or width > 300000 or height > 300000:
        raise ValueError(f"Canvas dimensions must be between 1 and 300000 px: {width}x{height}")
    if dpi < 1 or dpi > 29999:
        raise ValueError(f"DPI must be between 1 and 29999: {dpi}")
    now = datetime.now().isoformat()
    return {
        "version": PROJECT_VERSION,
        "name": name,
        "canvas": {
            "width": int(width),
            "height": int(height),
            "dpi": int(dpi),
            "background": normalize_background(background),
        },
        "layers": [],
        "next_layer_id": 1,
        "metadata": {"created": now, "modified": now, "software": "cli-anything-photoshop 1.0"},
    }


def validate_project(project: Any, source: str = "<project>") -> Dict[str, Any]:
    """Raise ValueError if the dict is not a structurally valid project."""
    if not isinstance(project, dict):
        raise ValueError(f"Invalid project file {source}: top level must be an object")
    for key in ("version", "canvas", "layers"):
        if key not in project:
            raise ValueError(f"Invalid project file {source}: missing '{key}'")
    canvas = project["canvas"]
    if not isinstance(canvas, dict):
        raise ValueError(f"Invalid project file {source}: 'canvas' must be an object")
    for key in ("width", "height", "dpi"):
        if not isinstance(canvas.get(key), int) or canvas[key] < 1:
            raise ValueError(f"Invalid project file {source}: canvas.{key} must be a positive integer")
    if not isinstance(project["layers"], list):
        raise ValueError(f"Invalid project file {source}: 'layers' must be a list")
    project.setdefault("metadata", {})
    project.setdefault("next_layer_id", 1 + max([l.get("id", 0) for l in project["layers"]] or [0]))
    return project


def open_project(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        raise FileNotFoundError(f"Project file not found: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        try:
            data = json.load(fh)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Project file is not valid JSON: {path}: {exc}") from exc
    return validate_project(data, path)


def get_project_info(project: Dict[str, Any]) -> Dict[str, Any]:
    layers = project.get("layers", [])
    return {
        "name": project.get("name", "untitled"),
        "version": project.get("version"),
        "canvas": dict(project["canvas"]),
        "layer_count": len(layers),
        "layers": [
            {
                "index": i,
                "id": l.get("id"),
                "name": l.get("name"),
                "type": l.get("type"),
                "visible": l.get("visible", True),
                "opacity": l.get("opacity", 100),
                "blend_mode": l.get("blend_mode", "normal"),
                "filters": len(l.get("filters", [])),
                "styles": len(l.get("styles", [])),
            }
            for i, l in enumerate(layers)
        ],
        "metadata": project.get("metadata", {}),
    }


def list_profiles() -> List[Dict[str, Any]]:
    return [{"name": n, **p} for n, p in PROFILES.items()]
