# cli-anything-photoshop — Test Plan & Results

## Part 1 — Test Plan

### Test inventory

| File | Planned tests | Needs Photoshop |
|---|---|---|
| `test_core.py` | ~75 unit tests (synthetic data, CLI via Click `CliRunner` for offline commands) | No |
| `test_full_e2e.py` | ~35 E2E tests (real Photoshop renders, real PSD files, installed-CLI subprocess) | **Yes — hard dependency, never skipped** |

### Unit test plan (`test_core.py`)

| Module | Functions | Edge cases | ~Count |
|---|---|---|---|
| `core/project.py` | `create_project`, `normalize_color`, `normalize_background`, `validate_project`, `open_project`, `get_project_info`, `list_profiles` | short hex, invalid hex, unknown profile, zero/huge dims, bad DPI, missing keys, invalid JSON, missing file | 14 |
| `core/layers.py` | `add_solid/shape/text/image/gradient`, `get/remove/duplicate/move_layer`, `set_property`, `list_layers` | empty text, bad align/shape/style, <2 gradient colors, missing image, out-of-range index, unknown prop, bool/pct/blend coercion, id allocation | 20 |
| `core/filters.py` | `resolve_params`, `parse_param_pairs`, `add/remove_filter`, `add/remove_style`, `list_available` | defaults, range violations, unknown params, bad bool/choice/color, style replace semantics, missing style | 13 |
| `core/export.py` | `format_from_path`, `build_output`, `build_render_spec`, `sniff_format`, `verify_outputs`, `list_presets` | unknown ext, preset/extension mismatch, overwrite guard, quality range, blend enum mapping, missing image, wrong magic | 10 |
| `core/jsx.py` | `wrap`, `js_literal`, `to_ps_path`, script builders | quote/newline/unicode escaping, library + envelope present, data embedded | 6 |
| `core/session.py` | snapshot/undo/redo/rollback/history/save/status | empty stacks, MAX_UNDO cap, rollback restores redo + modified flag, save w/o path | 8 |
| `core/psd.py` | `build_edit` | each op, missing text, opacity range, unknown op, missing replacement image | 4 |
| `core/preview.py` | `list_recipes`, `capture` validation | unknown recipe | 2 |
| CLI (`CliRunner`) | help, `project new --json`, layer/filter/style mutations, auto-save, `--dry-run`, JSON error envelope + exit code, undo in a process | — | 8 |

### E2E test plan (`test_full_e2e.py`)

All renders go through the real Photoshop. Outputs are verified by **magic bytes**
and **pixel analysis** (Pillow/numpy read-back), and artifact paths are printed.

* **Layer types** — solid, rect, ellipse, text, image (position + scale), gradient (both ends differ),
  transparent background (alpha = 0).
* **Filters** — invert (exact inverse color), desaturate (R=G=B), threshold (only 0/255),
  gaussian blur (edge softened vs. hard edge), hue/saturation colorize, brightness/contrast.
* **Layer props** — 50% opacity (blended mid color), multiply blend, hidden layer absent.
* **Layer styles** — stroke color outside a shape, drop shadow darkening offset region.
* **Formats** — PNG/JPG/TIFF/PSD magic bytes; PSD re-opened by Photoshop has the expected layer tree.
* **PSD operations** on a fixture PSD built by Photoshop (group `Header` with text `Title`,
  a smart object `Product`, a duplicated name `Dup` in two groups): `info` tree, `set_text`
  by path, ambiguous-name error, hide/show, opacity, `replace_smart_object`, in-place save,
  `export-layers` (count, trim reduces size), non-text-layer error.
* **Backend** — status/connect version, fonts search, run-jsx, no documents leaked after operations.

### Realistic workflow scenarios

1. **YouTube thumbnail production** — *Simulates:* creator making a thumbnail.
   *Ops:* new(profile youtube_thumb) → gradient → photo layer scaled → hue/sat → bold text →
   stroke + drop shadow → render PNG + PSD. *Verified:* 1280×720, PSD has 5 layers incl. text
   layer with the right contents, text pixels white at the title center region, PNG magic.
2. **Template personalization batch** — *Simulates:* marketing producing per-customer
   banners from one PSD. *Ops:* for 3 names → `psd edit --set-text` → PNG. *Verified:* 3
   distinct outputs (different pixel hashes), original PSD unchanged.
3. **Iterative refinement with undo** — *Simulates:* designer exploring variants.
   *Ops:* add solid → add filter → undo → redo → change color → render. *Verified:*
   final pixel color equals the last chosen color after filter.
4. **Asset extraction** — *Simulates:* handing off layers to developers.
   *Ops:* `psd export-layers --trim`. *Verified:* one file per leaf layer, trimmed sizes ≤ canvas.
5. **Installed CLI pipeline** (subprocess, `_resolve_cli`) — project new → layers → filter →
   style → `export render` → `psd info` on the produced PSD → `preview capture` (cache hit on 2nd).
