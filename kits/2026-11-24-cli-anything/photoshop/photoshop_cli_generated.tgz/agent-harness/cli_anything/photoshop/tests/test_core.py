"""Unit tests — synthetic data only, no Photoshop required."""

from __future__ import annotations

import json
import os

import pytest
from click.testing import CliRunner

from cli_anything.photoshop.core import export as E
from cli_anything.photoshop.core import filters as F
from cli_anything.photoshop.core import jsx
from cli_anything.photoshop.core import layers as L
from cli_anything.photoshop.core import preview as PV
from cli_anything.photoshop.core import project as P
from cli_anything.photoshop.core import psd as PSD
from cli_anything.photoshop.core.session import Session


@pytest.fixture
def proj():
    return P.create_project(800, 600, name="t")


@pytest.fixture
def img(tmp_path):
    path = tmp_path / "pic.png"
    path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 32)
    return str(path)


# ------------------------------------------------------------- project ----
class TestProject:
    def test_create_defaults(self):
        p = P.create_project()
        assert p["canvas"] == {"width": 1920, "height": 1080, "dpi": 72, "background": "#ffffff"}
        assert p["layers"] == [] and p["next_layer_id"] == 1

    def test_create_profile(self):
        p = P.create_project(profile="instagram_story")
        assert (p["canvas"]["width"], p["canvas"]["height"]) == (1080, 1920)

    def test_unknown_profile(self):
        with pytest.raises(ValueError, match="Unknown profile"):
            P.create_project(profile="nope")

    @pytest.mark.parametrize("w,h", [(0, 10), (10, -1), (300001, 5)])
    def test_bad_dimensions(self, w, h):
        with pytest.raises(ValueError):
            P.create_project(w, h)

    def test_bad_dpi(self):
        with pytest.raises(ValueError, match="DPI"):
            P.create_project(dpi=0)

    def test_normalize_color_short(self):
        assert P.normalize_color("#F80") == "#ff8800"
        assert P.normalize_color("00FF00") == "#00ff00"

    @pytest.mark.parametrize("bad", ["red", "#12345", "#ggg", ""])
    def test_normalize_color_invalid(self, bad):
        with pytest.raises(ValueError):
            P.normalize_color(bad)

    def test_transparent_background(self):
        assert P.create_project(background="none")["canvas"]["background"] == "transparent"

    def test_open_missing(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            P.open_project(str(tmp_path / "x.json"))

    def test_open_invalid_json(self, tmp_path):
        f = tmp_path / "bad.json"
        f.write_text("{nope")
        with pytest.raises(ValueError, match="not valid JSON"):
            P.open_project(str(f))

    def test_validate_missing_key(self):
        with pytest.raises(ValueError, match="missing 'layers'"):
            P.validate_project({"version": "1", "canvas": {"width": 1, "height": 1, "dpi": 1}})

    def test_validate_bad_canvas(self):
        with pytest.raises(ValueError, match="canvas.width"):
            P.validate_project({"version": "1", "layers": [], "canvas": {"width": "x", "height": 1, "dpi": 1}})

    def test_validate_restores_next_id(self):
        p = P.validate_project({"version": "1", "layers": [{"id": 7}], "canvas": {"width": 1, "height": 1, "dpi": 1}})
        assert p["next_layer_id"] == 8

    def test_info_and_profiles(self, proj):
        L.add_solid(proj, "#123456")
        info = P.get_project_info(proj)
        assert info["layer_count"] == 1 and info["layers"][0]["type"] == "solid"
        assert any(pr["name"] == "youtube_thumb" for pr in P.list_profiles())


# -------------------------------------------------------------- layers ----
class TestLayers:
    def test_add_solid(self, proj):
        layer = L.add_solid(proj, "#abc")
        assert layer["color"] == "#aabbcc" and layer["id"] == 1 and proj["next_layer_id"] == 2

    def test_add_shape(self, proj):
        layer = L.add_shape(proj, "ellipse", 1, 2, 30, 40, "#000")
        assert (layer["shape"], layer["width"], layer["height"]) == ("ellipse", 30, 40)

    def test_add_shape_invalid(self, proj):
        with pytest.raises(ValueError):
            L.add_shape(proj, "star", 0, 0, 10, 10, "#000")
        with pytest.raises(ValueError):
            L.add_shape(proj, "rect", 0, 0, 0, 10, "#000")

    def test_add_text(self, proj):
        layer = L.add_text(proj, "Hi\nthere", 10, 20, size=30, align="center", bold=True)
        assert layer["name"] == "Hi there" and layer["bold"] is True and layer["size"] == 30.0

    @pytest.mark.parametrize("kwargs", [{"text": ""}, {"text": "a", "size": 0}, {"text": "a", "align": "justify"}])
    def test_add_text_invalid(self, proj, kwargs):
        args = {"text": "x", "x": 0, "y": 0, **kwargs}
        with pytest.raises(ValueError):
            L.add_text(proj, **args)

    def test_add_image(self, proj, img):
        layer = L.add_image(proj, img, 5, 6, width=100)
        assert os.path.isabs(layer["path"]) and layer["width"] == 100 and layer["height"] is None

    def test_add_image_missing(self, proj, tmp_path):
        with pytest.raises(FileNotFoundError):
            L.add_image(proj, str(tmp_path / "none.png"))

    def test_add_gradient(self, proj):
        layer = L.add_gradient(proj, ["#000", "#fff", "#f00"], 45, "radial")
        assert layer["colors"] == ["#000000", "#ffffff", "#ff0000"] and layer["style"] == "radial"

    def test_add_gradient_invalid(self, proj):
        with pytest.raises(ValueError):
            L.add_gradient(proj, ["#000"])
        with pytest.raises(ValueError):
            L.add_gradient(proj, ["#000", "#fff"], style="conic")

    def test_position_insert(self, proj):
        L.add_solid(proj, "#111")
        L.add_solid(proj, "#222", position=0)
        assert [l["color"] for l in proj["layers"]] == ["#222222", "#111111"]

    def test_get_layer_out_of_range(self, proj):
        with pytest.raises(IndexError):
            L.get_layer(proj, 0)

    def test_remove(self, proj):
        L.add_solid(proj, "#111")
        assert L.remove_layer(proj, 0)["color"] == "#111111" and proj["layers"] == []

    def test_duplicate_new_id(self, proj):
        L.add_solid(proj, "#111", name="a")
        clone = L.duplicate_layer(proj, 0)
        assert clone["name"] == "a copy" and clone["id"] != proj["layers"][0]["id"]
        assert proj["layers"][1] is clone

    def test_move(self, proj):
        for c in ("#111", "#222", "#333"):
            L.add_solid(proj, c)
        L.move_layer(proj, 0, 2)
        assert [l["color"][-1] for l in proj["layers"]] == ["2", "3", "1"]
        with pytest.raises(IndexError):
            L.move_layer(proj, 0, 5)

    def test_set_coercions(self, proj):
        L.add_text(proj, "a", 0, 0)
        assert L.set_property(proj, 0, "visible", "false")["visible"] is False
        assert L.set_property(proj, 0, "opacity", "55")["opacity"] == 55.0
        assert L.set_property(proj, 0, "blend_mode", "multiply")["blend_mode"] == "multiply"
        assert L.set_property(proj, 0, "color", "#0f0")["color"] == "#00ff00"
        assert L.set_property(proj, 0, "x", "12")["x"] == 12

    @pytest.mark.parametrize("prop,value", [("opacity", "150"), ("blend_mode", "glow"), ("visible", "maybe"),
                                            ("align", "top"), ("bogus", "1"), ("x", "abc")])
    def test_set_invalid(self, proj, prop, value):
        L.add_text(proj, "a", 0, 0)
        with pytest.raises(ValueError):
            L.set_property(proj, 0, prop, value)

    def test_list_layers(self, proj):
        L.add_solid(proj, "#111")
        F.add_filter(proj, 0, "invert", {})
        listing = L.list_layers(proj)
        assert listing[0]["index"] == 0 and listing[0]["filters"] == ["invert"]

    def test_blend_modes_complete(self):
        assert len(L.BLEND_MODES) == 27 and L.BLEND_MODES["color"] == "COLORBLEND"


# ------------------------------------------------------------- filters ----
class TestFilters:
    def test_defaults(self):
        assert F.resolve_params(F.FILTERS, "gaussian_blur", {}) == {"radius": 5.0}

    def test_coercion(self):
        params = F.resolve_params(F.FILTERS, "add_noise", {"amount": "12.5", "monochromatic": "true",
                                                            "distribution": "gaussian"})
        assert params == {"amount": 12.5, "distribution": "gaussian", "monochromatic": True}

    @pytest.mark.parametrize("name,raw", [("gaussian_blur", {"radius": "999"}), ("gaussian_blur", {"radius": "x"}),
                                          ("gaussian_blur", {"sigma": "1"}), ("add_noise", {"distribution": "pink"}),
                                          ("hue_saturation", {"colorize": "kinda"}), ("nope", {})])
    def test_invalid(self, name, raw):
        with pytest.raises(ValueError):
            F.resolve_params(F.FILTERS, name, raw)

    def test_parse_pairs(self):
        assert F.parse_param_pairs(["a=1", "b = x=y"]) == {"a": "1", "b": "x=y"}
        with pytest.raises(ValueError):
            F.parse_param_pairs(["novalue"])

    def test_add_remove_filter(self, proj):
        L.add_solid(proj, "#111")
        F.add_filter(proj, 0, "posterize", {"levels": "6"})
        assert proj["layers"][0]["filters"] == [{"name": "posterize", "params": {"levels": 6}}]
        F.remove_filter(proj, 0, 0)
        assert proj["layers"][0]["filters"] == []
        with pytest.raises(IndexError):
            F.remove_filter(proj, 0, 0)

    def test_style_replace_semantics(self, proj):
        L.add_solid(proj, "#111")
        F.add_style(proj, 0, "stroke", {"size": "2"})
        F.add_style(proj, 0, "stroke", {"size": "8", "color": "#f00"})
        styles = proj["layers"][0]["styles"]
        assert len(styles) == 1 and styles[0]["size"] == 8 and styles[0]["color"] == "#ff0000"

    def test_style_remove(self, proj):
        L.add_solid(proj, "#111")
        F.add_style(proj, 0, "drop_shadow", {})
        assert F.remove_style(proj, 0, "drop_shadow")["name"] == "drop_shadow"
        with pytest.raises(ValueError):
            F.remove_style(proj, 0, "drop_shadow")

    def test_style_bad_color(self, proj):
        L.add_solid(proj, "#111")
        with pytest.raises(ValueError):
            F.add_style(proj, 0, "color_overlay", {"color": "blue"})

    def test_every_filter_has_jsx_mapping(self):
        lib = jsx.runtime_library()
        for name in F.FILTERS:
            assert f"case '{name}'" in lib, f"filter {name} has no render mapping"
        for name in F.STYLES:
            assert f"case '{name}'" in lib, f"style {name} has no render mapping"

    def test_list_available(self):
        items = F.list_available(F.FILTERS)
        assert {"name", "description", "category", "params"} <= set(items[0])


# -------------------------------------------------------------- export ----
class TestExport:
    @pytest.mark.parametrize("path,fmt", [("a.PNG", "png"), ("a.jpeg", "jpg"), ("a.tiff", "tif"), ("x/y.psd", "psd")])
    def test_format_from_path(self, path, fmt):
        assert E.format_from_path(path) == fmt

    def test_format_unknown(self):
        with pytest.raises(ValueError):
            E.format_from_path("a.gif")

    def test_build_output(self, tmp_path):
        out = E.build_output(str(tmp_path / "o.jpg"), quality=8)
        assert out["format"] == "jpg" and out["quality"] == 8 and "\\" not in out["path"]

    def test_build_output_guards(self, tmp_path):
        existing = tmp_path / "o.png"
        existing.write_bytes(b"x")
        with pytest.raises(FileExistsError):
            E.build_output(str(existing))
        assert E.build_output(str(existing), overwrite=True)["format"] == "png"
        with pytest.raises(ValueError, match="does not match"):
            E.build_output(str(tmp_path / "o.png"), preset="jpg", overwrite=True)
        with pytest.raises(ValueError, match="quality"):
            E.build_output(str(tmp_path / "q.jpg"), quality=13)
        with pytest.raises(ValueError, match="Unknown preset"):
            E.build_output(str(tmp_path / "q.jpg"), preset="webp")

    def test_render_spec(self, proj, img):
        L.add_solid(proj, "#111")
        L.add_image(proj, img)
        L.set_property(proj, 0, "blend_mode", "soft_light")
        spec = E.build_render_spec(proj)
        assert spec["layers"][0]["blend_enum"] == "SOFTLIGHT"
        assert "\\" not in spec["layers"][1]["path"]
        assert "blend_enum" not in proj["layers"][0]  # original untouched

    def test_render_spec_missing_image(self, proj, img):
        L.add_image(proj, img)
        os.remove(img)
        with pytest.raises(FileNotFoundError):
            E.build_render_spec(proj)

    def test_sniff_and_verify(self, tmp_path):
        png = tmp_path / "a.png"
        png.write_bytes(b"\x89PNG\r\n\x1a\nrest")
        assert E.sniff_format(str(png)) == "png"
        assert E.verify_outputs([{"path": str(png), "format": "png"}])[0]["verified_format"] == "png"
        with pytest.raises(RuntimeError, match="expected 'jpg'"):
            E.verify_outputs([{"path": str(png), "format": "jpg"}])
        with pytest.raises(RuntimeError, match="missing"):
            E.verify_outputs([{"path": str(tmp_path / "none.png"), "format": "png"}])

    def test_presets(self):
        assert {p["name"] for p in E.list_presets()} >= {"png", "jpg", "psd", "tif"}


# ----------------------------------------------------------------- jsx ----
class TestJsx:
    def test_literal_escaping(self):
        lit = jsx.js_literal({"t": 'a"b\n\u00e9</script>'})
        assert json.loads(lit)["t"] == 'a"b\n\u00e9</script>' and "\n" not in lit and "\\u00e9" in lit

    def test_wrap_structure(self):
        script = jsx.wrap("return 1;", {"k": 1})
        assert "function __json" in script and 'var __DATA = {"k": 1};' in script
        assert "DialogModes.NO" in script and "__tmpDocs" in script and script.rstrip().endswith("})();")

    def test_to_ps_path(self, tmp_path):
        assert "\\" not in jsx.to_ps_path(str(tmp_path / "a b.png"))

    def test_render_script_embeds_data(self, proj):
        L.add_text(proj, "Quote \"me\"", 1, 2)
        script = jsx.render_project_script(E.build_render_spec(proj), [{"path": "C:/o.png", "format": "png"}])
        assert "__renderProject(__DATA.project, __DATA.outputs)" in script and 'Quote \\"me\\"' in script

    def test_builders(self, tmp_path):
        f = tmp_path / "x.psd"
        f.write_bytes(b"8BPS")
        assert "__docInfo(__openDoc" in jsx.psd_info_script(str(f))
        assert "__applyEdit" in jsx.psd_edit_script(str(f), [], [], True)
        assert '"trim": true' in jsx.psd_export_layers_script(str(f), str(tmp_path), "png", trim=True, visible_only=False)
        assert '"query": "ari"' in jsx.fonts_script("ari", 5)

    def test_app_info_body(self):
        assert "app.version" in jsx.APP_INFO_BODY


# ------------------------------------------------------------- session ----
class TestSession:
    def test_no_project(self):
        with pytest.raises(RuntimeError, match="No project"):
            Session().get_project()

    def test_undo_redo(self, proj):
        s = Session()
        s.set_project(proj)
        s.snapshot("add")
        L.add_solid(s.project, "#111")
        assert s.undo() == "add" and s.project["layers"] == []
        assert s.redo() == "add" and len(s.project["layers"]) == 1

    def test_empty_stacks(self, proj):
        s = Session()
        s.set_project(proj)
        with pytest.raises(RuntimeError):
            s.undo()
        with pytest.raises(RuntimeError):
            s.redo()

    def test_snapshot_clears_redo(self, proj):
        s = Session()
        s.set_project(proj)
        s.snapshot("a")
        s.undo()
        s.snapshot("b")
        assert s.status()["redo_count"] == 0

    def test_rollback(self, proj):
        s = Session()
        s.set_project(proj)
        s.snapshot("a")
        s.undo()
        s._modified = False
        s.snapshot("fail")
        L.add_solid(s.project, "#111")
        s.rollback()
        assert s.project["layers"] == [] and s.status()["redo_count"] == 1 and s._modified is False

    def test_max_undo(self, proj):
        s = Session()
        s.set_project(proj)
        for i in range(Session.MAX_UNDO + 5):
            s.snapshot(str(i))
        assert len(s.list_history()) == Session.MAX_UNDO and s.list_history()[0]["description"] == "54"

    def test_save_roundtrip(self, proj, tmp_path):
        s = Session()
        s.set_project(proj)
        with pytest.raises(ValueError):
            s.save_session()
        path = str(tmp_path / "sub" / "p.json")
        s.save_session(path)
        assert P.open_project(path)["name"] == "t" and not s._modified
        # second save shorter content must not leave trailing garbage
        s.project["name"] = "x"
        s.save_session()
        assert json.load(open(path))["name"] == "x"


# ------------------------------------------------------------ psd/preview ----
class TestPsdAndPreview:
    def test_build_edit_ops(self, img):
        assert PSD.build_edit("set_text", "A", text="x") == {"op": "set_text", "layer": "A", "text": "x"}
        assert PSD.build_edit("set_visibility", "A", visible=0)["visible"] is False
        assert PSD.build_edit("replace_smart_object", "A", image=img)["image"].endswith("pic.png")

    @pytest.mark.parametrize("op,fields", [("set_text", {}), ("set_opacity", {"opacity": 101}), ("explode", {})])
    def test_build_edit_invalid(self, op, fields):
        with pytest.raises(ValueError):
            PSD.build_edit(op, "A", **fields)

    def test_build_edit_requires_layer_and_image(self, tmp_path):
        with pytest.raises(ValueError):
            PSD.build_edit("set_text", "", text="x")
        with pytest.raises(FileNotFoundError):
            PSD.build_edit("replace_smart_object", "A", image=str(tmp_path / "none.png"))

    def test_preview_recipes(self, proj):
        assert {r["name"] for r in PV.list_recipes()} == {"full", "quick"}
        with pytest.raises(ValueError):
            PV.capture(proj, recipe="nope")


# ------------------------------------------------------------------ CLI ----
class TestCLIOffline:
    def _run(self, args):
        import cli_anything.photoshop.photoshop_cli as cli_mod

        cli_mod._session = None
        return CliRunner().invoke(cli_mod.cli, args)

    def test_help(self):
        r = self._run(["--help"])
        assert r.exit_code == 0 and "psd" in r.output and "layer" in r.output

    def test_project_new_json(self, tmp_path):
        out = str(tmp_path / "p.json")
        r = self._run(["--json", "project", "new", "--profile", "og_image", "-o", out])
        data = json.loads(r.output)
        assert r.exit_code == 0 and data["canvas"]["width"] == 1200 and os.path.exists(out)

    def test_mutations_autosave(self, tmp_path):
        out = str(tmp_path / "p.json")
        self._run(["project", "new", "-o", out])
        assert self._run(["--project", out, "layer", "add-solid", "#ff0000"]).exit_code == 0
        assert self._run(["--project", out, "filter", "add", "gaussian_blur", "-l", "0", "-p", "radius=3"]).exit_code == 0
        assert self._run(["--project", out, "style", "add", "stroke", "-l", "0"]).exit_code == 0
        saved = P.open_project(out)
        assert saved["layers"][0]["filters"][0]["params"]["radius"] == 3.0
        assert saved["layers"][0]["styles"][0]["name"] == "stroke"

    def test_dry_run(self, tmp_path):
        out = str(tmp_path / "p.json")
        self._run(["project", "new", "-o", out])
        self._run(["--project", out, "--dry-run", "layer", "add-solid", "#ff0000"])
        assert P.open_project(out)["layers"] == []

    def test_json_error_envelope(self, tmp_path):
        out = str(tmp_path / "p.json")
        self._run(["project", "new", "-o", out])
        r = self._run(["--json", "--project", out, "layer", "remove", "3"])
        assert r.exit_code == 1 and json.loads(r.output)["type"] == "IndexError"

    def test_missing_project_file(self, tmp_path):
        r = self._run(["--json", "--project", str(tmp_path / "nope.json"), "layer", "list"])
        assert r.exit_code == 1 and json.loads(r.output.splitlines()[0])["type"] == "file_not_found"

    def test_failed_mutation_not_saved(self, tmp_path):
        out = str(tmp_path / "p.json")
        self._run(["project", "new", "-o", out])
        self._run(["--project", out, "layer", "add-solid", "#000"])
        r = self._run(["--project", out, "layer", "set", "0", "opacity", "500"])
        assert r.exit_code == 1 and P.open_project(out)["layers"][0]["opacity"] == 100.0

    def test_list_commands(self):
        assert self._run(["--json", "filter", "list-available", "--category", "blur"]).exit_code == 0
        assert len(json.loads(self._run(["--json", "style", "list-available"]).output)) == 4
        assert self._run(["--json", "export", "presets"]).exit_code == 0
        assert self._run(["--json", "preview", "recipes"]).exit_code == 0


# ------------------------------------------------- review regressions ----
class TestReviewRegressions:
    def _run(self, args, **kw):
        import cli_anything.photoshop.photoshop_cli as cli_mod

        cli_mod._session = None
        cli_mod._repl_mode = False
        return CliRunner().invoke(cli_mod.cli, args, **kw)

    def test_set_property_type_applicability(self, proj):
        L.add_solid(proj, "#111")
        with pytest.raises(ValueError, match="does not apply to solid"):
            L.set_property(proj, 0, "text", "hello")

    @pytest.mark.parametrize("prop,value", [("width", "-5"), ("height", "0"), ("name", "  ")])
    def test_set_property_value_validation(self, proj, prop, value):
        L.add_shape(proj, "rect", 0, 0, 10, 10, "#000")
        with pytest.raises(ValueError):
            L.set_property(proj, 0, prop, value)

    def test_set_text_empty_and_size(self, proj):
        L.add_text(proj, "a", 0, 0)
        with pytest.raises(ValueError):
            L.set_property(proj, 0, "text", "")
        with pytest.raises(ValueError):
            L.set_property(proj, 0, "size", "0")

    def test_canvas_must_be_object(self):
        with pytest.raises(ValueError, match="'canvas' must be an object"):
            P.validate_project({"version": "1", "layers": [], "canvas": []})

    def test_atomic_save_leaves_no_temp(self, proj, tmp_path):
        s = Session()
        s.set_project(proj)
        s.save_session(str(tmp_path / "p.json"))
        assert sorted(os.listdir(tmp_path)) == ["p.json"]

    def test_in_place_rejects_flat_formats(self, tmp_path):
        f = tmp_path / "a.png"
        f.write_bytes(b"\x89PNG\r\n\x1a\n")
        with pytest.raises(ValueError, match="--in-place only supports"):
            PSD.edit(str(f), [PSD.build_edit("set_visibility", "x", visible=True)], [], in_place=True)

    def test_project_new_overwrite_guard(self, tmp_path):
        out = str(tmp_path / "p.json")
        assert self._run(["project", "new", "-o", out]).exit_code == 0
        r = self._run(["--json", "project", "new", "-o", out])
        assert r.exit_code == 1 and json.loads(r.output)["type"] == "file_exists"
        assert self._run(["project", "new", "-o", out, "--overwrite"]).exit_code == 0

    def test_directory_as_project_gives_json_error(self, tmp_path):
        r = self._run(["--json", "--project", str(tmp_path), "layer", "list"])
        assert r.exit_code == 1 and "error" in json.loads(r.output.splitlines()[0])

    def test_repl_does_not_autosave_discarded_changes(self, tmp_path, monkeypatch):
        from cli_anything.photoshop.utils import repl_skin

        out = str(tmp_path / "p.json")
        self._run(["project", "new", "-o", out])
        lines = iter(["layer add-solid #ff0000", "quit"])
        monkeypatch.setattr(repl_skin.ReplSkin, "create_prompt_session", lambda self: None)
        monkeypatch.setattr(repl_skin.ReplSkin, "get_input", lambda self, *a, **k: next(lines))
        r = self._run(["--project", out])
        assert r.exit_code == 0, r.output
        assert P.open_project(out)["layers"] == []
