"""E2E tests — drive the REAL Adobe Photoshop. No skipping: Photoshop is a hard dependency.

Outputs are verified by magic bytes and pixel read-back (Pillow is used only to
*read* what Photoshop wrote). Artifact paths are printed (run with -s).
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys

import pytest
from PIL import Image

from cli_anything.photoshop.core import export as E
from cli_anything.photoshop.core import filters as F
from cli_anything.photoshop.core import jsx
from cli_anything.photoshop.core import layers as L
from cli_anything.photoshop.core import project as P
from cli_anything.photoshop.core import psd as PSD
from cli_anything.photoshop.core.session import Session
from cli_anything.photoshop.utils import photoshop_backend as backend
from cli_anything.photoshop.utils.photoshop_backend import PhotoshopError


# ----------------------------------------------------------------- helpers ----
def _render(project, tmp_path, name="out.png"):
    path = str(tmp_path / name)
    result = E.render(project, [E.build_output(path, overwrite=True)])
    print(f"\n  {name}: {path} ({os.path.getsize(path):,} bytes)")
    return path, result


def _px(path, x, y):
    with Image.open(path) as im:
        return im.convert("RGBA").getpixel((x, y))


def _close(a, b, tol=3):
    return all(abs(int(i) - int(j)) <= tol for i, j in zip(a, b))


def _md5(path):
    return hashlib.md5(open(path, "rb").read()).hexdigest()


def _make_png(path, size, color):
    Image.new("RGB", size, color).save(path)
    return str(path)


def _find(layers, path):
    for layer in layers:
        if layer["path"] == path:
            return layer
        found = _find(layer.get("layers", []), path)
        if found:
            return found
    return None


FIXTURE_BODY = """
var doc = app.documents.add(600, 400, 72, 'fixture', NewDocumentMode.RGB, DocumentFill.WHITE);
__tmpDocs.push(doc);
var prod = doc.artLayers.add();
__selectRect(doc, 50, 50, 200, 150); doc.selection.fill(__rgb('#ff0000')); doc.selection.deselect();
doc.activeLayer = prod;
executeAction(sTID('newPlacedLayer'), undefined, DialogModes.NO);
doc.activeLayer.name = 'Product';
var g = doc.layerSets.add(); g.name = 'Header';
var t = g.artLayers.add(); t.kind = LayerKind.TEXT;
t.textItem.contents = 'Original'; t.textItem.size = 40; t.textItem.position = [300, 100];
t.textItem.color = __rgb('#000000'); t.name = 'Title';
var a = doc.layerSets.add(); a.name = 'A'; var d1 = a.artLayers.add(); d1.name = 'Dup';
var b = doc.layerSets.add(); b.name = 'B'; var d2 = b.artLayers.add(); d2.name = 'Dup';
doc.activeLayer = d2; __selectRect(doc, 400, 300, 50, 50); doc.selection.fill(__rgb('#0000ff')); doc.selection.deselect();
return __saveAs(doc, { path: __DATA.path, format: 'psd' });
"""


@pytest.fixture(scope="module")
def fixture_psd(tmp_path_factory):
    path = tmp_path_factory.mktemp("psd") / "fixture.psd"
    backend.run_jsx_json(jsx.wrap(FIXTURE_BODY, {"path": jsx.to_ps_path(str(path))}))
    assert E.sniff_format(str(path)) == "psd"
    print(f"\n  fixture PSD: {path}")
    return str(path)


@pytest.fixture
def white():
    return P.create_project(400, 300, name="e2e")


# ---------------------------------------------------------------- backend ----
class TestBackend:
    def test_status_connect(self):
        status = backend.backend_status(connect=True)
        assert status["connected"] and status["version"][0].isdigit()
        print(f"\n  Photoshop {status['version']} / ExtendScript {status['scripting_version']}")

    def test_fonts(self):
        res = PSD.fonts("arial", 5)
        assert res["total_installed"] > 0 and res["fonts"] and all("postscript_name" in f for f in res["fonts"])

    def test_script_error_is_reported(self):
        with pytest.raises(PhotoshopError, match="boom"):
            backend.run_jsx_json(jsx.wrap("throw new Error('boom');"))


# ------------------------------------------------------------ layer types ----
class TestLayerTypes:
    def test_solid(self, white, tmp_path):
        L.add_solid(white, "#ff0000")
        path, _ = _render(white, tmp_path)
        assert _px(path, 200, 150)[:3] == (255, 0, 0)

    def test_rect_and_background(self, tmp_path):
        p = P.create_project(400, 300, background="#102030")
        L.add_shape(p, "rect", 100, 100, 50, 50, "#00ff00")
        path, _ = _render(p, tmp_path)
        assert _px(path, 125, 125)[:3] == (0, 255, 0)
        assert _px(path, 10, 10)[:3] == (16, 32, 48)

    def test_ellipse(self, white, tmp_path):
        L.add_shape(white, "ellipse", 100, 50, 200, 200, "#0000ff")
        path, _ = _render(white, tmp_path)
        assert _px(path, 200, 150)[:3] == (0, 0, 255)
        assert _px(path, 104, 54)[:3] == (255, 255, 255)  # bbox corner outside the ellipse

    def test_text(self, tmp_path):
        p = P.create_project(600, 200, background="#000000")
        L.add_text(p, "HELLO", 300, 140, size=100, color="#ffffff", align="center", font="Arial-BoldMT")
        path, result = _render(p, tmp_path)
        with Image.open(path) as im:
            bright = sum(1 for v in im.convert("L").crop((100, 40, 500, 160)).tobytes() if v > 200)
        assert bright > 3000
        text_layer = result["document"]["layers"][0]
        assert text_layer["kind"] == "text" and text_layer["text"] == "HELLO" and text_layer["font"] == "Arial-BoldMT"

    def test_image_position_and_scale(self, white, tmp_path):
        src = _make_png(tmp_path / "green.png", (100, 50), (0, 200, 0))
        L.add_image(white, src, x=150, y=100, width=200)
        path, result = _render(white, tmp_path)
        b = result["document"]["layers"][0]["bounds"]
        assert (b["left"], b["top"], b["right"], b["bottom"]) == (150, 100, 350, 200)
        assert _close(_px(path, 250, 150)[:3], (0, 200, 0))
        assert _px(path, 100, 150)[:3] == (255, 255, 255)

    def test_gradient(self, white, tmp_path):
        L.add_gradient(white, ["#000000", "#ffffff"], angle=0)
        path, _ = _render(white, tmp_path)
        assert _px(path, 2, 150)[0] < 30 and _px(path, 397, 150)[0] > 225

    def test_transparent_background(self, tmp_path):
        p = P.create_project(200, 200, background="transparent")
        L.add_shape(p, "rect", 50, 50, 100, 100, "#ff00ff")
        path, _ = _render(p, tmp_path)
        assert _px(path, 5, 5)[3] == 0 and _px(path, 100, 100) == (255, 0, 255, 255)


# ---------------------------------------------------------------- filters ----
class TestFilters:
    def _solid(self, white, color, name, params=None):
        L.add_solid(white, color)
        F.add_filter(white, 0, name, params or {})

    def test_invert(self, white, tmp_path):
        self._solid(white, "#204060", "invert")
        assert _px(_render(white, tmp_path)[0], 10, 10)[:3] == (223, 191, 159)

    def test_desaturate(self, white, tmp_path):
        self._solid(white, "#ff8000", "desaturate")
        r, g, b, _ = _px(_render(white, tmp_path)[0], 10, 10)
        assert r == g == b

    def test_threshold(self, white, tmp_path):
        L.add_gradient(white, ["#000000", "#ffffff"], angle=0)
        F.add_filter(white, 0, "threshold", {"level": "128"})
        with Image.open(_render(white, tmp_path)[0]) as im:
            assert set(im.convert("L").tobytes()) <= {0, 255}

    def test_gaussian_blur_softens_edges(self, white, tmp_path):
        L.add_shape(white, "rect", 100, 100, 100, 100, "#000000")
        hard = _render(white, tmp_path, "hard.png")[0]
        F.add_filter(white, 0, "gaussian_blur", {"radius": "8"})
        soft = _render(white, tmp_path, "soft.png")[0]
        assert _px(hard, 97, 150)[:3] == (255, 255, 255)
        v = _px(soft, 97, 150)[0]
        assert 20 < v < 240

    def test_hue_saturation_colorize(self, white, tmp_path):
        self._solid(white, "#808080", "hue_saturation", {"hue": "0", "saturation": "100", "colorize": "true"})
        r, g, b, _ = _px(_render(white, tmp_path)[0], 10, 10)
        assert r - b > 60

    def test_brightness(self, white, tmp_path):
        self._solid(white, "#808080", "brightness_contrast", {"brightness": "100"})
        assert _px(_render(white, tmp_path)[0], 10, 10)[0] > 150


# ------------------------------------------------------- props and styles ----
class TestPropsAndStyles:
    def test_opacity(self, white, tmp_path):
        L.add_solid(white, "#000000")
        L.set_property(white, 0, "opacity", 50)
        assert _close(_px(_render(white, tmp_path)[0], 10, 10)[:3], (128, 128, 128), 3)

    def test_multiply(self, white, tmp_path):
        L.add_solid(white, "#ff0000")
        L.add_solid(white, "#808080")
        L.set_property(white, 1, "blend_mode", "multiply")
        assert _close(_px(_render(white, tmp_path)[0], 10, 10)[:3], (128, 0, 0), 2)

    def test_hidden_layer(self, white, tmp_path):
        L.add_solid(white, "#ff0000")
        L.set_property(white, 0, "visible", "false")
        path, result = _render(white, tmp_path)
        assert _px(path, 10, 10)[:3] == (255, 255, 255) and result["document"]["layers"][0]["visible"] is False

    def test_stroke(self, white, tmp_path):
        L.add_shape(white, "rect", 100, 100, 100, 100, "#ff0000")
        F.add_style(white, 0, "stroke", {"color": "#000000", "size": "6"})
        path, _ = _render(white, tmp_path)
        assert max(_px(path, 97, 150)[:3]) < 40
        assert _px(path, 90, 150)[:3] == (255, 255, 255)

    def test_drop_shadow(self, white, tmp_path):
        L.add_shape(white, "rect", 100, 50, 100, 100, "#ff0000")
        F.add_style(white, 0, "drop_shadow", {"angle": "90", "distance": "20", "size": "0", "opacity": "100"})
        path, _ = _render(white, tmp_path)
        assert max(_px(path, 150, 160)[:3]) < 60  # shadow below the rect
        assert _px(path, 150, 40)[:3] == (255, 255, 255)  # nothing above

    def test_offset(self, white, tmp_path):
        L.add_shape(white, "rect", 0, 0, 50, 50, "#00ff00")
        L.set_property(white, 0, "offset_x", 100)
        path, _ = _render(white, tmp_path)
        assert _px(path, 25, 25)[:3] == (255, 255, 255) and _px(path, 125, 25)[:3] == (0, 255, 0)


# ---------------------------------------------------------------- formats ----
class TestFormats:
    def test_all_formats_one_render(self, white, tmp_path):
        L.add_solid(white, "#336699")
        L.add_text(white, "fmt", 10, 100, size=40)
        outs = [E.build_output(str(tmp_path / f"o.{ext}"), overwrite=True) for ext in ("png", "jpg", "tif", "psd")]
        result = E.render(white, outs)
        assert [o["verified_format"] for o in result["outputs"]] == ["png", "jpg", "tif", "psd"]
        for o in result["outputs"]:
            print(f"\n  {o['format']}: {o['path']} ({o['bytes']:,} bytes)")
        info = PSD.info(str(tmp_path / "o.psd"))
        assert info["width"] == 400 and [l["kind"] for l in info["layers"]] == ["text", "normal", "normal"]
        assert _close(_px(str(tmp_path / "o.jpg"), 200, 20)[:3], (51, 102, 153), 4)

    def test_jpeg_quality_affects_size(self, white, tmp_path):
        L.add_gradient(white, ["#ff0000", "#00ff00", "#0000ff"], angle=30)
        F.add_filter(white, 0, "add_noise", {"amount": "20"})
        result = E.render(white, [E.build_output(str(tmp_path / "lo.jpg"), quality=2, overwrite=True),
                                  E.build_output(str(tmp_path / "hi.jpg"), quality=12, overwrite=True)])
        lo, hi = result["outputs"]
        assert hi["bytes"] > lo["bytes"]


# ------------------------------------------------------------ PSD editing ----
class TestPsdOperations:
    def test_info_tree(self, fixture_psd):
        info = PSD.info(fixture_psd)
        assert info["width"] == 600 and info["height"] == 400
        title = _find(info["layers"], "Header/Title")
        assert title["kind"] == "text" and title["text"] == "Original"
        assert _find(info["layers"], "Product")["kind"] == "smartobject"
        assert info["layer_count"] == 8

    def test_set_text_by_path_leaves_original(self, fixture_psd, tmp_path):
        out = str(tmp_path / "edited.psd")
        res = PSD.edit(fixture_psd, [PSD.build_edit("set_text", "Header/Title", text="Changed")],
                       [E.build_output(out)])
        assert _find(res["document"]["layers"], "Header/Title")["text"] == "Changed"
        assert _find(PSD.info(out)["layers"], "Header/Title")["text"] == "Changed"
        assert _find(PSD.info(fixture_psd)["layers"], "Header/Title")["text"] == "Original"

    def test_ambiguous_name(self, fixture_psd, tmp_path):
        with pytest.raises(PhotoshopError, match="ambiguous"):
            PSD.edit(fixture_psd, [PSD.build_edit("set_visibility", "Dup", visible=False)],
                     [E.build_output(str(tmp_path / "x.png"))])

    def test_not_found_and_wrong_kind(self, fixture_psd, tmp_path):
        with pytest.raises(PhotoshopError, match="not found"):
            PSD.edit(fixture_psd, [PSD.build_edit("set_text", "Nope", text="x")], [E.build_output(str(tmp_path / "a.png"))])
        with pytest.raises(PhotoshopError, match="not a text layer"):
            PSD.edit(fixture_psd, [PSD.build_edit("set_text", "Product", text="x")], [E.build_output(str(tmp_path / "b.png"))])

    def test_hide_by_path_and_opacity(self, fixture_psd, tmp_path):
        png, psd_out = str(tmp_path / "h.png"), str(tmp_path / "h.psd")
        PSD.edit(fixture_psd, [PSD.build_edit("set_visibility", "B/Dup", visible=False),
                               PSD.build_edit("set_opacity", "Product", opacity=50)],
                 [E.build_output(png), E.build_output(psd_out)])
        layers = PSD.info(psd_out)["layers"]
        assert _find(layers, "B/Dup")["visible"] is False and _find(layers, "Product")["opacity"] == 50
        assert _px(png, 425, 325)[:3] == (255, 255, 255)  # blue square hidden
        assert _close(_px(png, 150, 125)[:3], (255, 128, 128), 3)  # red at 50%

    def test_replace_smart_object(self, fixture_psd, tmp_path):
        green = _make_png(tmp_path / "g.png", (200, 150), (0, 255, 0))
        png = str(tmp_path / "so.png")
        PSD.edit(fixture_psd, [PSD.build_edit("replace_smart_object", "Product", image=green)], [E.build_output(png)])
        assert _close(_px(png, 150, 125)[:3], (0, 255, 0), 3)

    def test_in_place(self, fixture_psd, tmp_path):
        copy_path = str(tmp_path / "copy.psd")
        shutil.copy(fixture_psd, copy_path)
        PSD.edit(copy_path, [PSD.build_edit("set_text", "Header/Title", text="InPlace")], [], in_place=True)
        assert _find(PSD.info(copy_path)["layers"], "Header/Title")["text"] == "InPlace"

    def test_export_layers(self, fixture_psd, tmp_path):
        res = PSD.export_layers(fixture_psd, str(tmp_path / "layers"), trim=True)
        names = [l["layer"] for l in res["layers"]]
        assert names == ["B/Dup", "A/Dup", "Header/Title", "Product", "Background"]  # top-first
        title = res["layers"][2]
        assert title["width"] < 600 and title["height"] < 400
        product = res["layers"][3]
        assert (product["width"], product["height"]) == (200, 150)
        print(f"\n  layers exported to {tmp_path / 'layers'}")

    def test_export_flattened(self, fixture_psd, tmp_path):
        res = PSD.export(fixture_psd, [E.build_output(str(tmp_path / "flat.jpg"))])
        assert res["outputs"][0]["verified_format"] == "jpg"

    def test_no_documents_leaked(self, fixture_psd, tmp_path):
        before = len(PSD.open_documents())
        PSD.info(fixture_psd)
        PSD.export_layers(fixture_psd, str(tmp_path / "l2"))
        assert len(PSD.open_documents()) == before


# --------------------------------------------------------------- workflows ----
class TestWorkflows:
    def test_youtube_thumbnail(self, tmp_path):
        photo = _make_png(tmp_path / "photo.png", (400, 300), (180, 120, 60))
        p = P.create_project(profile="youtube_thumb", background="#101020", name="thumb")
        L.add_gradient(p, ["#ff0066", "#3300ff"], angle=45)
        L.add_image(p, photo, x=700, y=200, width=520)
        F.add_filter(p, 1, "hue_saturation", {"saturation": "40"})
        L.add_text(p, "BIG NEWS", 400, 400, size=130, color="#ffffff", align="center", font="Arial-BoldMT")
        F.add_style(p, 2, "stroke", {"color": "#000000", "size": "6"})
        F.add_style(p, 2, "drop_shadow", {"distance": "12"})
        png, psd_out = str(tmp_path / "thumb.png"), str(tmp_path / "thumb.psd")
        result = E.render(p, [E.build_output(png), E.build_output(psd_out)])
        with Image.open(png) as im:
            assert im.size == (1280, 720)
        info = PSD.info(psd_out)
        assert info["layer_count"] == 4 and info["layers"][0]["text"] == "BIG NEWS"
        assert result["outputs"][1]["bytes"] > result["outputs"][0]["bytes"] / 4
        print(f"\n  thumbnail: {png}\n  layered: {psd_out}")

    def test_template_batch_personalization(self, fixture_psd, tmp_path):
        before = _md5(fixture_psd)
        outs = []
        for name in ("Alice", "Bob", "Chandra"):
            out = str(tmp_path / f"banner_{name}.png")
            PSD.edit(fixture_psd, [PSD.build_edit("set_text", "Header/Title", text=f"Hi {name}")], [E.build_output(out)])
            outs.append(out)
        assert len({_md5(o) for o in outs}) == 3
        assert _md5(fixture_psd) == before

    def test_iterative_refinement_with_undo(self, white, tmp_path):
        s = Session()
        s.set_project(white)
        s.snapshot("solid")
        L.add_solid(s.project, "#ff0000")
        s.snapshot("invert")
        F.add_filter(s.project, 0, "invert", {})
        s.undo()
        s.redo()
        s.snapshot("color")
        L.set_property(s.project, 0, "color", "#00ff00")
        path, _ = _render(s.project, tmp_path)
        assert _px(path, 10, 10)[:3] == (255, 0, 255)  # inverted green


# ---------------------------------------------------- installed CLI tests ----
def _resolve_cli(name):
    """Resolve installed CLI command; falls back to python -m for dev.

    Set env CLI_ANYTHING_FORCE_INSTALLED=1 to require the installed command.
    """
    force = os.environ.get("CLI_ANYTHING_FORCE_INSTALLED", "").strip() == "1"
    path = shutil.which(name)
    if path:
        print(f"[_resolve_cli] Using installed command: {path}")
        return [path]
    if force:
        raise RuntimeError(f"{name} not found in PATH. Install with: pip install -e .")
    module = name.replace("cli-anything-", "cli_anything.") + "." + name.split("-")[-1] + "_cli"
    print(f"[_resolve_cli] Falling back to: {sys.executable} -m {module}")
    return [sys.executable, "-m", module]


class TestCLISubprocess:
    CLI_BASE = _resolve_cli("cli-anything-photoshop")

    def _run(self, args, check=True):
        return subprocess.run(self.CLI_BASE + args, capture_output=True, text=True, check=check)

    def _json(self, args):
        return json.loads(self._run(["--json"] + args).stdout)

    def test_help(self):
        r = self._run(["--help"])
        assert r.returncode == 0 and "Photoshop" in r.stdout

    def test_backend_status(self):
        data = self._json(["backend", "status", "--connect"])
        assert data["connected"] is True and data["installs"]

    def test_full_pipeline(self, tmp_path):
        proj = str(tmp_path / "p.ps-cli.json")
        png, psd_out = str(tmp_path / "out.png"), str(tmp_path / "out.psd")
        data = self._json(["project", "new", "-w", "500", "-h", "300", "-b", "#000000", "-o", proj])
        assert data["canvas"]["width"] == 500
        P_ = ["--project", proj]
        self._run(P_ + ["layer", "add-shape", "rect", "--x", "50", "--y", "50", "--width", "100", "--height", "100", "-c", "#ffffff"])
        self._run(P_ + ["filter", "add", "invert", "-l", "0"])
        self._run(P_ + ["layer", "add-text", "CLI", "--x", "250", "--y", "200", "--size", "80", "--color", "#ff0000", "--align", "center"])
        self._run(P_ + ["style", "add", "stroke", "-l", "1", "-p", "color=#ffff00"])
        assert len(self._json(P_ + ["layer", "list"])) == 2
        res = self._json(P_ + ["export", "render", png, "--also", psd_out, "--overwrite"])
        assert [o["verified_format"] for o in res["outputs"]] == ["png", "psd"]
        assert _px(png, 100, 100)[:3] == (0, 0, 0)  # inverted white rect on black bg
        info = self._json(["psd", "info", psd_out])
        assert info["layers"][0]["text"] == "CLI"
        print(f"\n  CLI render: {png}")

    def test_psd_edit_cli(self, fixture_psd, tmp_path):
        out = str(tmp_path / "cli_edit.png")
        res = self._json(["psd", "edit", fixture_psd, "--set-text", "Header/Title=From CLI", "--hide", "A/Dup", "-o", out])
        assert res["applied"][0]["op"] == "set_text" and os.path.getsize(out) > 0

    def test_error_exit_code(self, tmp_path):
        r = self._run(["--json", "psd", "info", str(tmp_path / "missing.psd")], check=False)
        assert r.returncode == 1 and json.loads(r.stdout)["type"] == "file_not_found"

    def test_overwrite_guard(self, tmp_path):
        proj = str(tmp_path / "p.json")
        existing = tmp_path / "exists.png"
        existing.write_bytes(b"x")
        self._run(["project", "new", "-o", proj])
        r = self._run(["--json", "--project", proj, "export", "render", str(existing)], check=False)
        assert r.returncode == 1 and json.loads(r.stdout)["type"] == "file_exists"

    def test_preview_capture_and_cache(self, tmp_path):
        proj = str(tmp_path / "p.json")
        self._run(["project", "new", "-w", "320", "-h", "200", "-o", proj])
        self._run(["--project", proj, "layer", "add-solid", "#3366ff"])
        first = self._json(["--project", proj, "preview", "capture"])
        assert first["cached"] is False and first["protocol_version"] == "preview-bundle/v1"
        art = os.path.join(first["_bundle_dir"], first["artifacts"][0]["path"])
        assert _px(art, 5, 5)[:3] == (51, 102, 255)
        assert self._json(["--project", proj, "preview", "capture"])["cached"] is True
        assert self._json(["--project", proj, "preview", "latest"])["bundle_id"] == first["bundle_id"]
        print(f"\n  preview bundle: {first['_bundle_dir']}")

    def test_run_jsx(self, tmp_path):
        script = tmp_path / "s.jsx"
        script.write_text("1 + 41;")
        assert self._json(["backend", "run-jsx", str(script)])["result"] == "42"


# ------------------------------------------------- review regressions ----
class TestReviewRegressionsE2E:
    def test_export_layers_inside_hidden_group(self, fixture_psd, tmp_path):
        hidden = str(tmp_path / "hidden_b.psd")
        PSD.edit(fixture_psd, [PSD.build_edit("set_visibility", "B", visible=False)], [E.build_output(hidden)])
        res = PSD.export_layers(hidden, str(tmp_path / "all"))
        b_dup = next(l for l in res["layers"] if l["layer"] == "B/Dup")
        assert _px(b_dup["path"], 425, 325)[:3] == (0, 0, 255)  # not a blank file
        visible = PSD.export_layers(hidden, str(tmp_path / "vis"), visible_only=True)
        assert "B/Dup" not in [l["layer"] for l in visible["layers"]]
        assert _find(PSD.info(hidden)["layers"], "B")["visible"] is False  # visibility restored

    def test_refuses_document_already_open(self, fixture_psd):
        opened = "app.open(__file(__DATA.p)); return app.documents.length;"
        backend.run_jsx_json(jsx.wrap(opened, {"p": jsx.to_ps_path(fixture_psd)}))
        try:
            with pytest.raises(PhotoshopError, match="open in Photoshop"):
                PSD.info(fixture_psd)
        finally:
            close = "var n = app.documents.length; for (var i = n - 1; i >= 0; i--) app.documents[i].close(SaveOptions.DONOTSAVECHANGES); return n;"
            assert backend.run_jsx_json(jsx.wrap(close)) == 1

    def test_percent_and_unicode_paths(self, fixture_psd, tmp_path):
        weird_dir = tmp_path / "50%20off é"
        weird_dir.mkdir()
        src = weird_dir / "tmpl 100%.psd"
        shutil.copy(fixture_psd, src)
        out = weird_dir / "out%41.png"
        res = PSD.export(str(src), [E.build_output(str(out))])
        assert os.path.isfile(out) and res["outputs"][0]["verified_format"] == "png"

    def test_preview_cache_invalidated_by_image_edit(self, tmp_path):
        from cli_anything.photoshop.core import preview as PV

        img = _make_png(tmp_path / "src.png", (50, 50), (255, 0, 0))
        p = P.create_project(100, 100)
        L.add_image(p, img)
        first = PV.capture(p, root_dir=str(tmp_path / "pv"))
        os.utime(img, ns=(os.stat(img).st_atime_ns, os.stat(img).st_mtime_ns + 5_000_000_000))
        _make_png(tmp_path / "src.png", (50, 50), (0, 0, 255))
        second = PV.capture(p, root_dir=str(tmp_path / "pv"))
        assert second["cached"] is False and second["bundle_id"] != first["bundle_id"]
        art = os.path.join(second["_bundle_dir"], second["artifacts"][0]["path"])
        assert _px(art, 10, 10)[:3] == (0, 0, 255)
