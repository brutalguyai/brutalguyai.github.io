import csv, datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
rows=list(csv.DictReader(open('expenses.csv')))
wb=Workbook(); ws=wb.active; ws.title="Expenses"
ws.append(["Date","Item","Amount (INR)","Paid by"])
for r in rows:
    ws.append([datetime.date.fromisoformat(r['date']),r['item'],float(r['amount_inr']),r['paid_by']])
n=len(rows)+1
ws.append(["","Total",f"=SUM(C2:C{n})",""])
hf=PatternFill("solid",fgColor="DDDDDD")
for s in (ws,):
    for c in s[1]: c.font=Font(bold=True); c.fill=hf
for c in ws[n+1]: c.font=Font(bold=True)
for r in range(2,n+1): ws.cell(r,1).number_format="DD-MMM-YYYY"
for r in range(2,n+2): ws.cell(r,3).number_format="#,##0.00"
for col,w in zip("ABCD",(14,28,16,12)): ws.column_dimensions[col].width=w
s=wb.create_sheet("Summary")
s.append(["Person","Total paid (INR)","Fair share (INR)","Balance (INR)"])
for i,p in enumerate(["Aarav","Bhavna","Chirag","Divya"],start=2):
    s.append([p,f'=SUMIF(Expenses!$D$2:$D${n},A{i},Expenses!$C$2:$C${n})',f"=SUM(Expenses!$C$2:$C${n})/4",f"=B{i}-C{i}"])
s.append(["Total","=SUM(B2:B5)","=SUM(C2:C5)","=SUM(D2:D5)"])
for c in s[1]: c.font=Font(bold=True); c.fill=hf
for c in s[6]: c.font=Font(bold=True)
for r in range(2,7):
    for c in range(2,5): s.cell(r,c).number_format="#,##0.00;[Red]-#,##0.00"
for col in "ABCD": s.column_dimensions[col].width=20
s.append([]); s.append(["Positive balance = is owed money; negative = owes money."])
for w in wb: w.page_setup.orientation="portrait"
wb.save("tmp.xlsx")
