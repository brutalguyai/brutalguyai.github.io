import csv, datetime
from openpyxl import Workbook
from openpyxl.styles import Font
wb=Workbook(); ws=wb.active; ws.title="Expenses"
ws.append(["Date","Item","Amount (INR)","Paid by"])
rows=list(csv.DictReader(open("expenses.csv")))
for r in rows:
    ws.append([datetime.date.fromisoformat(r["date"]),r["item"].strip(),float(r["amount_inr"]),r["paid_by"].strip()])
n=len(rows)+1
for c in ws[1]: c.font=Font(bold=True)
for i in range(2,n+1):
    ws.cell(i,1).number_format="DD-MMM-YYYY"; ws.cell(i,3).number_format="#,##0.00"
ws.cell(n+1,2,"Total").font=Font(bold=True)
ws.cell(n+1,3,f"=SUM(C2:C{n})").number_format="#,##0.00"
for col,w in zip("ABCD",(14,30,15,12)): ws.column_dimensions[col].width=w
s=wb.create_sheet("Summary")
s.append(["Person","Total paid (INR)","Fair share (INR)","Balance (INR)"])
for c in s[1]: c.font=Font(bold=True)
for i,p in enumerate(["Aarav","Bhavna","Chirag","Divya"],2):
    s.append([p,f"=SUMIF(Expenses.D$2:D${n},A{i},Expenses.C$2:C${n})".replace("Expenses.","Expenses!"),f"=SUM(Expenses!C$2:C${n})/COUNTA(A$2:A$5)",f"=B{i}-C{i}"])
    for c in "BCD": s[f"{c}{i}"].number_format="#,##0.00"
s.append(["Total","=SUM(B2:B5)","=SUM(C2:C5)","=SUM(D2:D5)"])
for c in s[6]: c.font=Font(bold=True)
for c in "BCD": s[f"{c}6"].number_format="#,##0.00"
for col in "ABCD": s.column_dimensions[col].width=18
wb.save("tmp.xlsx")
