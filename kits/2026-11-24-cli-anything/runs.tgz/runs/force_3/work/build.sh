set -e
P=$PWD/proj2.json
C="cli-anything-libreoffice --project $P"
rm -f $P
cli-anything-libreoffice document new --type calc -n flat_expenses -o $P
$C calc rename-sheet 0 Expenses
$C calc add-sheet -n Summary 2>&1 || $C calc add-sheet Summary
i=1
for h in Date Item "Amount (INR)" "Paid by"; do :; done
$C calc set-cell A1 Date --type string -s 0
$C calc set-cell B1 Item --type string -s 0
$C calc set-cell C1 "Amount (INR)" --type string -s 0
$C calc set-cell D1 "Paid by" --type string -s 0
r=2
tail -n +2 expenses.csv | while IFS=, read d it a p; do
 $C calc set-cell A$r "$d" --type string -s 0
 $C calc set-cell B$r "$it" --type string -s 0
 $C calc set-cell C$r "$a" --type float -s 0
 $C calc set-cell D$r "$p" --type string -s 0
 r=$((r+1))
done
for c in A1:Person B1:"Total paid" C1:"Fair share" D1:Balance; do :; done
$C calc set-cell A1 Person --type string -s 1
$C calc set-cell B1 "Total paid (INR)" --type string -s 1
$C calc set-cell C1 "Fair share (INR)" --type string -s 1
$C calc set-cell D1 "Balance (INR)" --type string -s 1
r=2
for n in Aarav Bhavna Chirag Divya; do
 $C calc set-cell A$r $n --type string -s 1
 $C calc set-cell B$r "" --formula "=SUMIF([\$Expenses.\$D\$2:.\$D\$16];[.A$r];[\$Expenses.\$C\$2:.\$C\$16])" -s 1
 $C calc set-cell C$r "" --formula "=SUM([\$Expenses.\$C\$2:.\$C\$16])/4" -s 1
 $C calc set-cell D$r "" --formula "=[.B$r]-[.C$r]" -s 1
 r=$((r+1))
done
$C calc set-cell A6 Total --type string -s 1
$C calc set-cell B6 "" --formula "=SUM([.B2:.B5])" -s 1
$C calc set-cell C6 "" --formula "=SUM([.C2:.C5])" -s 1
$C calc set-cell D6 "" --formula "=SUM([.D2:.D5])" -s 1
