import zipfile,re,sys,shutil
src,dst=sys.argv[1:3]
zi=zipfile.ZipFile(src)
files={n:zi.read(n) for n in zi.namelist()}
c=files['content.xml'].decode()
# 1. strip the 'of:' prefix the tool emits (LibreOffice rejects it -> Err:510)
c=c.replace('table:formula="of:=','table:formula="=')
# 2. real dates
c=re.sub(r'<table:table-cell office:value-type="string"><text:p>(\d{4}-\d\d-\d\d)</text:p>',
         r'<table:table-cell table:style-name="ceD" office:value-type="date" office:date-value="\1"><text:p>\1</text:p>',c)
# 3. 2-decimal number style on numeric / formula cells
c=re.sub(r'<table:table-cell (table:formula="[^"]*" )?office:value-type="float"',
         lambda m:'<table:table-cell table:style-name="ceN" '+(m.group(1) or '')+'office:value-type="float"',c)
# header row bold
c=re.sub(r'<table:table-cell office:value-type="string"><text:p>(Date|Item|Amount \(INR\)|Paid by|Person|Total paid \(INR\)|Fair share \(INR\)|Balance \(INR\)|Total)</text:p>',
         r'<table:table-cell table:style-name="ceH" office:value-type="string"><text:p>\1</text:p>',c)
# column widths
def cols(w): return ''.join(f'<table:table-column table:style-name="{s}"/>' for s in w)
parts=c.split('<table:table table:name=')
parts[1]=parts[1].replace('><table:table-row>','>'+cols(['coA','coB','coC','coD'])+'<table:table-row>',1)
parts[2]=parts[2].replace('><table:table-row>','>'+cols(['coP','coC','coC','coC'])+'<table:table-row>',1)
c='<table:table table:name='.join(parts)
styles='''<office:automatic-styles>
<number:number-style style:name="N2"><number:number number:decimal-places="2" number:min-integer-digits="1" number:grouping="true"/></number:number-style>
<number:date-style style:name="D1"><number:year number:style="long"/><number:text>-</number:text><number:month number:style="long"/><number:text>-</number:text><number:day number:style="long"/></number:date-style>
<style:style style:name="ceN" style:family="table-cell" style:data-style-name="N2"/>
<style:style style:name="ceD" style:family="table-cell" style:data-style-name="D1"/>
<style:style style:name="ceH" style:family="table-cell"><style:text-properties fo:font-weight="bold"/></style:style>
<style:style style:name="coA" style:family="table-column"><style:table-column-properties style:column-width="2.6cm"/></style:style>
<style:style style:name="coB" style:family="table-column"><style:table-column-properties style:column-width="6.5cm"/></style:style>
<style:style style:name="coC" style:family="table-column"><style:table-column-properties style:column-width="3.8cm"/></style:style>
<style:style style:name="coD" style:family="table-column"><style:table-column-properties style:column-width="3cm"/></style:style>
<style:style style:name="coP" style:family="table-column"><style:table-column-properties style:column-width="3cm"/></style:style>
</office:automatic-styles>'''
c=c.replace('<office:automatic-styles />',styles)
c=c.replace('xmlns:office=','xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:office=',1)
files['content.xml']=c.encode()
zo=zipfile.ZipFile(dst,'w')
zo.writestr(zipfile.ZipInfo('mimetype'),files.pop('mimetype'),zipfile.ZIP_STORED)
for n,d in files.items(): zo.writestr(n,d,zipfile.ZIP_DEFLATED)
zo.close()
