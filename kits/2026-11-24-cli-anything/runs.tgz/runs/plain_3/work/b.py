import csv,datetime
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill
wb=Workbook();ws=wb.active;ws.title="Expenses"
ws.append(["Date","Item","Amount (INR)","Paid by"])
rows=list(csv.DictReader(open("expenses.csv")))
for r in rows:
    ws.append([datetime.date.fromisoformat(r["date"]),r["item"],float(r["amount_inr"]),r["paid_by"]])
n=len(rows)+1
for c in ws[1]: c.font=Font(bold=True,color="FFFFFF");c.fill=PatternFill("solid",fgColor="305496")
for i in range(2,n+1):
    ws.cell(i,1).number_format="DD-MMM-YYYY";ws.cell(i,3).number_format="#,##0.00"
ws.append(["","Total",f"=SUM(C2:C{n})",""]);ws.cell(n+1,2).font=ws.cell(n+1,3).font=Font(bold=True);ws.cell(n+1,3).number_format="#,##0.00"
for k,w in zip("ABCD",[14,30,15,12]): ws.column_dimensions[k].width=w
s=wb.create_sheet("Summary")
s.append(["Person","Total paid (INR)","Fair share (INR)","Balance (INR)"])
for c in s[1]: c.font=Font(bold=True,color="FFFFFF");c.fill=PatternFill("solid",fgColor="305496")
for i,p in enumerate(["Aarav","Bhavna","Chirag","Divya"],2):
    s.append([p,f"=SUMIF(Expenses!$D$2:$D${n},A{i},Expenses!$C$2:$C${n})",f"=SUM(Expenses!$C$2:$C${n})/4",f"=B{i}-C{i}"])
s.append(["Total","=SUM(B2:B5)","=SUM(C2:C5)","=SUM(D2:D5)"])
for c in s[6]: c.font=Font(bold=True)
for row in s.iter_rows(min_row=2,min_col=2,max_col=4):
    for c in row:c.number_format="#,##0.00;[Red]-#,##0.00"
s.append([]);s.append(["Positive balance = is owed money; negative = owes money."])
for k in "ABCD": s.column_dimensions[k].width=20
for w in wb: w.page_setup.orientation="portrait"; w.page_setup.fitToWidth=1; w.sheet_properties.pageSetUpPr.fitToPage=True; w.page_setup.fitToHeight=0
wb.save("flat_expenses.xlsx")
