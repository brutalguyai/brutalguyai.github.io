import csv,datetime
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
rows=list(csv.DictReader(open('expenses.csv')))
wb=Workbook();ws=wb.active;ws.title="Expenses"
ws.append(["Date","Item","Amount (INR)","Paid by"])
for r in rows:
    ws.append([datetime.date.fromisoformat(r['date']),r['item'],float(r['amount_inr']),r['paid_by']])
n=len(rows)+1
for c in ws[1]: c.font=Font(bold=True,color="FFFFFF");c.fill=PatternFill("solid",fgColor="305496")
for i in range(2,n+1):
    ws.cell(i,1).number_format="DD-MMM-YYYY";ws.cell(i,3).number_format="#,##0.00"
ws.append(["","Total",f"=SUM(C2:C{n})",""]);
for c in ws[n+1]: c.font=Font(bold=True)
ws.cell(n+1,3).number_format="#,##0.00"
for col,w in zip("ABCD",[14,30,16,12]): ws.column_dimensions[col].width=w
s=wb.create_sheet("Summary")
s.append(["Person","Total paid (INR)","Fair share (INR)","Balance (INR)"])
for c in s[1]: c.font=Font(bold=True,color="FFFFFF");c.fill=PatternFill("solid",fgColor="305496")
for i,p in enumerate(["Aarav","Bhavna","Chirag","Divya"],2):
    s.append([p,f"=SUMIF(Expenses!$D$2:$D${n},A{i},Expenses!$C$2:$C${n})",f"=SUM(Expenses!$C$2:$C${n})/4",f"=B{i}-C{i}"])
s.append(["Total","=SUM(B2:B5)","=SUM(C2:C5)","=SUM(D2:D5)"])
for c in s[6]: c.font=Font(bold=True)
for row in s.iter_rows(min_row=2,max_row=6,min_col=2,max_col=4):
    for c in row: c.number_format="#,##0.00;[Red]-#,##0.00"
s["A8"]="Positive balance = is owed money; negative = owes money."
for col in "ABCD": s.column_dimensions[col].width=20
wb.save("flat_expenses.xlsx")
